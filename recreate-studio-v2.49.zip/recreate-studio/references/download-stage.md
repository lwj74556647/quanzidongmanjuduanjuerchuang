# 阶段 0：素材获取（asset-harvester 精简版）

完整流程见 `references/download-pipeline.md`（原 asset-harvester v1.0 已并入本技能）。

## 判断来源

| 来源 | 路线 |
|---|---|
| 已登录网站（星图等） | Playwright 接管 Chrome 副本 → 抓接口 |
| 百度网盘分享 `pan.baidu.com/s/xxx?pwd=` | BaiduPCS-Go 转存 + 下载 |
| 直链 | curl / aria2c |

## Chrome 副本（推荐）

```powershell
# 完全关闭 Chrome 后
$src = "$env:LOCALAPPDATA\Google\Chrome\User Data"; $dst = "D:\chrome-dsh-profile"
New-Item -ItemType Directory -Force "$dst\Default\Network" | Out-Null
Copy-Item "$src\Local State" "$dst\Local State"
Copy-Item "$src\Default\Network\Cookies" "$dst\Default\Network\Cookies"
Copy-Item "$src\Default\Local Storage" "$dst\Default\Local Storage" -Recurse
& "C:\Program Files\Google\Chrome\Application\chrome.exe" `
  --user-data-dir=D:\chrome-dsh-profile --remote-debugging-port=9333 `
  --no-first-run --no-default-browser-check
```

Chrome 155 复制后 Cookie 可能失效 → 在副本窗口登录一次。

## 抓接口

```python
from playwright.sync_api import sync_playwright
with sync_playwright() as p:
    b = p.chromium.connect_over_cdp("http://127.0.0.1:9333")
    page = b.contexts[0].pages[0]
    store = {}
    page.on("response", lambda r: store.setdefault(r.url, r.text()) if "/gw/api/" in r.url else None)
    page.goto("https://www.xingtu.cn/sup/creator/user/task")
    page.wait_for_timeout(6000)
```

- 列表/详情接口的字段：见 `asset-harvester/references/case-xingtu-2026-10-25.md`
- 分页：点 `li.number` 让页面自己发请求（外部重放会 400）

## 百度网盘下载

```powershell
$exe = "D:\deepseek编程脚本\tools\BaiduPCS-Go\BaiduPCS-Go-v4.0.2-windows-x64\BaiduPCS-Go.exe"
& $exe login "-cookies=BDUSS=...; STOKEN=..."
& $exe cd /漫剧
& $exe transfer "<分享链接>" "<提取码>"
& $exe download --saveto "D:\碧海剧场\001. 剧名" -p 8 封面.jpg 1.mp4 2.mp4 3.mp4
```

## 目录与容错

- 目录：`<根>\NNN. <剧名>`
- 网盘目录可能带 `：共N集` 后缀；分享内可能套层或分 `封面/`、`正片/`
- 封面文件名可能是 `cover (1).jpg`、`1：1.png`
- Python 调用：输出 GBK、下载必须 `stdout=DEVNULL` 防死锁

## 交付检查

- 每个剧文件夹：封面（任意图片）+ 1.mp4 + 2.mp4 + 3.mp4
- 缺项补齐后再进入阶段 2
