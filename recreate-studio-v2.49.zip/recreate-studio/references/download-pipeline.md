# 素材获取流水线（原 asset-harvester v1.0，已并入 recreate-studio）

把"某站/某网盘上的一部剧/一个合集"自动落到本地：**建文件夹 → 只下点名文件 → 校验补齐 → 出报告**。

## 〇、判断来源

| 来源特征 | 路线 |
|---|---|
| 已登录网站（星图、后台、CMS），页面能点出下载 | **A. Playwright + Chrome CDP** 抓接口拿真实地址 |
| `pan.baidu.com/s/xxx` / 分享链接 + 提取码 | **B. BaiduPCS-Go** 转存 → 选择性下载 |
| 直链（`http(s)://...mp4`） | **C. curl / aria2c** 直接下 |

三条路线都不需要"破解"：只用账号已有权限、分享已给权限、或公开直链。付费墙/加密内容不做绕过。

## 一、通用流程

1. **确认清单**：要哪些文件（封面 + 前 N 集是常见组合）、根目录（如 `D:\碧海剧场`）、命名规则。
2. **拿目录结构**：先抓/列一遍远端目录，得到"剧名 → 文件列表"。
3. **建本地文件夹**：`<根>\NNN. <剧名>`（批量加 001. 前缀，保证排序）。
4. **只下点名文件**，不要整包（112 部全下会到几十 GB）。
5. **校验**：每个文件夹应有 封面图 + 1.mp4 + 2.mp4 + 3.mp4；缺失重试。
6. **出报告**：数量、体积、缺失清单，写入 `<根>\_下载报告.md` 和 CSV。

## 二、路线 A：登录态网站（Playwright + Chrome CDP）

**关键原则**：接口签名/风控由页面自己完成，**不要在页面外重放接口**；用 CDP 接管一个已登录的 Chrome，监听页面发出的响应。

1. 准备一个带登录态的 Chrome（见 `references/toolchain.md` 的三种做法，推荐 profile 副本 + `--remote-debugging-port=9333`）。
2. `playwright.chromium.connect_over_cdp("http://127.0.0.1:9333")`。
3. 监听 `page.on("response")`，把目标 API 的 URL → JSON 存起来。
4. 正常点页面（翻页也要点页面元素，让页面自己发请求）。
5. 从捕获的 JSON 里取列表/详情/下载地址；`demand.attachment_description` 这类字段常含网盘链接。
6. 分页：先点第 1 页，再逐页点 `1..N`；不要用 URL 参数硬翻。

星图实战字段与坑：`references/case-xingtu-2026-10-25.md`。

## 三、路线 B：百度网盘分享（BaiduPCS-Go）

```powershell
$exe = "D:\deepseek编程脚本\tools\BaiduPCS-Go\BaiduPCS-Go-v4.0.2-windows-x64\BaiduPCS-Go.exe"
& $exe login "-cookies=BDUSS=...; STOKEN=..."       # 只需一次
& $exe cd /漫剧
& $exe transfer "<分享链接>" "<提取码>"              # 转存到自己网盘
& $exe ls /漫剧/<剧名>                              # 看文件名
& $exe download --saveto "<本地文件夹>" -p 8 封面.jpg 1.mp4 2.mp4 3.mp4
```

要点：

- 分享目录可能带 `：共N集` 后缀、可能套层、可能分 `封面/`、`正片/《…》有字幕/`。
- 只下点名文件；下载用 `-p 8` 并发。
- Python 调用 BaiduPCS-Go 时：**必须 `stdout=DEVNULL, stderr=DEVNULL`**，否则进度条塞满管道会死锁（文件下完了进程还挂着）。
- 输出是 **GBK**：`decode("utf-8", "ignore")` 失败就 `decode("gbk", "ignore")`，否则"成功/文件重复"判断会错。

## 四、路线 C：直链

`curl -L -o "<文件>" "<url>"` 或 aria2c；大文件加 `--retry 5 --continue`。

## 五、目录与命名容错

- 目录：`<根>\NNN. <剧名>`；剧名去掉 `：共N集` 之类后缀。
- 封面：名字可能是 `封面.jpg`、`cover (1).jpg`、`1：1.png`；**只要扩展名是图片就接受**，优先含"封面/cover/海报"的。
- 套层：远端目录里再套同名目录（如 043）；需要递归下钻一层。
- 拆分：107 这类是 `封面/` + `正片/《…》有字幕/` 两级结构，要按实际路径下。

## 六、稳定性清单

| 问题 | 做法 |
|---|---|
| 进度条塞满管道 → 死锁 | 下载进程 `stdout=DEVNULL, stderr=DEVNULL` |
| GBK 输出乱码 | 先 utf-8 再 gbk 解码 |
| 目录行数量误判 | 正则 `(-|[\d.]+[KMG]?B)` 兼容目录的 `-` 大小 |
| 断点续跑 | 每部记录进度 JSON，已存在且大小一致就跳过 |
| 限流/失败 | 每文件重试 3 次，间隔 2s；失败写报告，不中断整批 |
| 页面翻页丢页 | 显式先点第 1 页，再逐页点数字 |

## 七、交付校验

```text
<根>/
├── 001. 剧名/
│   ├── 封面.jpg
│   ├── 1.mp4
│   ├── 2.mp4
│   └── 3.mp4
├── _清单_封面与前三集.csv
└── _下载报告.md
```

校验项：文件夹数 = 目标数；每部 4 个文件；总大小与报告一致；缺失清单为空。

## 八、安全边界

- 只处理自己账号、已授权、或公开可下的内容。
- 不绕过登录/付费墙/加密，不破解接口签名。
- 账号 Cookie 只在本机使用，不写进日志/技能文件、不外发。

## 九、环境依赖

- Playwright（`pip install playwright`，已有 Chrome 时 `connect_over_cdp` 不需要 `playwright install`）。
- BaiduPCS-Go v4.0.2（路径与哈希见 `references/toolchain.md`）。
- Python 3.10+（DSH 自带即可）。

## 十、版本 / 来源 / 回滚

- 版本：v1.0（2026-10-25）
- 来源：星图短剧推广任务 112 部素材实战（12.28 GB / 448 文件），含百度网盘分享转存与下载
- 回滚：`Remove-Item -Recurse C:\Users\Administrator\.dsh\skills\asset-harvester` + 删除记忆条目
- 详细命令与踩坑：`references/toolchain.md`、`references/case-xingtu-2026-10-25.md`

## 按集点名（跳集）

```bash
python harvester_template.py download --remote /漫剧/某剧 --local "D:\碧海剧场\001. 某剧" --eps 4,9,14 --cover 封面.jpg
```

- `--eps 3` = 1,2,3；`--eps 4,9,14` = 跳集；`--eps 3-6` = 连续区间
- 认 `4.mp4`、`第4集.mp4`、`EP04.mp4`、`14话.mp4` 这些命名
- 也可继续用 `--names 封面.jpg 4.mp4 9.mp4` 精确点名
