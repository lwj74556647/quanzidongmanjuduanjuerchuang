# recreate-studio

> 短剧素材 → **全自动二创成片**：封面片头、按台词完整句下刀、原声全保留、右上角水印、9:16 竖屏、约 180 秒。

给 AI agent（DeepSeek Harness skill 格式）使用，也可直接调用 `scripts/recreate.py`。

## 能实现什么

- **封面片头**：取素材目录里的封面图，铺满画布做 2.5 秒缓慢推近（`--no-cover` 可关）
- **按完整句下刀**：`faster-whisper`（medium）转写每条素材拿句级时间戳，候选段由连续完整句组成，**起点=句首、终点=句尾**，不切断人物台词；缓存 `<clip>.asr.json`，重剪秒级
- **高燃选段**：音频能量 0.6 + 画面运动 0.4 打分，挑 18–20 段，按强度由弱到强
- **原声全保留**：原声 1.0 主轨；BGM 0.12 由原声侧链闪避，台词不被压
- **字幕**：默认保留源片自带硬字幕，**不额外烧录**（避免重影/遮挡）；`--subtitles` 为实验选项（ASR 字幕）
- **水印**：右上角半透明账号水印（`--watermark "@账号"`）
- **音画同步**：每段强制 300 帧（10.000s）+ 音频 `apad/atrim` 等长；concat 视频 copy、音频重编码；不用 `loudnorm`
- **规格**：默认 9:16（1080×1920），可 `16:9`/`1:1`/`19:6`/`WxH`
- **批量**：`--root` 遍历，已有成片自动跳过，`--force` 重剪
- **报告**：JSON（时长/句级对齐/原声/水印/合规项/每段高燃分数）

## 目录结构

```
recreate-studio/
├── SKILL.md                      # 技能主文档（流程、校验、强制规则）
├── references/
│   ├── editing-recipe.md         # FFmpeg 配方：句级切点、封面片头、音轨链、字幕
│   ├── compliance-douyin.md      # 抖音二创审核要点与发布 SOP
│   ├── download-pipeline.md      # 内置下载流程（与独立技能同源）
│   ├── download-stage.md         # 下载速查
│   ├── toolchain.md              # Chrome CDP / BaiduPCS-Go 工具链
│   └── case-xingtu-2026-10-25.md # 星图实战字段与坑
├── scripts/
│   ├── recreate.py               # 核心渲染器
│   ├── launch_gui.py
│   ├── bootstrap_vlm.ps1       # 自动装 Ollama + 视觉模型             # 双击入口：选文件夹 + 水印/时长（路径不经 cmd）（含 BGM 来源清单与自动下载）
│   ├── harvester_template.py     # 下载模板（与 asset-harvester 同一份）
│   ├── quick_download.py         # 双击下载：网盘分享/直链
│   ├── 双击下载素材.bat            # 双击入口
│   ├── 双击剪辑文件夹.bat          # 拖入/粘贴文件夹即剪（推荐）
│   └── 一键二创_碧海剧场.bat        # 批量批处理
└── README.md
```

## 依赖

> **下载**：双击 `scripts/双击下载素材.bat`（首次自动装 15MB Python） 可选「网盘分享 / 直链」；登录站仍需 AI 用 Playwright CDP。**下载能力优先使用独立技能 `asset-harvester`**（阶段 0）；本包内置同源副本（download-pipeline/toolchain/case/模板）用于便携/离线兜底，两边模板保持同步。支持跳集 `--eps 4,9,14`。

| 依赖 | 说明 |
|---|---|
| Python 3.10+ | `numpy`、`faster-whisper`（句级切点必需） |
| FFmpeg / ffprobe | 6.0+，含 libx264/libass |
| ASR 模型 | 默认 `medium`（首次下载约 1.5GB，CPU 约 0.7x 实时） |
| BGM | 自备 7 种情绪 mp3（版权原因不附带） |
| 字体 | `C:\Windows\Fonts\msyh.ttc` |

```bash
pip install numpy faster-whisper
```

## BGM（内嵌自动部署）

- 解析顺序：`RECREATE_BGM_DIR` → 桌面 `漫剧短剧BGM库` → 技能 `assets/bgm`
- 目录为空时，`recreate.py` 用**内置的 39 首来源清单**从 Mixkit / Incompetech 直接下载（约 200MB），并生成 10 分类 + `index.json` 情绪映射
- 单独准备：`python scripts/recreate.py --setup-bgm`（`--bgm-limit 2` 可试跑）
- 许可：Mixkit 免署名可商用；Incompetech CC BY 4.0，成片需署名 `Kevin MacLeod (incompetech.com)`
- 仓库不附带音频文件

## 更自由的用法（不用改代码）

| 需求 | 做法 |
|---|---|
| 任意视频文件名 | 直接指向文件夹：自动识别 `mp4/mkv/mov/flv/ts/webm`，自然排序取前 3 个 |
| 明确指定哪几个 | `--clips "第01集.mp4" "EP02.mp4" "随便.mp4"` |
| 递归扫描根目录 | `--root "D:\素材" --recursive` |
| 成片输出到别处 | `--out "D:\成片输出"` |
| 自定义成片标题 | `--title "新标题"` |

## 新设备常见问题与兜底

| 问题 | 已处理 |
|---|---|
| 访问 python.org / PyPI / GitHub 慢 | Python 走华为/淘宝镜像；pip 失败自动切清华源；FFmpeg 先 GitHub 再 gyan |
| HuggingFace 连不上（ASR 模型） | 自动探测，失败切 `hf-mirror.com` |
| 包解压在只读目录（Program Files/U 盘） | runtime 自动改存 `%LOCALAPPDATA%\recreate-studio-runtime` |
| BGM 站点被墙/超时 | 连续 3 次失败自动跳过 BGM，照常出片 |
| 中文路径/空格 | 已支持；路径尽量别超 200 字符 |
| 32 位 Windows | 不支持（内置 Python/FFmpeg 为 64 位） |
| 完全离线 | 用便携包；ASR 模型可从他机复制 `%USERPROFILE%\.cache\huggingface\hub\models--Systran--faster-whisper-medium` |

## 新设备：解压即用（首次自动装环境）

1. 解压后双击 `scripts/启动并剪辑.bat`
2. 首次会自动把 Python、依赖、FFmpeg 下载到本包 `runtime\`（约 250MB，不污染系统）
3. 按提示确认/修改水印（默认 `@枫林晚`），再把素材文件夹拖进窗口回车
4. 首次剪辑还会自动下载 BGM（约 200MB）和 ASR 模型（约 1.5GB）

> 也可用离线便携包（含 runtime，不含 1.5GB 模型）：解压后直接双击同一个 bat。

## 双击就能剪（不用命令行）

1. 双击 `scripts/双击剪辑文件夹.bat`
2. 把素材文件夹拖进黑窗口，回车
3. 或用右键：把 bat 复制到 `%APPDATA%\Microsoft\Windows\SendTo`，之后右键任意文件夹 → 发送到 → 双击剪辑文件夹

自动判断：文件夹里直接有视频 → 剪这一部；只有子文件夹 → 批量递归。
可选参数：`双击剪辑文件夹.bat "文件夹" "@水印" 180`

## 用法

```bash
# 单部
python scripts/recreate.py --folder "<LIBRARY_ROOT>/001. 剧名" --watermark "@你的账号"

# 批量
python scripts/recreate.py --root "<LIBRARY_ROOT>" --watermark "@你的账号"
```

Windows 双击/命令行：

```bat
一键二创_碧海剧场.bat "D:\碧海剧场" 1 force
```

| 参数 | 说明 |
|---|---|
| `--folder` / `--root` | 单部 / 批量 |
| `--aspect` | `9:16`（默认）/`16:9`/`1:1`/`19:6`/`WxH` |
| `--duration` | 目标秒数（默认 180） |
| `--watermark` | 水印文案（右上角） |
| `--subtitles` | 额外烧录 ASR 字幕（默认关，保留源字幕） |
| `--tts` | 加 AI 解说（默认关） |
| `--no-cover` | 不用封面片头 |
| `--keep-src-subs` | 不铺字幕条（配合 `--subtitles` 时用） |
| `--force` | 覆盖已有成片 |

环境变量：`RECREATE_FFMPEG`、`RECREATE_FFPROBE`、`RECREATE_BGM_DIR`、`RECREATE_FONT`、`RECREATE_ASR_MODEL`。

## 输出

```
<素材文件夹>/
├── <剧名>_二创_3min.mp4
├── <剧名>_二创_报告.json
└── *.mp4.asr.json      # ASR 缓存，可复用
```

## 合规提醒

只处理自己账号、已获授权或平台允许推广的素材；含 AI 合成内容按平台要求勾选「内容由AI生成」；不承诺 100% 过审。

## 版本

- **v2.4（2026-10-27）**：合并 asset-harvester v1.0——下载流水线（Playwright CDP / BaiduPCS-Go / 直链、目录命名容错、断点续跑、下载报告）
- v2.3：网络镜像/只读目录/BGM 超时兜底
- v2.2：所有 bat 首次运行都会自动装环境；双击后先改水印
- v2.1：新设备首次运行自动装 Python/依赖/FFmpeg；启动时提示改水印
- v2.0：自由输入（任意文件名 / --clips / --out / --recursive / --title）
- v1.9：随机化去重（时长/fps/段长/缩放/调色/颗粒/水印字号），同素材每次成片不同
- v1.8：单文件脚本，BGM 来源清单与下载逻辑内嵌
- v1.6：句级切点（ASR medium）、原声 1.0 全保留 + BGM 侧链闪避、默认保留源字幕不烧录、水印右上角
- v1.3：音画同步修复（300 帧/段、音频等长、concat 音频重编码、去 loudnorm）
- v1.2：封面片头、高燃选段
- v1.0：下载 + 二创基础流水线

## License

暂未声明许可证；如需开源建议补 MIT。
