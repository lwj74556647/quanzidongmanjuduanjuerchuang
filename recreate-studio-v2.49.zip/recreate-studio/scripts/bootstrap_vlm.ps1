﻿param(
    [Parameter(Mandatory=$true)][string]$Root,
    [string]$Model = "qwen2.5vl:7b"
)
$ErrorActionPreference = "Continue"
$ProgressPreference = "SilentlyContinue"
try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 } catch { }
if (-not [Environment]::Is64BitOperatingSystem) { Write-Host "[fatal] 需要 64 位 Windows"; exit 9 }

$runtime = Join-Path $Root "runtime"
New-Item -ItemType Directory -Force -Path $runtime | Out-Null
try {
    $free = (Get-PSDrive ((Get-Item $runtime).PSDrive.Name)).Free
    if ($free -lt 8GB) { Write-Host "[fatal] 磁盘不足 8GB（视觉模型约 5GB + Ollama）"; exit 8 }
} catch { }

function Find-Ollama {
    if ($env:OLLAMA_EXE -and (Test-Path $env:OLLAMA_EXE)) { return $env:OLLAMA_EXE }
    $c = Get-Command ollama -ErrorAction SilentlyContinue
    if ($c) { return $c.Source }
    $cands = @()
    if ($env:LOCALAPPDATA) { $cands += Join-Path $env:LOCALAPPDATA "Programs\Ollama\ollama.exe" }
    if ($env:ProgramFiles) { $cands += Join-Path $env:ProgramFiles "Ollama\ollama.exe" }
    if (${env:ProgramFiles(x86)}) { $cands += Join-Path ${env:ProgramFiles(x86)} "Ollama\ollama.exe" }
    foreach ($p in $cands) { if ($p -and (Test-Path $p)) { return $p } }
    return $null
}

$ollama = Find-Ollama
if (-not $ollama) {
    Write-Host "[install] 下载 Ollama 安装包（约 1GB）..."
    $exe = Join-Path $runtime "OllamaSetup.exe"
    $urls = @(
        "https://ollama.com/download/OllamaSetup.exe",
        "https://github.com/ollama/ollama/releases/latest/download/OllamaSetup.exe"
    )
    $ok = $false
    foreach ($u in $urls) {
        try {
            Invoke-WebRequest -Uri $u -OutFile $exe -UseBasicParsing -TimeoutSec 1800
            if ((Get-Item $exe).Length -gt 10MB) { $ok = $true; break }
        } catch { Write-Host "[warn] 下载失败：$u" }
    }
    if (-not $ok) { Write-Host "[fatal] Ollama 下载失败，请手动安装后重试"; exit 1 }
    Write-Host "[install] 静默安装 Ollama..."
    Start-Process -FilePath $exe -ArgumentList "/S" -Wait
    Start-Sleep -Seconds 5
    Remove-Item $exe -Force -ErrorAction SilentlyContinue
    $ollama = Find-Ollama
    if (-not $ollama) { Write-Host "[fatal] Ollama 安装后仍未找到，请手动安装"; exit 2 }
}

# 启动服务
$api = "http://127.0.0.1:11434/api/tags"
function Test-Api {
    try { Invoke-WebRequest -Uri $api -UseBasicParsing -TimeoutSec 3 | Out-Null; return $true } catch { return $false }
}
if (-not (Test-Api)) {
    Write-Host "[serve] 启动 Ollama 服务..."
    Start-Process -FilePath $ollama -ArgumentList "serve" -WindowStyle Hidden
    for ($i = 0; $i -lt 30; $i++) {
        Start-Sleep -Seconds 2
        if (Test-Api) { break }
    }
}
if (-not (Test-Api)) { Write-Host "[fatal] Ollama 服务启动失败（端口 11434）"; exit 3 }

Write-Host "[pull] 下载视觉模型 $Model（约 5GB，首次较慢）..."
$pulled = $false
for ($try = 1; $try -le 3; $try++) {
    $proc = Start-Process -FilePath $ollama -ArgumentList @("pull", $Model) -NoNewWindow -PassThru
    $done = $false
    try { $proc | Wait-Process -Timeout 1800 -ErrorAction Stop; $done = $true } catch { }
    if (-not $done) {
        Write-Host "[warn] 下载超过 30 分钟，已终止本次尝试"
        try { Stop-Process -Id $proc.Id -Force -ErrorAction SilentlyContinue } catch { }
    } else {
        $proc.Refresh()
        if ($proc.ExitCode -eq 0) { $pulled = $true; break }
    }
    Write-Host "[warn] 第 $try 次下载失败，10 秒后重试..."
    Start-Sleep -Seconds 10
}
if (-not $pulled) { Write-Host "[fatal] 模型下载失败（网络/磁盘），可稍后重试；也可设置代理后重跑"; exit 4 }

Set-Content -Path (Join-Path $Root "vlm_ready.txt") -Value $Model -Encoding UTF8
Write-Host "[ready] 视觉审核模型就绪：$Model"
exit 0
