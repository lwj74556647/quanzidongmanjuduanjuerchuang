# -*- coding: utf-8 -*-
"""asset-harvester 双击入口：网盘分享 / 直链。登录站请让 AI 跑 Playwright CDP。"""
import os, sys, subprocess, json, re
try:
    import license_guard as _lic
except Exception:
    _lic = None

HERE = os.path.dirname(os.path.abspath(__file__))
try:
    from path_utils import find_baidupcs as _find_pcs
except Exception:
    _find_pcs = lambda: ""
PCS = os.environ.get("BAIDUPCS_GO") or _find_pcs()
DRY = os.environ.get("QUICK_DRY") == "1"


def norm(p):
    p = (p or "").strip().strip('"').strip("'")
    p = os.path.expanduser(p)
    p = os.path.abspath(p)
    if len(p) > 3:
        p = p.rstrip("\\/")
    return p


def safe_name(name):
    name = re.sub(r'[<>:"/\\|?*\x00-\x1f]', "_", name or "").strip(" .")
    return name or "untitled"


def pick_folder(title="选择保存文件夹"):
    ps = ("Add-Type -AssemblyName System.Windows.Forms;"
          "$d=New-Object System.Windows.Forms.FolderBrowserDialog;"
          f"$d.Description='{title}';"
          "if($d.ShowDialog() -eq 'OK'){[Console]::OutputEncoding=[Text.Encoding]::UTF8;"
          "Write-Output $d.SelectedPath}")
    try:
        p = subprocess.run(["powershell", "-NoProfile", "-STA", "-Command", ps],
                           capture_output=True, timeout=300)
        return p.stdout.decode("utf-8", "ignore").strip()
    except Exception:
        return ""


def check_space(path, need_mb=500):
    try:
        free = __import__("shutil").disk_usage(path).free
        if free < need_mb * 1048576:
            print(f"[错误] 磁盘剩余不足 {need_mb}MB（当前 {free // 1048576}MB）"); return False
    except Exception:
        pass
    return True

def run(cmd, **kw):
    if DRY:
        print("[dry]", " ".join(cmd)); return 0, ""
    p = subprocess.run(cmd, capture_output=True, **kw)
    try:
        out = p.stdout.decode("utf-8")
    except UnicodeDecodeError:
        out = p.stdout.decode("gbk", "ignore")
    return p.returncode, out

def ask(prompt, default=""):
    v = input(prompt).strip()
    return v or default

def direct():
    urls = []
    print("粘贴直链，每行一个，空行结束：")
    while True:
        u = input().strip()
        if not u: break
        urls.append(u)
    local = ask("保存到文件夹（空=弹窗选择）: ", "")
    if not local:
        local = pick_folder("选择直链保存文件夹") or os.path.join(os.path.expanduser("~"), "Desktop", "素材下载")
    local = norm(local)
    if len(local) > 240:
        print("[警告] 路径过长，Windows 下可能失败：", local)
    try:
        os.makedirs(local, exist_ok=True)
    except OSError as e:
        print("[错误] 无法创建目录：", e); return
    if not check_space(local):
        return
    for u in urls:
        name = safe_name(os.path.basename(u.split("?")[0])) or "video.mp4"
        dst = os.path.join(local, name)
        print("下载", u, "->", dst)
        rc, _ = run(["curl.exe", "-L", "--retry", "3", "--continue", "-o", dst, u])
        print("  完成" if rc == 0 else f"  失败 rc={rc}")

def netdisk():
    link = ask("网盘分享链接: ")
    pwd = ask("提取码（没有就直接回车）: ")
    title = ask("剧名（用于建文件夹）: ")
    eps = ask("要哪几集（如 4,9,14 或 3）: ", "3")
    root = ask("保存根目录（空=弹窗选择，默认 D:\\碧海剧场）: ", "")
    if not root:
        root = pick_folder("选择保存根目录") or r"D:\碧海剧场"
    root = norm(root)
    title = safe_name(title)
    if not (link and title): print("链接和剧名必填"); return
    try:
        os.makedirs(root, exist_ok=True)
    except OSError as e:
        print("[错误] 无法创建根目录：", e); return
    if not check_space(root, 1000):
        return
    if not os.path.isfile(PCS):
        print("[错误] 没找到 BaiduPCS-Go：", PCS)
        print("可设置环境变量 BAIDUPCS_GO 指向 exe"); return
    if re.match(r"^\d+\.", title):
        local = os.path.join(root, title)
    else:
        nums = [int(m.group(1)) for m in (re.match(r"^(\d+)\.", d) for d in os.listdir(root)) if m]
        local = os.path.join(root, f"{(max(nums)+1 if nums else 1):03d}. {title}")
    os.makedirs(local, exist_ok=True)
    print("转存中...")
    rc, out = run([PCS, "transfer", link, pwd] if pwd else [PCS, "transfer", link])
    print(out.strip()[:300])
    # 在根目录下找刚转存的目录
    rc, listing = run([PCS, "ls", "/"])
    target = None
    for line in listing.splitlines():
        if title in line: target = "/" + title; break
    if not target:
        target = ask("没自动找到远端目录，请粘贴远端路径（如 /漫剧/某剧）: ")
    if not target: print("缺远端路径，退出"); return
    print("远端:", target)
    cmd = [sys.executable, os.path.join(HERE, "harvester_template.py"), "download",
           "--remote", target, "--local", local, "--eps", eps, "--cover", "封面.jpg"]
    rc, out = run(cmd)
    print(out.strip()[-500:])
    print("完成，目录：", local)

def main():
    if _lic is not None and not _lic.require_license(interactive=sys.stdin.isatty()):
        return
    print("=" * 50)
    print(" asset-harvester 双击下载")
    print(" 1. 百度网盘分享（转存 + 下载指定集）")
    print(" 2. 公开直链")
    print(" 0. 退出（登录站请让 AI 用 Chrome CDP）")
    print("=" * 50)
    try:
        c = input("选择: ").strip()
    except EOFError:
        return
    if c == "1": netdisk()
    elif c == "2": direct()
    else: print("退出")

if __name__ == "__main__":
    main()
