@echo off
setlocal EnableExtensions
chcp 936 >nul 2>&1
set "PYTHONUTF8=1"
set "PYTHONIOENCODING=utf-8"
title asset-harvester ˫������
set "ROOT=%~dp0.."
for %%I in ("%ROOT%") do set "ROOT=%%~fI"
call :ENSURE_ENV
if not defined PY ( echo [����] Python ׼��ʧ�ܣ����������·�� & pause & exit /b 1 )
"%PY%" "%~dp0license_gate.py"
if errorlevel 1 (
    echo [��Ȩ] δͨ�������˳���
    pause
    exit /b 2
)
"%PY%" "%~dp0quick_download.py"
echo.
pause
exit /b 0

:ENSURE_ENV
set "PY="
set "RT=%ROOT%\runtime"
if exist "%ROOT%\runtime\python\python.exe" set "RT=%ROOT%\runtime"
if exist "%ROOT%\runtime\python\python.exe" set "PY=%ROOT%\runtime\python\python.exe"
if not defined PY if exist "%ROOT%\runtime_path.txt" set /p RT=<"%ROOT%\runtime_path.txt"
if not defined PY if exist "%RT%\python\python.exe" set "PY=%RT%\python\python.exe"
if not defined PY if exist "%LOCALAPPDATA%\recreate-studio-runtime\python\python.exe" set "RT=%LOCALAPPDATA%\recreate-studio-runtime"
if not defined PY if exist "%LOCALAPPDATA%\recreate-studio-runtime\python\python.exe" set "PY=%LOCALAPPDATA%\recreate-studio-runtime\python\python.exe"
if not defined PY if exist "%LOCALAPPDATA%\recreate-studio\python\python.exe" set "PY=%LOCALAPPDATA%\recreate-studio\python\python.exe"
if not defined PY for /f "delims=" %%P in ('where python 2^>nul') do if not defined PY set "PY=%%P"
if defined PY exit /b 0
echo [����] �״����У�׼����Я Python��Լ 15MB��...
set "BOOT=%~dp0bootstrap.ps1"
if not exist "%BOOT%" if exist "%ROOT%\bootstrap.ps1" set "BOOT=%ROOT%\bootstrap.ps1"
if not exist "%BOOT%" if exist "%~dp0..\scripts\bootstrap.ps1" set "BOOT=%~dp0..\scripts\bootstrap.ps1"
if not exist "%BOOT%" (
    echo [����] ȱ�� bootstrap.ps1����װ����������
    echo ��ȷ�� scripts\bootstrap.ps1 ���ڣ������½�ѹ��������
    pause
    exit /b 1
)
powershell -NoProfile -ExecutionPolicy Bypass -File "%BOOT%" -Root "%ROOT%" -Mode lite
set "PY="
set "RT=%ROOT%\runtime"
if exist "%ROOT%\runtime\python\python.exe" set "PY=%ROOT%\runtime\python\python.exe"
if not defined PY if exist "%ROOT%\runtime_path.txt" set /p RT=<"%ROOT%\runtime_path.txt"
if not defined PY if exist "%RT%\python\python.exe" set "PY=%RT%\python\python.exe"
if not defined PY if exist "%LOCALAPPDATA%\recreate-studio-runtime\python\python.exe" set "RT=%LOCALAPPDATA%\recreate-studio-runtime"
if not defined PY if exist "%LOCALAPPDATA%\recreate-studio-runtime\python\python.exe" set "PY=%LOCALAPPDATA%\recreate-studio-runtime\python\python.exe"
exit /b 0
