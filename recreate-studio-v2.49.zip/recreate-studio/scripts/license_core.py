# -*- coding: utf-8 -*-
"""recreate-studio 授权核心：机器码 + RSA 签名验证（公钥内置，私钥只在管理员工具）。"""
import base64, hashlib, json, os, time

PUB_N = int("22922867096616670683239045676644326748187320547317602115173086996674119403894442029416756217986148120679893881626130739801386023877258915229918115045955690942312454524660722106348224077508292677430765353138534163173021788163990657508276209246024446940521779317861239423339885994855391598245893575333890407105078911632469849006616819679063813398946395356794104107638795196390415586999535670052828703270831731088848022937218350196920447666579807994747059285448119142747204247608949482275328462427771641032889114582818349400478371658763652526627732873628212237946949314491553704645977073633245541299594170662044928814219")
PUB_E = 65537
_DIGEST_PREFIX = bytes.fromhex("3031300d060960864801650304020105000420")


def b64e(b):
    return base64.urlsafe_b64encode(b).decode().rstrip("=")


def b64d(s):
    return base64.urlsafe_b64decode(s + "=" * (-len(s) % 4))


def _machine_guid():
    try:
        import winreg
        k = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Cryptography")
        v, _ = winreg.QueryValueEx(k, "MachineGuid")
        return str(v)
    except Exception:
        return ""


def _volume_serial():
    try:
        import ctypes
        from ctypes import wintypes
        k32 = ctypes.windll.kernel32
        vol = wintypes.DWORD()
        fs = wintypes.DWORD()
        k32.GetVolumeInformationW("C:\\", None, 0, ctypes.byref(vol), ctypes.byref(fs), None, 0)
        return "{:08X}".format(vol.value)
    except Exception:
        return ""


def machine_id():
    raw = "|".join([_machine_guid(), _volume_serial(), os.environ.get("COMPUTERNAME", "")])
    return hashlib.sha256(raw.encode("utf-8", "ignore")).hexdigest()[:32]


def _emsa(h):
    k = (PUB_N.bit_length() + 7) // 8
    t = _DIGEST_PREFIX + h
    ps = b"\xff" * (k - len(t) - 3)
    return b"\x00\x01" + ps + b"\x00" + t


def verify_code(code):
    """返回 payload dict；失败抛 ValueError。"""
    parts = (code or "").strip().split(".")
    if len(parts) != 3 or parts[0] != "RS1":
        raise ValueError("授权码格式不对")
    payload, sig = b64d(parts[1]), b64d(parts[2])
    if len(sig) != (PUB_N.bit_length() + 7) // 8:
        raise ValueError("授权码签名长度不对")
    em = pow(int.from_bytes(sig, "big"), PUB_E, PUB_N).to_bytes(len(sig), "big")
    if em != _emsa(hashlib.sha256(payload).digest()):
        raise ValueError("授权码无效（签名校验失败）")
    data = json.loads(payload.decode("utf-8"))
    if data.get("v") != 1:
        raise ValueError("授权码版本不支持")
    return data


def check_payload(data, now=None):
    now = int(now or time.time())
    kind = data.get("k")
    if kind == "invite":
        return True
    if kind == "owner":
        if data.get("m") != machine_id():
            raise ValueError("此授权码不属于本机")
        return True
    if kind != "machine":
        raise ValueError("授权码类型未知")
    if data.get("m") != machine_id():
        raise ValueError("此授权码不属于本机，请把本机机器码发给管理员重新生成")
    if data.get("s") and now < int(data["s"]):
        raise ValueError("授权码尚未生效（生效时间 " + time.strftime("%Y-%m-%d %H:%M", time.localtime(int(data["s"]))) + "）")
    if data.get("e") and now > int(data["e"]):
        raise ValueError("授权码已过期（到期 " + time.strftime("%Y-%m-%d %H:%M", time.localtime(int(data["e"]))) + "）")
    return True


def read_token(path):
    try:
        with open(path, encoding="utf-8") as f:
            return f.read().strip()
    except Exception:
        return ""
