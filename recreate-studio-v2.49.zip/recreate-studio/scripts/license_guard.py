# -*- coding: utf-8 -*-
"""recreate-studio 授权门禁：本机授权文件 / 永久邀请码 / 管理员 owner 免授权。"""
import json, os, sys, time
from license_core import (machine_id, verify_code, check_payload, read_token)

APP = "recreate-studio"


def storage_dir():
    base = os.environ.get("LOCALAPPDATA") or os.path.join(os.path.expanduser("~"), "AppData", "Local")
    d = os.path.join(base, APP)
    os.makedirs(d, exist_ok=True)
    return d


def license_path():
    return os.path.join(storage_dir(), "license.json")


def owner_path():
    return os.path.join(storage_dir(), "owner.json")


def last_seen_path():
    return os.path.join(storage_dir(), "last_seen.txt")


def _save_code(code):
    with open(license_path(), "w", encoding="utf-8") as f:
        json.dump({"code": code, "saved": int(time.time())}, f, ensure_ascii=False)


def _load_code():
    try:
        return json.load(open(license_path(), encoding="utf-8")).get("code", "")
    except Exception:
        return ""


def _anti_rollback(now):
    try:
        last = int(open(last_seen_path(), encoding="utf-8").read().strip() or 0)
    except Exception:
        last = 0
    if last and now < last - 86400:
        raise ValueError("检测到系统时间被回拨，请把系统时间调回正确时间后再试")
    try:
        open(last_seen_path(), "w", encoding="utf-8").write(str(now))
    except OSError:
        pass


def check_code(code, now=None):
    data = verify_code(code)
    check_payload(data, now)
    return data


def owner_ok():
    tok = read_token(owner_path())
    if not tok:
        return False
    try:
        data = verify_code(tok)
        return data.get("k") == "owner" and data.get("m") == machine_id()
    except Exception:
        return False


def activate(code):
    data = check_code(code)
    _save_code(code.strip())
    _anti_rollback(int(time.time()))
    return data


def current_ok():
    if owner_ok():
        return True
    code = _load_code()
    if not code:
        return False
    try:
        check_code(code)
        _anti_rollback(int(time.time()))
        return True
    except Exception:
        return False


def require_license(interactive=None):
    """返回 True/False；交互模式下最多让用户输 3 次。"""
    if current_ok():
        return True
    if interactive is None:
        interactive = sys.stdin.isatty()
    mid = machine_id()
    print("=" * 58, flush=True)
    print("recreate-studio 未授权 / 授权已过期", flush=True)
    print("本机机器码：", mid, flush=True)
    print("把机器码发给管理员，换取本机授权码；或输入永久邀请码。", flush=True)
    print("=" * 58, flush=True)
    if not interactive:
        print("非交互环境请先运行：recreate.py --license 授权码", flush=True)
        return False
    for _ in range(3):
        try:
            code = input("请输入授权码（回车退出）: ").strip()
        except (EOFError, KeyboardInterrupt):
            return False
        if not code:
            return False
        try:
            activate(code)
            data = verify_code(code)
            print("授权成功，有效期至：", "永久" if not data.get("e") else time.strftime("%Y-%m-%d %H:%M", time.localtime(int(data["e"]))), flush=True)
            return True
        except Exception as e:
            print("授权失败：", e, flush=True)
    return False
