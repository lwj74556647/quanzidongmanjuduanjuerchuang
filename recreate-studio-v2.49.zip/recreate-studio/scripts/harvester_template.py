# -*- coding: utf-8 -*-
"""asset-harvester v1.0 模板脚本

用法示例：
  python harvester_template.py verify --root "D:\\碧海剧场"
  python harvester_template.py ls --remote "/漫剧/001. 毒酒换红妆" --save "D:\\碧海剧场\\001. 毒酒换红妆"
  python harvester_template.py download --remote "/漫剧/001. 毒酒换红妆" --local "D:\\碧海剧场\\001. 毒酒换红妆"
  python harvester_template.py capture --url "https://www.xingtu.cn/sup/creator/user/task" --seconds 8 --out dump.json
"""
import argparse
import json
import os
import re
import subprocess
import sys

try:
    from path_utils import find_baidupcs as _find_pcs
except Exception:
    _find_pcs = lambda: ""
PCS = os.environ.get("HARVEST_PCS") or os.environ.get("BAIDUPCS_GO") or _find_pcs()
CDP = os.environ.get("HARVEST_CDP", "http://127.0.0.1:9333")
IMG_EXT = {".jpg", ".jpeg", ".png", ".webp", ".bmp"}
LINE = re.compile(r"^\s*\d+\s+(-|[\d.]+[KMG]?B)\s+(\d{4}-\d{2}-\d{2})\s+(\d{2}:\d{2}:\d{2})\s+(.+)$")


def decode(data):
    for enc in ("utf-8", "gbk"):
        try:
            return data.decode(enc)
        except UnicodeDecodeError:
            continue
    return data.decode("utf-8", "ignore")


def run(cmd, timeout=1800):
    """下载/查询统一走这里：DEVNULL 防止进度条塞满管道死锁。"""
    r = subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                       timeout=timeout)
    return r.returncode


def pcs(*args, timeout=1800):
    if not PCS or not os.path.isfile(PCS):
        raise SystemExit("未找到 BaiduPCS-Go，请放到包内 tools/BaiduPCS-Go/ 或设置 BAIDUPCS_GO")
    return run([PCS, *args], timeout=timeout)


def pcs_out(*args, timeout=120):
    r = subprocess.run([PCS, *args], timeout=timeout,
                       stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    return r.returncode, decode(r.stdout or b"")


def parse_ls(text):
    rows = []
    for line in text.splitlines():
        m = LINE.match(line)
        if not m:
            continue
        size = m.group(1)
        raw = m.group(4).strip()
        if raw in (".", ".."):
            continue
        is_dir = raw.endswith("/") or size == "-"
        rows.append({"name": raw.rstrip("/"), "dir": bool(is_dir), "size": size})
    return rows


def pick_cover(names):
    """封面命名不统一：封面/cover/海报优先，任意图片兜底。"""
    imgs = [n for n in names if os.path.splitext(n)[1].lower() in IMG_EXT]
    for n in imgs:
        low = n.lower()
        if any(k in low for k in ("封面", "cover", "海报", "poster")):
            return n
    return imgs[0] if imgs else None


def episode_map(names):
    """收集集号：1.mp4 / 第4集.mp4 / EP09.mp4 / 14话.mp4 都认。"""
    eps = {}
    for n in names:
        stem = re.sub(r"\.(mp4|mkv|mov)$", "", n, flags=re.I)
        m = re.match(r"^(?:第|ep|e)?\s*0*(\d{1,4})\s*(?:集|话|期)?$", stem, re.I)
        if m:
            eps.setdefault(int(m.group(1)), n)
    return eps


def parse_eps(spec):
    """'3' → 1,2,3；'4,9,14' → 4,9,14；'3-6' → 3,4,5,6；也接受 '第4集,第9集'。"""
    if isinstance(spec, int):
        return list(range(1, spec + 1))
    out = set()
    for part in str(spec).replace("，", ",").split(","):
        part = part.strip()
        if not part:
            continue
        part = re.sub(r"^(第|ep|e)?\s*|\s*(集|话|期)?$", "", part, flags=re.I)
        if "-" in part:
            a, b = part.split("-", 1)
            out.update(range(int(a), int(b) + 1))
        else:
            out.add(int(part))
    return sorted(out)


def verify_folder(folder, want_eps="3"):
    files = os.listdir(folder) if os.path.isdir(folder) else []
    cover = pick_cover(files)
    eps = episode_map(files)
    missing = [f"{i}.mp4" for i in parse_eps(want_eps) if i not in eps]
    return {"folder": folder, "cover": cover, "episodes": sorted(eps),
            "missing": missing, "ok": bool(cover) and not missing}


def verify_root(root, want_eps="3"):
    outs = []
    for name in sorted(os.listdir(root)):
        p = os.path.join(root, name)
        if os.path.isdir(p) and os.path.isfile(os.path.join(p, "1.mp4")):
            outs.append(verify_folder(p, want_eps))
    bad = [o for o in outs if not o["ok"]]
    return {"total": len(outs), "ok": len(outs) - len(bad), "bad": bad}


def download_selected(remote_dir, local_dir, cover=None, episodes="3", timeout=1800):
    """严格按需下载：封面 + 第 1..episodes 集。
    逐个文件下载到临时目录再移动，避免 PCS 对多参数时把整目录拉下来。"""
    import shutil, tempfile
    rc, text = pcs_out("ls", remote_dir)
    files = [r["name"] for r in parse_ls(text) if not r["dir"]]
    eps = episode_map(files)
    want = []
    if cover and cover in files:
        want.append(cover)
    for i in parse_eps(episodes):
        if i in eps:
            want.append(eps[i])
    os.makedirs(local_dir, exist_ok=True)
    got = []
    with tempfile.TemporaryDirectory(prefix="pcs_") as tmp:
        for name in want:
            rc = pcs("download", "--saveto", tmp, "-p", "8",
                     remote_dir.rstrip("/") + "/" + name, timeout=timeout)
            src = os.path.join(tmp, name)
            if os.path.isfile(src):
                dst = os.path.join(local_dir, name)
                shutil.move(src, dst)
                got.append(name)
    missing = [n for n in want if n not in got]
    return {"want": want, "got": got, "missing": missing}


def capture_responses(url, seconds=8, out="dump.json", needle="/gw/api/"):
    """接管已登录 Chrome，抓页面响应。需 pip install playwright。"""
    from playwright.sync_api import sync_playwright

    with sync_playwright() as p:
        browser = p.chromium.connect_over_cdp(CDP)
        ctx = browser.contexts[0]
        page = ctx.pages[0] if ctx.pages else ctx.new_page()
        store = {}

        def on_resp(resp):
            try:
                if needle in resp.url:
                    store[resp.url] = resp.text()
            except Exception:
                pass

        page.on("response", on_resp)
        page.goto(url)
        page.wait_for_timeout(int(seconds * 1000))
        with open(out, "w", encoding="utf-8") as f:
            json.dump(store, f, ensure_ascii=False, indent=1)
        return len(store)


def main():
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)

    v = sub.add_parser("verify")
    v.add_argument("--root", required=True)
    v.add_argument("--eps", default="3", help="1-3 或 4,9,14 或 3-6")

    l = sub.add_parser("ls")
    l.add_argument("--remote", required=True)
    l.add_argument("--save")

    d = sub.add_parser("download")
    d.add_argument("--remote", required=True)
    d.add_argument("--local", required=True)
    d.add_argument("--names", nargs="*")
    d.add_argument("--eps", default="3", help="1-3 或 4,9,14 或 3-6")
    d.add_argument("--cover", default="封面.jpg")

    c = sub.add_parser("capture")
    c.add_argument("--url", required=True)
    c.add_argument("--seconds", type=int, default=8)
    c.add_argument("--out", default="dump.json")

    a = ap.parse_args()
    if a.cmd == "verify":
        print(json.dumps(verify_root(a.root, a.eps), ensure_ascii=False, indent=1))
    elif a.cmd == "ls":
        rc, text = pcs_out("ls", a.remote)
        rows = parse_ls(text)
        print(json.dumps(rows, ensure_ascii=False, indent=1))
        if a.save:
            names = [r["name"] for r in rows if not r["dir"]]
            targets = [n for n in [pick_cover(names)] if n] + \
                      [f"{i}.mp4" for i in sorted(episode_map(names))]
            os.makedirs(a.save, exist_ok=True)
            with open(os.path.join(a.save, "_download_list.json"), "w", encoding="utf-8") as f:
                json.dump(targets, f, ensure_ascii=False, indent=1)
    elif a.cmd == "download":
        if a.names:
            rc = pcs("download", "--saveto", a.local, "-p", "8", *a.names)
            print(json.dumps({"rc": rc, "names": a.names}, ensure_ascii=False))
        else:
            print(json.dumps(download_selected(a.remote, a.local, a.cover, a.eps),
                             ensure_ascii=False))
    elif a.cmd == "capture":
        n = capture_responses(a.url, a.seconds, a.out)
        print(json.dumps({"responses": n, "out": a.out}, ensure_ascii=False))


if __name__ == "__main__":
    main()