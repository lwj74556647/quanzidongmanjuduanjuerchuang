# -*- coding: utf-8 -*-
"""所有双击入口的统一授权门禁。已授权/未到期直接放行，不重复提示。"""
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

try:
    import license_guard as g
except Exception as e:
    print("=" * 58, flush=True)
    print("[授权] 授权组件缺失或损坏，无法启动。", flush=True)
    print("请确认 scripts 目录下同时存在：", flush=True)
    print("  license_core.py", flush=True)
    print("  license_guard.py", flush=True)
    print("错误：", e, flush=True)
    print("=" * 58, flush=True)
    sys.exit(3)

if g.current_ok():
    sys.exit(0)

if g.require_license(interactive=True):
    sys.exit(0)

sys.exit(2)