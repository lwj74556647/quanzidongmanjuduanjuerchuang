# -*- coding: utf-8 -*-
"""recreate-studio 图形入口：路径不经过 cmd，支持中文/空格/! % 等特殊字符。"""
import argparse, os, subprocess, sys, tempfile
try:
    import license_guard as _lic
except Exception:
    _lic = None

HERE = os.path.dirname(os.path.abspath(__file__))
RENDER = os.path.join(HERE, "recreate.py")


def pick_folder():
    ps = (
        "Add-Type -AssemblyName System.Windows.Forms;"
        "$d=New-Object System.Windows.Forms.FolderBrowserDialog;"
        "$d.Description='选择素材文件夹';"
        "if($d.ShowDialog() -eq 'OK'){[Console]::OutputEncoding=[Text.Encoding]::UTF8;"
        "Write-Output $d.SelectedPath}"
    )
    try:
        p = subprocess.run(["powershell", "-NoProfile", "-STA", "-Command", ps],
                           capture_output=True, timeout=300)
        out = p.stdout.decode("utf-8", "ignore").strip() or p.stdout.decode("gbk", "ignore").strip()
        return out
    except Exception:
        return ""


def ask(prompt, default=""):
    try:
        v = input(prompt).strip()
    except (EOFError, KeyboardInterrupt):
        v = ""
    return v or default


def norm(p):
    p = (p or "").strip().strip('"').strip("'")
    if not p:
        return ""
    p = os.path.expanduser(p)
    p = os.path.abspath(p)
    if len(p) > 3:
        p = p.rstrip("\\/")
    return p


def vlm_missing():
    import json as _json
    import os as _os
    import urllib.request
    try:
        with urllib.request.urlopen("http://127.0.0.1:11434/api/tags", timeout=2) as r:
            names = [m.get("name", "") for m in _json.loads(r.read()).get("models", [])]
        if any(n.startswith("qwen2.5vl") for n in names):
            return False
    except Exception:
        pass
    # 服务没起时，用模型清单判断（避免误报未安装）；支持 OLLAMA_MODELS/自定义目录
    rel = _os.path.join("manifests", "registry.ollama.ai", "library", "qwen2.5vl", "7b")
    roots = []
    if _os.environ.get("OLLAMA_MODELS"):
        roots.append(_os.environ["OLLAMA_MODELS"])
    roots += [
        _os.path.join(_os.path.expanduser("~"), ".ollama", "models"),
        _os.path.join(_os.environ.get("LOCALAPPDATA", ""), "Ollama", "models"),
        _os.path.join(_os.environ.get("LOCALAPPDATA", ""), "Programs", "Ollama", "models"),
    ]
    return not any(_os.path.isfile(_os.path.join(r, rel)) for r in roots if r)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("folder", nargs="?", default="")
    ap.add_argument("--watermark", default="")
    ap.add_argument("--duration", default="")
    ap.add_argument("--aspect", default="")
    ap.add_argument("--interpolate", action="store_true")
    ap.add_argument("--pick", action="store_true")
    ap.add_argument("--limit", default="")
    ap.add_argument("--license", default="")
    a = ap.parse_args()

    if _lic is not None:
        if a.license:
            try:
                _lic.activate(a.license)
                print("授权成功")
            except Exception as e:
                print("授权失败：", e)
                return 2
        if not _lic.require_license(interactive=True):
            return 2

    wm = a.watermark or ask("水印名称（直接回车=@枫林晚）: ", "@枫林晚")
    folder = norm(a.folder)
    tries = 0
    while True:
        if not folder or a.pick or not os.path.isdir(folder):
            picked = pick_folder()
            if picked:
                folder = norm(picked)
            else:
                folder = norm(ask("把素材文件夹拖进来（或粘贴路径）后回车: "))
        if not folder:
            print("[错误] 没有选择文件夹（弹窗被取消，也没输入路径）")
            tries += 1
            if tries >= 3:
                ask("按回车退出...")
                return 1
            continue
        if not os.path.isdir(folder):
            print("[错误] 文件夹不存在：", folder)
            tries += 1
            if tries >= 3:
                ask("按回车退出...")
                return 1
            folder = ""
            continue
        exts = (".mp4", ".mkv", ".mov", ".flv", ".ts", ".webm", ".m4v", ".avi")

        def videos_in(d):
            try:
                return [n for n in os.listdir(d) if os.path.splitext(n)[1].lower() in exts]
            except OSError:
                return []

        root_vids = videos_in(folder)
        sub_dirs = []
        try:
            for name in sorted(os.listdir(folder)):
                p = os.path.join(folder, name)
                if os.path.isdir(p) and videos_in(p):
                    sub_dirs.append(name)
        except OSError:
            sub_dirs = []
        if not root_vids and not sub_dirs:
            print("[错误] 这个文件夹和它的子文件夹里都没有视频：", folder)
            tries += 1
            if tries >= 3:
                ask("按回车退出...")
                return 1
            folder = ""
            continue
        break

    if folder.startswith("\\\\"):
        print("[警告] 这是网络路径，批量渲染可能很慢，建议先拷到本地。")
    if root_vids:
        mode = "single"
        print(f"检测到 {len(root_vids)} 个视频，单部处理")
    else:
        mode = "batch"
        print(f"根目录下有 {len(sub_dirs)} 个子文件夹含视频，批量递归处理")

    dur = a.duration or ask("目标时长秒数（回车=180）: ")
    aspect = a.aspect.strip() if a.aspect else ""
    if not aspect:
        raw = ask("画面比例（1=9:16 2=16:9 3=1:1 4=4:3 5=3:4 6=19:6，回车=9:16）: ", "")
        aspect = {"1": "9:16", "2": "16:9", "3": "1:1", "4": "4:3", "5": "3:4", "6": "19:6"}.get(raw.strip(), raw.strip() or "9:16")
        if not __import__("re").fullmatch(r"\d+:\d+", aspect):
            print("比例格式无效，使用 9:16")
            aspect = "9:16"
    if mode == "single":
        cmd = [sys.executable, RENDER, "--folder", folder, "--watermark", wm]
    else:
        cmd = [sys.executable, RENDER, "--root", folder, "--recursive", "--watermark", wm]
    if dur:
        cmd += ["--duration", dur]
    cmd += ["--aspect", aspect]
    interp = a.interpolate
    if not interp:
        ans = ask("启用显卡补帧（RIFE，较慢，约 4 分钟/30秒）? y/N: ", "N")
        interp = ans.lower().startswith("y")
    if interp:
        cmd += ["--interpolate"]
    if a.limit:
        cmd += ["--limit", a.limit]
    if vlm_missing():
        ans = ask("视觉审核模型未安装（约5GB，仅首次）。现在安装? y/N: ", "N")
        if ans.lower().startswith("y"):
            cmd += ["--vlm-review", "on", "--vlm-install"]
        else:
            print("跳过 AI 视觉审核，仅用规则过滤（--vlm-install 可稍后安装）")
    print("=" * 50)
    print("目录：", folder)
    print("水印：", wm, " 时长：", dur or "180", " 比例：", aspect)
    print("审核安全过滤：已开启（strict）｜默认烧录 AI演绎")
    print("特效：进度条/转场/开幕白闪/粒子/素材叠加；补帧：", "开" if interp else "关")
    print("=" * 50)
    rc = subprocess.call(cmd)
    ask("完成，按回车退出...")
    return rc


if __name__ == "__main__":
    sys.exit(main())
