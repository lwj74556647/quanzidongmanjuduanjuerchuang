﻿# recreate-studio bootstrap: provision a portable runtime (Python + deps + FFmpeg)
# Usage: powershell -NoProfile -ExecutionPolicy Bypass -File bootstrap.ps1 -Root "<package root>"
param(
    [Parameter(Mandatory = $true)][string]$Root,
    [ValidateSet("full","lite")][string]$Mode = "full"
)
$ErrorActionPreference = "Continue"
$ProgressPreference = "SilentlyContinue"
try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 } catch { }
if (-not [Environment]::Is64BitOperatingSystem) {
    Write-Host "[fatal] 32-bit Windows is not supported (need 64-bit)"
    exit 9
}

# ---- pick a writable runtime dir: package\runtime, else LOCALAPPDATA\recreate-studio-runtime ----
$runtime = Join-Path $Root "runtime"
if ($Root.Length -gt 100) {
    Write-Host "[warn] package path is long; using LOCALAPPDATA runtime to avoid MAX_PATH"
    $runtime = Join-Path $env:LOCALAPPDATA "recreate-studio-runtime"
}
$writable = $false
try {
    New-Item -ItemType Directory -Force -Path $runtime | Out-Null
    $probe = Join-Path $runtime ".write_test"
    [IO.File]::WriteAllText($probe, "x")
    Remove-Item $probe -Force
    $writable = $true
} catch { $writable = $false }
if (-not $writable) {
    $runtime = Join-Path $env:LOCALAPPDATA "recreate-studio-runtime"
    Write-Host "[warn] package dir is read-only; using $runtime"
    New-Item -ItemType Directory -Force -Path $runtime | Out-Null
}
try {
    $drive = (Get-Item $runtime).PSDrive
    if ($drive -and $drive.Free -lt 800MB) {
        Write-Host "[fatal] not enough free disk space (need at least 800MB)"
        exit 8
    }
} catch { }
$pyDir = Join-Path $runtime "python"
$ffDir = Join-Path $runtime "ffmpeg"
$pyExe = Join-Path $pyDir "python.exe"
$ffExe = Join-Path $ffDir "ffmpeg.exe"
$ffprobe = Join-Path $ffDir "ffprobe.exe"
New-Item -ItemType Directory -Force -Path $pyDir, $ffDir | Out-Null

function Download($url, $out) {
    Write-Host "[download] $url"
    if (Get-Command curl.exe -ErrorAction SilentlyContinue) {
        & curl.exe -L --fail --retry 2 --connect-timeout 20 -o $out $url
        if ($LASTEXITCODE -eq 0 -and (Test-Path $out) -and ((Get-Item $out).Length -gt 1024)) { return $true }
    }
    try {
        Invoke-WebRequest -Uri $url -OutFile $out -UseBasicParsing -TimeoutSec 600
        return $true
    } catch {
        Write-Host "[error] download failed: $($_.Exception.Message)"
        return $false
    }
}

function DownloadFirst($urls, $out) {
    foreach ($u in $urls) {
        if (Download $u $out) { return $true }
    }
    return $false
}

# ---------- 1. Python embeddable (China mirrors first) ----------
if (-not (Test-Path $pyExe)) {
    $pyVer = "3.11.9"
    $zip = Join-Path $runtime "python-embed.zip"
    $pyUrls = @(
        "https://mirrors.huaweicloud.com/python/$pyVer/python-$pyVer-embed-amd64.zip",
        "https://registry.npmmirror.com/-/binary/python/$pyVer/python-$pyVer-embed-amd64.zip",
        "https://www.python.org/ftp/python/$pyVer/python-$pyVer-embed-amd64.zip"
    )
    if (DownloadFirst $pyUrls $zip) {
        Write-Host "[unzip] Python $pyVer"
        Expand-Archive -Path $zip -DestinationPath $pyDir -Force
        Remove-Item $zip -Force
        Get-ChildItem $pyDir -Filter "python*._pth" | ForEach-Object {
            $c = Get-Content $_.FullName
            if ($c -notmatch "Lib\\site-packages") { $c += "Lib\site-packages" }
            if ($c -notmatch "^import site") { $c += "import site" }
            Set-Content $_.FullName $c -Encoding ASCII
        }
        $getpip = Join-Path $runtime "get-pip.py"
        if (DownloadFirst @("https://bootstrap.pypa.io/get-pip.py") $getpip) {
            & $pyExe $getpip --no-warn-script-location
            Remove-Item $getpip -Force
        }
    }
}
if (-not (Test-Path $pyExe)) {
    Write-Host "[fatal] Python runtime not available"
    exit 1
}
Write-Host ("[Python] " + (& $pyExe --version 2>&1 | Out-String).Trim())
& $pyExe -c "print('ok')" *> $null
if ($LASTEXITCODE -ne 0) {
    Write-Host "[deps] Python 启动失败，尝试自动安装 VC++ 2015-2022 运行库..."
    $vc = Join-Path $runtime "vc_redist.x64.exe"
    $vcUrls = @(
        "https://aka.ms/vs/17/release/vc_redist.x64.exe",
        "https://aka.ms/vs/16/release/vc_redist.x64.exe"
    )
    if (DownloadFirst $vcUrls $vc) {
        try {
            Write-Host "[deps] 安装 VC++ 运行库（可能弹出 UAC，请点允许）..."
            $p = Start-Process -FilePath $vc -ArgumentList @("/install", "/quiet", "/norestart") -Wait -PassThru -Verb RunAs
            Write-Host "[deps] VC++ 安装返回: $($p.ExitCode)"
        } catch {
            Write-Host "[warn] VC++ 安装被取消或失败: $($_.Exception.Message)"
        }
        Remove-Item $vc -Force -ErrorAction SilentlyContinue
        & $pyExe -c "print('ok')" *> $null
    }
}
if ($LASTEXITCODE -ne 0) {
    Write-Host "[fatal] Python cannot start. 自动安装 VC++ 失败，请手动安装 Microsoft VC++ 2015-2022 x64 后重试。"
    exit 7
}

if ($Mode -eq "lite") {
    Write-Host "[lite] skip numpy/faster-whisper/FFmpeg (download-only mode)"
    $marker = Join-Path $Root "runtime_path.txt"
    try { Set-Content -Path $marker -Value $runtime -Encoding Default } catch { }
    Write-Host "[ready] runtime: $runtime"
    Write-Host "Python : $pyExe"
    exit 0
}

# ---------- 2. Python deps (PyPI, with China mirror fallback) ----------
& $pyExe -c "import numpy, faster_whisper, PIL" *> $null
if ($LASTEXITCODE -eq 0) {
    & $pyExe -c "import PIL" *> $null
    if ($LASTEXITCODE -ne 0) {
        Write-Host "[install] Pillow (overlay generation)"
        & $pyExe -m pip install Pillow --no-warn-script-location
    }
}
if ($LASTEXITCODE -ne 0) {
    Write-Host "[install] numpy faster-whisper (about 150MB, first run only)"
    $mirrors = @("", "https://pypi.tuna.tsinghua.edu.cn/simple", "https://mirrors.aliyun.com/pypi/simple")
    foreach ($m in $mirrors) {
        if ($m) {
            Write-Host "[install] PyPI mirror: $m"
            & $pyExe -m pip install --upgrade pip --no-warn-script-location -i $m --trusted-host ([Uri]$m).Host
            & $pyExe -m pip install numpy faster-whisper Pillow --no-warn-script-location -i $m --trusted-host ([Uri]$m).Host
        } else {
            & $pyExe -m pip install --upgrade pip --no-warn-script-location
            & $pyExe -m pip install numpy faster-whisper Pillow --no-warn-script-location
        }
        & $pyExe -c "import numpy, faster_whisper, PIL" *> $null
        if ($LASTEXITCODE -eq 0) { break }
    }
}
if ($LASTEXITCODE -eq 0) {
    & $pyExe -c "import numpy, faster_whisper, PIL; print('[deps] numpy', numpy.__version__, '/ faster-whisper ok / Pillow ok')"
} else {
    Write-Host "[fatal] python deps install failed (check network / proxy)"
    exit 2
}

# ---------- 3. FFmpeg (GitHub first, gyan fallback) ----------
if (-not (Test-Path $ffExe) -or -not (Test-Path $ffprobe)) {
    $zip = Join-Path $runtime "ffmpeg.zip"
    $ffUrls = @(
        "https://github.com/BtbN/FFmpeg-Builds/releases/latest/download/ffmpeg-master-latest-win64-gpl.zip",
        "https://www.gyan.dev/ffmpeg/builds/ffmpeg-release-essentials.zip",
        "https://ghproxy.net/https://github.com/BtbN/FFmpeg-Builds/releases/latest/download/ffmpeg-master-latest-win64-gpl.zip",
        "https://mirror.ghproxy.com/https://github.com/BtbN/FFmpeg-Builds/releases/latest/download/ffmpeg-master-latest-win64-gpl.zip"
    )
    if (DownloadFirst $ffUrls $zip) {
        $tmp = Join-Path $runtime "ffmpeg_tmp"
        Remove-Item $tmp -Recurse -Force -ErrorAction SilentlyContinue
        Expand-Archive -Path $zip -DestinationPath $tmp -Force
        Remove-Item $zip -Force
        $ff = Get-ChildItem $tmp -Recurse -Filter "ffmpeg.exe" | Select-Object -First 1
        $fp = Get-ChildItem $tmp -Recurse -Filter "ffprobe.exe" | Select-Object -First 1
        if ($ff) { Copy-Item $ff.FullName $ffExe -Force }
        if ($fp) { Copy-Item $fp.FullName $ffprobe -Force }
        Remove-Item $tmp -Recurse -Force -ErrorAction SilentlyContinue
    }
}
if (-not (Test-Path $ffExe)) {
    Write-Host "[fatal] FFmpeg not available"
    exit 3
}
Write-Host ("[FFmpeg] " + (& $ffExe -version 2>&1 | Select-Object -First 1))

# ---------- 4. marker for launchers (which runtime dir was chosen) ----------
$marker = Join-Path $Root "runtime_path.txt"
try { Set-Content -Path $marker -Value $runtime -Encoding Default } catch { }

Write-Host ""
Write-Host "[ready] runtime: $runtime"
Write-Host "Python : $pyExe"
Write-Host "FFmpeg : $ffExe"
exit 0
