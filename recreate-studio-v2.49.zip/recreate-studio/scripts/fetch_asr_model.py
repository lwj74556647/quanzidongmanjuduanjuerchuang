# -*- coding: utf-8 -*-
"""多源下载 faster-whisper ASR 模型，断点续传、校验、可换盘。"""
import json, os, shutil, subprocess, sys, time

PKG = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DIRS = [os.path.join(PKG, "runtime", "models", "faster-whisper-medium"),
        os.path.join(os.environ.get("LOCALAPPDATA", os.path.expanduser("~")),
                     "recreate-studio", "models", "faster-whisper-medium")]
FILES = {
    "config.json": 1000,
    "model.bin": 1_400_000_000,
    "tokenizer.json": 1_000_000,
    "vocabulary.txt": 400_000,
}
SOURCES = [os.environ.get("RECREATE_ASR_BASE", "").strip(),
           "https://huggingface.co/Systran/faster-whisper-medium/resolve/main",
           "https://hf-mirror.com/Systran/faster-whisper-medium/resolve/main",
           "https://modelscope.cn/models/pengzhendong/faster-whisper-medium/resolve/master"]
SOURCES = [s for s in SOURCES if s]


def valid(path, name, minsize):
    if not os.path.isfile(path) or os.path.getsize(path) < minsize:
        return False
    if name.endswith(".json"):
        try:
            json.load(open(path, encoding="utf-8"))
        except Exception:
            return False
    return True


def urllib_download(url, out):
    import urllib.request
    pos = os.path.getsize(out) if os.path.isfile(out) else 0
    req = urllib.request.Request(url, headers={"Range": f"bytes={pos}-"} if pos else {})
    try:
        with urllib.request.urlopen(req, timeout=30) as r, open(out, "ab" if pos else "wb") as f:
            while True:
                chunk = r.read(1024 * 512)
                if not chunk:
                    break
                f.write(chunk)
        return True
    except Exception as e:
        print("[ASR] urllib 失败：", e, flush=True)
        return False


def curl_ok(url, out):
    if not shutil.which("curl"):
        return False
    print("[ASR] 下载", os.path.basename(out), "from", url.split("/")[2], flush=True)
    p = subprocess.run(["curl.exe", "-L", "--fail", "--retry", "5", "--retry-delay", "3",
                        "--connect-timeout", "20", "--speed-time", "120", "--speed-limit", "1024",
                        "-C", "-", "-o", out, url])
    if p.returncode == 0:
        return True
    print("[ASR] curl 失败，改用 urllib 续传", flush=True)
    return urllib_download(url, out)


def main():
    dest = None
    for d in DIRS:
        try:
            os.makedirs(d, exist_ok=True)
            probe = os.path.join(d, ".write_test")
            open(probe, "w").close(); os.remove(probe)
            dest = d
            break
        except OSError:
            continue
    if not dest:
        print("[ASR] 无可用写入目录", flush=True)
        return 2
    try:
        free = shutil.disk_usage(dest).free
        if free < 2 * 1024**3:
            print(f"[ASR] 磁盘不足 2GB（剩余 {free/1024**3:.1f}GB）", flush=True)
            return 3
    except Exception:
        pass
    lock = os.path.join(dest, ".download.lock")
    try:
        fd = os.open(lock, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
        os.close(fd)
    except OSError:
        print("[ASR] 已有下载进程，等待...", flush=True)
        for _ in range(120):
            if not os.path.exists(lock):
                break
            time.sleep(2)
    try:
        for name, minsize in FILES.items():
            dst = os.path.join(dest, name)
            if valid(dst, name, minsize):
                print("[ASR] 已存在", name, flush=True)
                continue
            ok = False
            for base in SOURCES:
                url = base.rstrip("/") + "/" + name
                if curl_ok(url, dst) and valid(dst, name, minsize):
                    ok = True
                    break
                print("[ASR] 源失败/校验失败，换源：", url, flush=True)
            if not ok:
                print("[ASR] 下载失败：", name, "；可设 RECREATE_ASR_BASE 指向可用镜像", flush=True)
                return 1
        size = os.path.getsize(os.path.join(dest, "model.bin"))
        print(f"[ASR] 模型就绪：{dest}（model.bin {size/1024/1024:.0f}MB）", flush=True)
        return 0
    finally:
        try:
            os.remove(lock)
        except OSError:
            pass


if __name__ == "__main__":
    sys.exit(main())