# -*- coding: utf-8 -*-
"""包内路径解析：优先找包内文件，找不到再找本机/旧路径。"""
import os, shutil

HERE = os.path.dirname(os.path.abspath(__file__))
APP_ROOT = os.path.dirname(HERE)
LOCAL = os.environ.get("LOCALAPPDATA") or os.path.join(os.path.expanduser("~"), "AppData", "Local")


def norm(p):
    if not p:
        return ""
    return os.path.abspath(os.path.expandvars(os.path.expanduser(str(p))))


def first_file(*paths):
    for p in paths:
        if p and os.path.isfile(norm(p)):
            return norm(p)
    return ""


def find_tool(name, *extra):
    """显式候选 -> 包内 tools/runtime -> LOCALAPPDATA -> PATH。"""
    exts = [name] if name.lower().endswith(".exe") else [name, name + ".exe"]
    cands = list(extra) + [
        os.path.join(APP_ROOT, "tools", n) for n in exts
    ] + [
        os.path.join(APP_ROOT, "runtime", n) for n in exts
    ] + [
        os.path.join(LOCAL, "recreate-studio", "tools", n) for n in exts
    ]
    for p in cands:
        if p and os.path.isfile(norm(p)):
            return norm(p)
    for n in exts:
        w = shutil.which(n)
        if w:
            return w
    return ""


def find_baidupcs():
    env = os.environ.get("BAIDUPCS_GO") or os.environ.get("HARVEST_PCS")
    if env and os.path.isfile(norm(env)):
        return norm(env)
    roots = [os.path.join(APP_ROOT, "tools"),
             os.path.join(LOCAL, "recreate-studio", "tools"),
             r"D:\deepseek编程脚本\tools"]
    for root in roots:
        if not os.path.isdir(root):
            continue
        for dirpath, dirnames, files in os.walk(root):
            if dirpath.count(os.sep) - root.count(os.sep) > 3:
                dirnames[:] = []
                continue
            for f in files:
                if f.lower() == "baidupcs-go.exe":
                    return os.path.join(dirpath, f)
    return find_tool("BaiduPCS-Go")


def writable_dir(candidates, fallback):
    for d in candidates:
        if not d:
            continue
        d = norm(d)
        try:
            os.makedirs(d, exist_ok=True)
            probe = os.path.join(d, ".write_test")
            with open(probe, "w") as f:
                f.write("1")
            os.remove(probe)
            return d
        except OSError:
            continue
    d = norm(fallback)
    os.makedirs(d, exist_ok=True)
    return d


def package_asset(*parts):
    return os.path.join(APP_ROOT, "assets", *parts)