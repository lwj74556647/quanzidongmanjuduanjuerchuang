﻿# recreate-studio 授权码工具（仅管理员）

## 启动
双击 `授权码生成器.bat`，或命令行：
`python license_admin.py`

## 命令
- `machine`：显示本机机器码
- `gen --machine <机器码> --days 30`：生成 30 天授权码
- `gen --machine <机器码> --start "2026-11-05 00:00" --end "2026-12-05 00:00"`：指定生效/到期
- `gen --machine <机器码> --permanent`：本机永久码
- `invite`：生成永久邀请码（保存到 invite_code.txt）
- `owner`：把当前电脑设为免授权（本地自用）
- `verify <授权码>`：校验

## 安全
`private_key.json` 是私钥，**不要发给别人、不要打包进客户端**。
丢失私钥后已发出的码无法再验证，需要重新生成密钥对并更新客户端公钥。
