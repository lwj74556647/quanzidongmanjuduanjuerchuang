# -*- coding: utf-8 -*-
"""recreate-studio 授权码生成器（仅管理员持有私钥，不随客户端分发）。"""
import argparse, base64, hashlib, json, os, secrets, sys, time

SKILL = r"C:\Users\Administrator\.dsh\skills\recreate-studio\scripts"
sys.path.insert(0, SKILL)
from license_core import machine_id, verify_code, check_payload, PUB_E

HERE = os.path.dirname(os.path.abspath(__file__))
PRIV = json.load(open(os.path.join(HERE, "private_key.json"), encoding="utf-8"))
N, D = int(PRIV["n"]), int(PRIV["d"])
_DIGEST_PREFIX = bytes.fromhex("3031300d060960864801650304020105000420")


def b64e(b):
    return base64.urlsafe_b64encode(b).decode().rstrip("=")


def sign(payload):
    raw = json.dumps(payload, separators=(",", ":"), sort_keys=True).encode()
    h = hashlib.sha256(raw).digest()
    k = (N.bit_length() + 7) // 8
    t = _DIGEST_PREFIX + h
    em = b"\x00\x01" + b"\xff" * (k - len(t) - 3) + b"\x00" + t
    sig = pow(int.from_bytes(em, "big"), D, N).to_bytes(k, "big")
    return "RS1." + b64e(raw) + "." + b64e(sig)


def parse_time(s):
    return int(time.mktime(time.strptime(s, "%Y-%m-%d %H:%M")))


def gen(machine, days=30, start="", end="", permanent=False):
    now = int(time.time())
    s = parse_time(start) if start else now
    if permanent or days == 0:
        e = 0
    elif end:
        e = parse_time(end)
    else:
        e = s + int(days) * 86400
    payload = {"v": 1, "k": "machine", "m": machine, "s": s, "e": e,
               "n": secrets.token_hex(4), "t": now}
    return sign(payload)


def invite():
    return sign({"v": 1, "k": "invite", "n": "INVITE-2026", "t": 0})


def owner_token():
    return sign({"v": 1, "k": "owner", "m": machine_id(), "t": int(time.time())})


def write_owner():
    base = os.environ.get("LOCALAPPDATA") or os.path.join(os.path.expanduser("~"), "AppData", "Local")
    d = os.path.join(base, "recreate-studio")
    os.makedirs(d, exist_ok=True)
    path = os.path.join(d, "owner.json")
    tok = owner_token()
    open(path, "w", encoding="utf-8").write(tok)
    return path


def menu():
    print("=" * 60)
    print("recreate-studio 授权码生成器")
    print("本机机器码：", machine_id())
    print("=" * 60)
    while True:
        print("\n1) 生成授权码（指定机器码/天数）")
        print("2) 生成永久邀请码")
        print("3) 把本机设为免授权（owner）")
        print("4) 校验授权码")
        print("5) 显示本机机器码")
        print("0) 退出")
        c = input("选择: ").strip()
        if c == "0":
            return
        if c == "1":
            m = input("目标机器码: ").strip()
            d = input("有效天数（0=永久，默认30）: ").strip() or "30"
            code = gen(m, int(d))
            print("\n授权码（复制发给对方）：\n" + code)
            print("\n到期：", "永久" if int(d) == 0 else time.strftime("%Y-%m-%d %H:%M", time.localtime(time.time() + int(d) * 86400)))
        elif c == "2":
            code = invite()
            open(os.path.join(HERE, "invite_code.txt"), "w", encoding="utf-8").write(code)
            print("\n永久邀请码：\n" + code)
        elif c == "3":
            p = write_owner()
            print("已写入 owner 免授权：", p)
        elif c == "4":
            code = input("授权码: ").strip()
            try:
                data = verify_code(code)
                check_payload(data)
                print("有效：", data)
            except Exception as e:
                print("无效：", e)
        elif c == "5":
            print("本机机器码：", machine_id())


def main():
    ap = argparse.ArgumentParser(description="recreate-studio 授权码生成器")
    sub = ap.add_subparsers(dest="cmd")
    g = sub.add_parser("gen")
    g.add_argument("--machine", required=True)
    g.add_argument("--days", type=int, default=30)
    g.add_argument("--start", default="")
    g.add_argument("--end", default="")
    g.add_argument("--permanent", action="store_true")
    sub.add_parser("invite")
    sub.add_parser("owner")
    sub.add_parser("machine")
    v = sub.add_parser("verify")
    v.add_argument("code")
    a = ap.parse_args()
    if not a.cmd:
        menu(); return
    if a.cmd == "gen":
        code = gen(a.machine, a.days, a.start, a.end, a.permanent)
        print(code)
    elif a.cmd == "invite":
        code = invite()
        open(os.path.join(HERE, "invite_code.txt"), "w", encoding="utf-8").write(code)
        print(code)
    elif a.cmd == "owner":
        print(write_owner())
    elif a.cmd == "machine":
        print(machine_id())
    elif a.cmd == "verify":
        print(verify_code(a.code))


if __name__ == "__main__":
    main()