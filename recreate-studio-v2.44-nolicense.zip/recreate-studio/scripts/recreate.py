# -*- coding: utf-8 -*-
"""recreate-studio 渲染器：把一集短剧素材自动剪成约 3 分钟的抖音二创成片。

用法：
  py recreate.py --folder "D:\\碧海剧场\\001. 毒酒换红妆"
  py recreate.py --root   "D:\\碧海剧场" --limit 3
  py recreate.py --folder ... --aspect 9:16 --duration 180 --watermark "@账号名"

产出：<素材文件夹>\\<剧名>_二创_3min.mp4 与 <剧名>_二创_报告.json
"""
import argparse
import json
import math
import os
import random
import re
import shutil
import subprocess
import sys
import tempfile
import time
import urllib.request
try:
    import license_guard as _lic
except Exception:
    _lic = None
import shutil
import ctypes
import hashlib

__version__ = "2.44"

try:
    import numpy as np
except Exception:  # numpy 缺失时退化为随机选段
    np = None

def _first(*paths):
    """按顺序返回第一个存在的文件/命令；都没有则返回最后一个（可能只是命令名）。"""
    for p in paths:
        if p and (os.path.isfile(p) or shutil.which(p)):
            return p
    return paths[-1]


def _first_dir(*paths):
    for p in paths:
        if p and os.path.isdir(p):
            return p
    return ""


def _exe(env_name, *cands):
    p = os.environ.get(env_name)
    if p and os.path.isfile(p):
        return p
    return _first(*cands)


FFMPEG = _exe("RECREATE_FFMPEG", r"D:\AI\tools\ffmpeg.exe", "ffmpeg")
FFPROBE = _exe("RECREATE_FFPROBE", r"D:\AI\tools\ffprobe.exe", "ffprobe")
BGM_DIR = os.environ.get("RECREATE_BGM_DIR") or _first_dir(
    os.path.join(os.path.expanduser("~"), "Desktop", "漫剧短剧BGM库"),
    r"D:\deepseek漫剧1\studio\assets\bgm",
    os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "assets", "bgm"),
)
def _font_path():
    cands = [os.environ.get("RECREATE_FONT", ""),
             r"C:\Windows\Fonts\msyh.ttc", r"C:\Windows\Fonts\msyhbd.ttc",
             r"C:\Windows\Fonts\simhei.ttf", r"C:\Windows\Fonts\simsun.ttc",
             os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "assets", "fonts", "NotoSansCJKsc-Regular.otf"),
             r"C:\Windows\Fonts\arial.ttf"]
    for c in cands:
        if c and os.path.isfile(c):
            return c
    return ""


FONT = _font_path()
FONT_ESC = FONT.replace("\\", "/").replace(":", "\\:") if FONT else ""

# 内嵌 BGM 来源清单（Mixkit 免署名 / Incompetech CC-BY），首次运行自动下载
BGM_SOURCES = [
    ('01_甜宠暧昧｜恋爱撒糖/01_Beautiful Dream.mp3', 'https://assets.mixkit.co/music/493/493.mp3'),
    ('01_甜宠暧昧｜恋爱撒糖/02_Skyline.mp3', 'https://assets.mixkit.co/music/601/601.mp3'),
    ('01_甜宠暧昧｜恋爱撒糖/03_Romantic.mp3', 'https://assets.mixkit.co/music/659/659.mp3'),
    ('01_甜宠暧昧｜恋爱撒糖/04_Latin Lovers.mp3', 'https://assets.mixkit.co/music/39/39.mp3'),
    ('02_虐心BE｜遗憾回忆/01_Silent Descent.mp3', 'https://assets.mixkit.co/music/614/614.mp3'),
    ('02_虐心BE｜遗憾回忆/02_Sun and His Daughter.mp3', 'https://assets.mixkit.co/music/580/580.mp3'),
    ('02_虐心BE｜遗憾回忆/03_Piano Reflections.mp3', 'https://assets.mixkit.co/music/22/22.mp3'),
    ('02_虐心BE｜遗憾回忆/04_Classical vibes 5.mp3', 'https://assets.mixkit.co/music/688/688.mp3'),
    ('02_虐心BE｜遗憾回忆/05_Classical 7.mp3', 'https://assets.mixkit.co/music/714/714.mp3'),
    ('03_高燃逆袭｜打脸高光/01_Epic Unease.mp3', 'https://incompetech.com/music/royalty-free/mp3-royaltyfree/Epic%20Unease.mp3'),
    ('03_高燃逆袭｜打脸高光/02_Heroic Age.mp3', 'https://incompetech.com/music/royalty-free/mp3-royaltyfree/Heroic%20Age.mp3'),
    ('03_高燃逆袭｜打脸高光/03_Take the Lead.mp3', 'https://incompetech.com/music/royalty-free/mp3-royaltyfree/Take%20the%20Lead.mp3'),
    ('03_高燃逆袭｜打脸高光/04_Rynos Theme.mp3', 'https://incompetech.com/music/royalty-free/mp3-royaltyfree/Rynos%20Theme.mp3'),
    ('04_悬疑反转｜伏笔惊悚/01_Dark Fog.mp3', 'https://incompetech.com/music/royalty-free/mp3-royaltyfree/Dark%20Fog.mp3'),
    ('04_悬疑反转｜伏笔惊悚/02_Hidden Agenda.mp3', 'https://incompetech.com/music/royalty-free/mp3-royaltyfree/Hidden%20Agenda.mp3'),
    ('04_悬疑反转｜伏笔惊悚/03_Anxiety.mp3', 'https://incompetech.com/music/royalty-free/mp3-royaltyfree/Anxiety.mp3'),
    ('04_悬疑反转｜伏笔惊悚/04_Ossuary 5 - Rest.mp3', 'https://incompetech.com/music/royalty-free/mp3-royaltyfree/Ossuary%205%20-%20Rest.mp3'),
    ('05_轻松搞笑｜乌龙吃瓜/01_Secret Garden.mp3', 'https://assets.mixkit.co/music/595/595.mp3'),
    ('05_轻松搞笑｜乌龙吃瓜/02_Games Worldbeat.mp3', 'https://assets.mixkit.co/music/466/466.mp3'),
    ('05_轻松搞笑｜乌龙吃瓜/03_Upbeat Jazz.mp3', 'https://assets.mixkit.co/music/644/644.mp3'),
    ('05_轻松搞笑｜乌龙吃瓜/04_Comical.mp3', 'https://assets.mixkit.co/music/2/2.mp3'),
    ('05_轻松搞笑｜乌龙吃瓜/05_Keep Smiling.mp3', 'https://assets.mixkit.co/music/15/15.mp3'),
    ('06_古风仙侠｜江湖权谋/01_Eastern Thought.mp3', 'https://incompetech.com/music/royalty-free/mp3-royaltyfree/Eastern%20Thought.mp3'),
    ('06_古风仙侠｜江湖权谋/02_Ishikari Lore.mp3', 'https://incompetech.com/music/royalty-free/mp3-royaltyfree/Ishikari%20Lore.mp3'),
    ('06_古风仙侠｜江湖权谋/03_Tabuk.mp3', 'https://incompetech.com/music/royalty-free/mp3-royaltyfree/Tabuk.mp3'),
    ('06_古风仙侠｜江湖权谋/04_Desert City.mp3', 'https://incompetech.com/music/royalty-free/mp3-royaltyfree/Desert%20City.mp3'),
    ('07_治愈日常｜温柔叙事/01_Serene View.mp3', 'https://assets.mixkit.co/music/443/443.mp3'),
    ('07_治愈日常｜温柔叙事/02_Valley Sunset.mp3', 'https://assets.mixkit.co/music/127/127.mp3'),
    ('07_治愈日常｜温柔叙事/03_Classical vibes 2.mp3', 'https://assets.mixkit.co/music/682/682.mp3'),
    ('07_治愈日常｜温柔叙事/04_Wedding 01.mp3', 'https://assets.mixkit.co/music/657/657.mp3'),
    ('07_治愈日常｜温柔叙事/05_Relax Beat.mp3', 'https://assets.mixkit.co/music/292/292.mp3'),
    ('08_反派压迫｜阴郁暗黑/01_Ghost Story.mp3', 'https://incompetech.com/music/royalty-free/mp3-royaltyfree/Ghost%20Story.mp3'),
    ('08_反派压迫｜阴郁暗黑/02_Ossuary 6 - Air.mp3', 'https://incompetech.com/music/royalty-free/mp3-royaltyfree/Ossuary%206%20-%20Air.mp3'),
    ('08_反派压迫｜阴郁暗黑/03_Come Play with Me.mp3', 'https://incompetech.com/music/royalty-free/mp3-royaltyfree/Come%20Play%20with%20Me.mp3'),
    ('08_反派压迫｜阴郁暗黑/04_Darkest Child.mp3', 'https://incompetech.com/music/royalty-free/mp3-royaltyfree/Darkest%20Child.mp3'),
    ('09_卡点预告｜片头片尾/01_Prelude and Action.mp3', 'https://incompetech.com/music/royalty-free/mp3-royaltyfree/Prelude%20and%20Action.mp3'),
    ('09_卡点预告｜片头片尾/02_Killers.mp3', 'https://incompetech.com/music/royalty-free/mp3-royaltyfree/Killers.mp3'),
    ('09_卡点预告｜片头片尾/03_Impact Prelude.mp3', 'https://incompetech.com/music/royalty-free/mp3-royaltyfree/Impact%20Prelude.mp3'),
    ('09_卡点预告｜片头片尾/04_Impact Moderato.mp3', 'https://incompetech.com/music/royalty-free/mp3-royaltyfree/Impact%20Moderato.mp3'),
]


ASPECTS = {
    "9:16": (1080, 1920),
    "16:9": (1920, 1080),
    "19:6": (1920, 608),
    "1:1": (1080, 1080),
}

MOODS = [
    ("温柔", ("甜", "恋", "婚", "宠", "爱", "暖", "春")),
    ("悬疑", ("悬", "秘", "谜", "真相", "阴", "局")),
    ("激昂", ("总裁", "复仇", "逆袭", "打脸", "豪门", "狂", "龙", "殿")),
    ("紧张", ("逃", "追", "危", "杀", "绑", "劫", "惊")),
    ("空灵", ("仙", "灵", "玄", "梦", "古", "云", "凤")),
    ("轻快", ("笑", "萌", "团宠", "福宝", "搞笑", "宝", "娃")),
    ("悲伤", ("离", "别", "死", "哭", "遗", "孤", "悔")),
]


def decode(b):
    if not b:
        return ""
    for enc in ("utf-8", "gbk"):
        try:
            s = b.decode(enc)
            if "\ufffd" not in s:
                return s
        except Exception:
            pass
    return b.decode("gbk", errors="replace")


def run(cmd, cwd=None, timeout=1800):
    p = subprocess.run(cmd, capture_output=True, cwd=cwd, timeout=timeout)
    return p.returncode, decode(p.stdout), decode(p.stderr)


def probe(path):
    rc, out, _ = run([FFPROBE, "-v", "error", "-print_format", "json",
                      "-show_format", "-show_streams", path], timeout=120)
    if rc != 0:
        return {}
    j = json.loads(out)
    v = next((s for s in j.get("streams", []) if s.get("codec_type") == "video"), {})
    a = next((s for s in j.get("streams", []) if s.get("codec_type") == "audio"), None)
    return {
        "width": int(v.get("width") or 0),
        "height": int(v.get("height") or 0),
        "fps": v.get("r_frame_rate") or "25/1",
        "duration": float(j.get("format", {}).get("duration") or 0),
        "has_audio": a is not None,
    }


def is_offline(path):
    """检测 OneDrive/网盘占位文件（FILE_ATTRIBUTE_OFFLINE=0x1000）。"""
    try:
        FILE_ATTRIBUTE_OFFLINE = 0x1000
        attrs = ctypes.windll.kernel32.GetFileAttributesW(str(path))
        return attrs != -1 and bool(attrs & FILE_ATTRIBUTE_OFFLINE)
    except Exception:
        return False


SENSITIVE_HARD = (
    # 色情/裸露
    "裸", "脱衣", "做爱", "上床", "开房", "迷奸", "迷药", "下药",
    # 吸毒/赌博/枪爆
    "吸毒", "贩毒", "制毒", "毒瘾", "海洛因", "冰毒", "赌博", "赌场", "开赌",
    "枪支", "私藏枪", "炸弹", "爆炸物", "爆头", "分尸",
    # 自杀/自残/性侵
    "割腕", "自杀", "跳楼", "上吊", "强奸", "性侵", "猥亵",
    # 未成年人不当内容
    "未成年", "幼女", "萝莉", "童婚", "恋童",
    # 时政/邪教/恐怖
    "邪教", "法轮功", "全能神", "颠覆国家", "分裂国家", "恐怖组织", "诋毁英烈", "侮辱英烈",
    # 色情擦边
    "情趣用品", "露点", "走光", "裸聊", "约炮", "援交", "福利姬", "软色情",
    # 暴力/管制
    "虐杀", "碎尸", "割喉", "自残", "自焚", "管制刀具", "制爆", "制枪", "撬锁",
    # 违法
    "外挂", "刷单", "传销", "洗钱",
    # 医疗/金融夸大
    "根治", "包治", "治愈率", "保本", "稳赚", "荐股", "内幕消息", "医美贷",
    # 封建迷信（现实向）
    "算命", "看相", "风水大师", "转运", "辟邪", "符水", "驱邪", "招魂", "通灵",
    "降头", "巫术", "诅咒", "邪术", "跳大神", "神婆", "大师改运", "改运",
    # 伪科学/虚假养生
    "偏方治", "秘方治", "抗癌神药", "治愈癌症", "神医", "量子保健", "磁疗",
    "酸碱体质", "排毒养颜", "能量水", "富氢水", "干细胞美容", "伪科学",
    # ===== 站外导流（硬信号）=====
    "微信", "加微", "微我", "vx", "vx号", "扣扣号", "企鹅号", "手机号", "电话号",
    "扫码", "二维码", "外链", "公众号", "小红书", "淘宝", "拼多多", "闲鱼",
    "进群", "拉群", "群号", "抠1发链接", "扣一领取",
    # ===== 极限绝对词（广告法明确违规的组合）=====
    "全网第一", "全国第一", "史无前例", "绝无仅有",
    "王牌",
    "独家", "首家", "100%", "百分百",
    # ===== 医疗功效（疗效承诺）=====
    "药到病除", "防癌", "抗癌", "降血压", "降血糖", "排毒", "祛湿",
    "生发", "止脱", "祛斑", "祛痘", "壮阳", "增高", "转阴", "医用", "药用",
    "偏方", "特效药", "无副作用", "包好", "根除", "活血化瘀", "抗过敏",
    # ===== 金融/副业诱导 =====
    "稳赚", "保本", "零风险", "躺赚", "必赚", "暴富", "月入过万", "日入上千",
    "包赚钱", "百分百回本", "内幕消息", "原始股", "资金盘", "征信洗白",
    "外汇", "期货", "内幕", "稳收益", "保证收益", "必发财", "刷单", "跑分",
    "杀猪盘", "盗号",
    # ===== 色情擦边（明确）=====
    "嫖", "妓", "骚货", "骚女", "嫩模", "裸", "上床", "开房", "包养", "调教",
    "看片", "色情", "黄片", "大尺度", "脱衣", "约炮", "援交", "福利姬",
    # ===== 暴力/犯罪/违禁 =====
    "赌球", "博彩", "白粉", "军火", "管制刀具", "制爆", "走私", "外挂", "破解",
    "自杀", "自残", "跳楼", "割腕", "下毒", "撬锁",
    # ===== 封建迷信（现实操作）=====
    "算命", "改运", "转运", "风水", "占卜", "符咒", "驱邪", "招魂", "通灵",
    "蛊术", "诅咒", "招财", "避灾", "消灾", "看相", "卜卦", "神婆", "跳大神",
    # ===== 歧视/辱骂 =====
    "傻逼", "脑残", "杂种", "地域黑", "穷鬼", "低贱", "蠢货", "老不死", "残废",
    "挑起对立", "男拳", "女拳", "挑事",
    # ===== 教培/保过 =====
    "包过", "保过", "必过", "稳过", "内部押题", "泄题", "真题答案", "包就业",
    "包分配", "绝密资料", "内部渠道",
    # ===== 价值观高危 =====
    "钱能摆平一切", "穷就是原罪", "灭门", "杀光", "弄死", "同归于尽",
    "乱伦", "婚外情", "借种", "代孕",
    # ===== 未成年人 =====
    "童模擦边", "萝莉福利", "诱导打赏", "未成年带货", "早恋怀孕",
    # ===== 谐音/缩写变体 =====
    "薇信", "围信", "维信", "扣一", "k1", "v我50", "稳赚不赔", "保本收益",
    "根冶", "治俞", "降xy", "增免yi",
    # ===== 涉政/英烈/国家安全 =====
    "台独", "港独", "疆独", "藏独", "台湾独立", "香港独立", "新疆独立", "西藏独立", "分裂国家", "反动", "邪教", "法轮功", "敏感情报", "泄密",
    "叛国", "间谍", "抹黑英烈", "侮辱英烈", "歪曲历史", "暴乱", "示威", "游行",
    "非法组织", "境外势力", "负面谣言", "不实舆情", "涉密", "军旗", "国徽",
    "篡改地图", "残缺地图",
    # ===== 导流（明确信号，短词不硬拦）=====
    "加微", "微我", "加v", "v我", "vx", "绿泡泡", "加扣扣", "扣扣号", "看简介",
    "看主页", "加客服", "单独发", "同城见面", "面交", "扣1领取", "抠1",
    # ===== 广告极限/营销套路 =====
    "全网第一", "全国第一", "史无前例", "绝无仅有", "100%", "百分百", "终极",
    "至尊", "极品", "NO.1", "史上", "无敌", "秒杀一切", "免检", "驰名",
    "永不复发", "包满意", "免费领", "0元购", "零元到手", "点击领取", "恭喜获奖",
    "全民免单", "手慢无", "错过再等一年", "清仓亏本", "厂家破产", "跳楼价",
    "政府补贴", "无效退款",
    # ===== 医疗功效（扩展）=====
    "降三高", "补肾", "安神", "补血", "养胃", "养肝", "调理糖尿病", "降压药",
    "伤口愈合", "祛疤", "减脂溶脂", "吸脂", "瘦脸", "瘦腿", "延年益寿",
    "增强免疫力", "处方", "药方", "临床", "无激素", "纯天然治病", "消除结节",
    "结石排出", "HPV转阴",
    # ===== 金融/网赚（扩展）=====
    "养卡", "套现", "花呗套现", "白条套现", "虚拟币", "比特币", "以太坊", "币圈",
    "炒币", "私募", "P2P", "返佣", "拉人头", "分红保底", "内部单", "无脑赚",
    # ===== 色情擦边（扩展）=====
    "会所", "陪玩", "有偿陪侍", "失足", "乳沟", "私密", "私处", "合欢", "春药",
    "迷药", "裸聊", "母狗", "反差", "找搭子", "地陪",
    # ===== 暴力犯罪（扩展）=====
    "千术", "赌术", "海洛因", "麻古", "上吊", "开锁教程", "炸药", "绑架", "灭口",
    "分尸", "虐杀", "投毒", "袭警", "越狱",
    # ===== 迷信玄学（扩展）=====
    "灵符", "八字", "命格", "逆天改命", "开光", "加持", "渡劫", "旺夫", "旺宅",
    "旺财", "聚财", "化解小人", "破太岁", "犯太岁", "灵验", "显灵", "护身符",
    "仙家", "阴阳眼", "地府", "阴间还阳", "出马", "顶仙",
    # ===== 歧视辱骂（扩展）=====
    "洋鬼子", "蛮子", "拳师", "种族歧视", "重男轻女", "厌女", "仇男", "畜生",
    "去死", "弄死你", "人渣",
    # ===== 教培/假冒 =====
    "内部答案", "免试", "走后门", "保录取", "高仿", "A货", "一比一复刻", "原单",
    "尾单", "水货", "走私货", "原厂流出", "破解版", "盗版", "无授权", "盗录", "盗播",
    # ===== 未成年 =====
    "诱骗少女", "猥亵", "性侵", "诱拐", "童养媳",
    # ===== 价值观/桥段 =====
    "PUA", "仙人跳", "家暴合理化",
    # ===== 谐音/缩写/拆字 =====
    "稳赚不赔", "保本收益", "根冶", "治俞", "降xy", "增免yi", "芷疗", "根至",
    "围信", "维欣", "扣一", "k1", "v我50", "绿泡", "泡泡", "某信", "某q",
    "米米", "赌bo", "色请", "自沙", "割腕wan",
    # ===== 犯罪教唆（新增）=====
    "教唆犯罪", "传授犯罪", "犯罪教程", "杀人教程", "投毒教程", "制毒教程",
    "制枪教程", "制爆教程", "洗钱教程", "诈骗话术", "诈骗教程", "开锁教程",
    "黑客教程", "赌博技巧", "赌术教学", "吸毒方法", "传销话术", "绑架教程",
    # ===== 自杀细节（新增）=====
    "自杀方法", "怎么自杀", "如何自杀", "无痛自杀", "烧炭自杀", "安眠药自杀",
    "上吊教程", "割腕教程", "跳楼教程", "自杀直播", "相约自杀", "自杀群",
    # ===== 未成年恋爱/性化（新增）=====
    "未成年恋爱", "未成年同居", "未成年怀孕", "未成年接吻", "萝莉控",
    "儿童色情", "猥亵儿童", "诱骗未成年", "师生恋", "包养未成年",
    # ===== 色情低俗（新增）=====
    "低俗色情", "露骨挑逗", "床戏直播", "色情直播", "成人视频", "黄网",
    "约炮软件", "上门服务", "特殊服务", "一夜情交易",
    # ===== 炫富拜金（新增硬组合）=====
    "炫富炒作", "拜金主义", "傍大款", "嫁豪门", "有钱就是爷", "穷人原罪",
    "没钱别谈恋爱", "奢侈品炫富", "炫富挑战",
    # ===== 诈骗（新增硬组合）=====
    "电信诈骗", "网络诈骗", "冒充公检法", "中奖诈骗", "兼职诈骗", "刷单诈骗",
    "虚假投资", "庞氏骗局", "资金盘诈骗", "杀猪盘话术", "贷款诈骗", "养老诈骗",
    # ===== 虚假/误导信息（新增）=====
    "造谣传谣", "编造谣言", "假新闻", "虚假宣传", "虚假广告", "误导消费者",
    "百分百有效", "绝对有效", "包治百病", "神药", "特效偏方",
    # ===== 涉密（新增）=====
    "国家机密", "军事机密", "泄露机密", "机密文件", "内部机密", "保密资料",
    "涉密文件", "情报交易",
    # ===== 价值观极端（新增）=====
    "报复社会", "反社会人格", "极端主义", "仇恨言论", "煽动仇恨", "反人类",
    "灭世言论", "鼓励自残", "鼓励犯罪",
    # ===== 假冒盗版（新增）=====
    "假冒品牌", "山寨货", "假冒伪劣", "伪造证件", "假证办理", "盗版资源",
    "盗版课程", "翻录课程", "假冒官方",
)
SENSITIVE_SOFT = (
    "血", "杀", "死", "尸", "刀", "砍", "捅", "绑架", "家暴", "殴打", "毒打",
    "堕胎", "复仇", "报仇", "陷害", "诈骗", "走私",
    # 极限词/夸大（只计数，不拦截，避免误杀剧情台词）
    "全网最低", "史上最", "第一", "永久", "百分百", "保证", "绝对", "稳赚不赔",
    # 玄幻/灵异（可能只是剧情设定，只计数）
    "妖怪",
    # 极限词单字/泛化（剧情台词常见，只计数）
    "最", "第一", "唯一", "顶级", "顶尖", "极致", "永久", "万能", "绝对", "永不",
    "首选", "最佳", "最强", "最高", "最低", "完美", "王牌", "天花板", "国家级", "世界级",
    "转账", "支付宝",
    # 医疗泛动词（医生/病房剧情）
    "治疗", "治愈", "治病", "消炎", "修复",
    # 情感/伦理主题（剧情常见）
    "情人", "出轨", "外遇", "少妇", "人妻", "约",
    # 暴力剧情主题
    "打架", "杀人", "暗杀", "报复", "炫富", "拜金", "垃圾",
    # 玄幻/灵异设定
    "修仙", "法术", "鬼怪", "鬼魂", "轮回", "前世", "因果", "灵异", "玄幻", "仙侠",
    # 新增类别中剧情常见、只计数不硬拦
    "诈骗", "炫富", "拜金", "早恋", "师生恋", "低俗", "擦边", "谣言", "假新闻",
    "极端", "仇恨", "假冒", "山寨", "盗版", "机密", "教唆", "自杀", "未成年恋爱",
)

CONTACT_RE = re.compile(
    r"1[3-9]\d{9}"
    r"|(?:微信|薇信|vx|wx|加v|qq)\s*[:：]?\s*[A-Za-z0-9_-]{4,}"
    r"|https?://|www\."
    r"|二维码",
    re.I,
)

SAFETY = {"enabled": False, "text_rejected": 0, "visual_rejected": 0,
          "lowq_rejected": 0, "asr_available": False, "soft_hits": 0, "note": ""}


def scan_text_safety(text):
    text = text or ""
    hard = []
    for w in SENSITIVE_HARD:
        if w not in text:
            continue
        if w == "绑架" and any(k in text for k in ("道德绑架", "亲情绑架", "情感绑架", "孝顺绑架", "舆论绑架")):
            continue
        hard.append(w)
    if CONTACT_RE.search(text):
        hard.append("导流联系方式")
    soft = [w for w in SENSITIVE_SOFT if w in text]
    for w in ("私下", "私聊我", "骚扰", "线下找我", "私信发你", "来我这", "主页找我", "联系我", "发给你"):
        if w in text:
            soft.append(w)
    return hard, soft


def frame_quality(path, ts):
    """返回 (平均亮度, 锐度)；用于剔除黑屏/极度模糊的低质画面。"""
    try:
        p = subprocess.run([FFMPEG, "-v", "error", "-ss", str(max(0.0, ts)), "-i", path,
                            "-frames:v", "1", "-vf", "scale=160:90", "-f", "rawvideo",
                            "-pix_fmt", "gray", "-"], capture_output=True, timeout=60)
        if p.returncode != 0 or not p.stdout:
            return 128.0, 99.0
        arr = np.frombuffer(p.stdout, dtype=np.uint8).astype(np.float32)
        h, w = 90, 160
        if arr.size < h * w:
            return 128.0, 99.0
        img = arr[:h * w].reshape(h, w)
        mean = float(img.mean())
        sharp = float(np.abs(np.diff(img, axis=1)).mean() + np.abs(np.diff(img, axis=0)).mean())
        return mean, sharp
    except Exception:
        return 128.0, 99.0


def frame_red_ratio(path, ts):
    """取一帧算“血色/强红”像素占比，用于粗筛血腥画面。"""
    try:
        p = subprocess.run([FFMPEG, "-v", "error", "-ss", str(max(0.0, ts)), "-i", path,
                            "-frames:v", "1", "-vf", "scale=160:90", "-f", "rawvideo",
                            "-pix_fmt", "rgb24", "-"], capture_output=True, timeout=60)
        if p.returncode != 0 or not p.stdout:
            return 0.0
        arr = np.frombuffer(p.stdout, dtype=np.uint8)
        arr = arr[:len(arr) // 3 * 3].reshape(-1, 3).astype(np.float32)
        if not len(arr):
            return 0.0
        r, g, b = arr[:, 0], arr[:, 1], arr[:, 2]
        mask = (r > 90) & (r > g * 1.5) & (r > b * 1.5) & ((r - np.minimum(g, b)) > 40)
        return float(mask.mean())
    except Exception:
        return 0.0


def norm_path(p):
    """统一处理：去引号、展开 ~、绝对路径、去掉 Windows 尾部的反斜杠/斜杠。"""
    if not p:
        return ""
    p = str(p).strip()
    if len(p) >= 2 and p[0] == p[-1] and p[0] in "\"'":
        p = p[1:-1]
    p = os.path.expanduser(p)
    p = os.path.abspath(p)
    if len(p) > 3:
        p = p.rstrip("\\/")
    return p


def safe_title(name):
    name = re.sub(r'[<>:"/\\|?*\x00-\x1f]', "_", name or "").strip(" .")
    return name or "untitled"


def parse_aspect(text):
    text = text.strip()
    if text in ASPECTS:
        return ASPECTS[text]
    m = re.match(r"^(\d+)[xX:：](\d+)$", text)
    if m:
        w, h = int(m.group(1)), int(m.group(2))
        w -= w % 2
        h -= h % 2
        return w, h
    raise ValueError("aspect 需为 9:16/16:9/19:6/1:1 或 WxH")


def pick_mood(title):
    for mood, keys in MOODS:
        if any(k in title for k in keys):
            return mood
    return "悬疑"


BGM_MOODS = {
    "悬疑": ["04_悬疑反转｜伏笔惊悚"],
    "紧张": ["04_悬疑反转｜伏笔惊悚", "03_高燃逆袭｜打脸高光"],
    "悲伤": ["02_虐心BE｜遗憾回忆"],
    "温柔": ["01_甜宠暧昧｜恋爱撒糖", "07_治愈日常｜温柔叙事"],
    "激昂": ["03_高燃逆袭｜打脸高光", "09_卡点预告｜片头片尾"],
    "空灵": ["06_古风仙侠｜江湖权谋", "07_治愈日常｜温柔叙事"],
    "轻快": ["05_轻松搞笑｜乌龙吃瓜"],
}

BGM_LICENSE = """# BGM 许可说明

- Mixkit Stock Music Free License：可商用、免署名、不可转售原始音频。
- Incompetech / Kevin MacLeod — CC BY 4.0：可商用，成片需署名
  `Music by Kevin MacLeod (incompetech.com), licensed under CC BY 4.0`
"""


def ensure_bgm(limit=0, force=False):
    """BGM 目录缺失/为空时，按内嵌来源清单从原始地址下载（约 39 首，200MB）。"""
    os.makedirs(BGM_DIR, exist_ok=True)
    idx_path = os.path.join(BGM_DIR, "index.json")
    if os.path.isfile(idx_path) and not force:
        try:
            data = json.load(open(idx_path, encoding="utf-8"))
            if any(data.get(m) for m in BGM_MOODS):
                return
        except Exception:
            pass
    ok = skip = fail = 0
    for rel, url in BGM_SOURCES:
        if limit and ok + skip >= limit:
            break
        if fail >= 3:
            print("BGM 连续下载失败，跳过 BGM（不影响出片）", flush=True)
            break
        dst = os.path.join(BGM_DIR, rel.replace("/", os.sep))
        if os.path.isfile(dst) and not force:
            skip += 1
            continue
        os.makedirs(os.path.dirname(dst), exist_ok=True)
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
            with urllib.request.urlopen(req, timeout=20) as r, open(dst, "wb") as f:
                f.write(r.read())
            ok += 1
            print(f"BGM 下载 {rel}", flush=True)
        except Exception as e:
            fail += 1
            print(f"BGM 失败 {rel}: {e}", flush=True)
    index = {}
    for mood, dirs in BGM_MOODS.items():
        index[mood] = [rel for rel, _ in BGM_SOURCES
                       if os.path.dirname(rel) in dirs
                       and os.path.isfile(os.path.join(BGM_DIR, rel.replace("/", os.sep)))]
    with open(idx_path, "w", encoding="utf-8") as f:
        json.dump(index, f, ensure_ascii=False, indent=1)
    with open(os.path.join(BGM_DIR, "LICENSE.md"), "w", encoding="utf-8") as f:
        f.write(BGM_LICENSE)
    print(f"BGM 就绪：{BGM_DIR}（下载 {ok}，跳过 {skip}，失败 {fail}）", flush=True)


def pick_bgm(title):
    mood = pick_mood(title)
    idx = os.path.join(BGM_DIR, "index.json")
    if os.path.isfile(idx):
        try:
            data = json.load(open(idx, encoding="utf-8"))
            files = data.get(mood) or []
            cands = [os.path.join(BGM_DIR, f.replace("/", os.sep)) for f in files]
            cands = [p for p in cands if os.path.isfile(p)]
            if cands:
                return mood, random.choice(cands)
        except Exception:
            pass
    p = os.path.join(BGM_DIR, f"{mood}.mp3")      # 兼容旧的 7 个情绪文件
    return mood, (p if os.path.isfile(p) else "")


HOOKS = [
    "开头三秒就把人拽进戏里，信息量拉满。",
    "这一段的张力，隔着屏幕都能感觉到。",
    "别眨眼，接下来的反转来得很快。",
    "这场对手戏，每一句都在互相试探。",
    "看到这里才明白，前面全是铺垫。",
]
BEATS = [
    "人物关系一上来就绷紧，谁在算计谁，一眼看不透。",
    "一个关键选择，把所有人的位置重新洗牌。",
    "表面风平浪静，暗地里每一步都在做局。",
    "情绪被推到顶点，台词一句比一句扎心。",
    "真正的高手，不吵不闹，只用结果说话。",
]
TAILS = [
    "后面还有更大的局，接着往下看。",
    "这一局谁输谁赢，下一段见分晓。",
    "故事才刚开始，真正的底牌还没亮。",
]


def make_commentary(title, seed):
    rnd = random.Random(seed)
    parts = [f"注意看，这部《{title}》" + rnd.choice(HOOKS)]
    picked = rnd.sample(BEATS, 4)
    parts += picked
    parts.append("故事走到这里，已经不是谁对谁错的问题，而是谁能先一步看清局面。")
    parts += rnd.sample([b for b in BEATS if b not in picked], 2)
    parts.append(rnd.choice(TAILS))
    text = "".join(parts)
    while len(text) < 320:
        pool = [b for b in BEATS if b not in text]
        text += rnd.choice(pool) if pool else rnd.choice(BEATS)
    return text


def tts(text, out_mp3, voice):
    script = "import sys, asyncio, edge_tts\n" \
             "text, voice, out = sys.argv[1], sys.argv[2], sys.argv[3]\n" \
             "async def main():\n" \
             "    c = edge_tts.Communicate(text, voice)\n" \
             "    await c.save(out)\n" \
             "asyncio.run(main())\n"
    rc, _, err = run([sys.executable, "-c", script, text, voice, out_mp3], timeout=300)
    if os.path.isfile(out_mp3) and os.path.getsize(out_mp3) > 1024:
        return True, ""
    return False, err[-500:]


def split_sentences(text, max_len=18):
    parts = re.split(r"(?<=[。！？!?；;])", text)
    out = []
    for p in parts:
        p = p.strip()
        while len(p) > max_len:
            out.append(p[:max_len])
            p = p[max_len:]
        if p:
            out.append(p)
    return out


def write_srt(sentences, total_dur, path):
    weights = [max(1, len(s)) for s in sentences]
    unit = total_dur / sum(weights)
    t = 0.0
    lines = []
    for i, s in enumerate(sentences, 1):
        d = weights[i - 1] * unit
        lines.append(f"{i}\n{fmt_ts(t)} --> {fmt_ts(t + d - 0.05)}\n{s}\n")
        t += d
    with open(path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines))


def fmt_ts(t):
    h = int(t // 3600)
    m = int(t % 3600 // 60)
    s = t % 60
    return f"{h:02d}:{m:02d}:{s:06.3f}".replace(".", ",")


def _ass_ts(t):
    t = max(0.0, float(t))
    h = int(t // 3600)
    m = int(t % 3600 // 60)
    s = t % 60
    return f"{h:d}:{m:02d}:{s:05.2f}"


def write_ass(items, W, H, path, fs_factor=0.046):
    """items: [(start, end, text)]。ASS 自带 PlayRes，单位即像素，避免 libass 288 缩放。"""
    fs = max(18, int(round(H * fs_factor)))
    outline = max(2, int(round(H * 0.0028)))
    mv = int(round(H * 0.16))
    ml = int(round(W * 0.06))
    head = [
        "[Script Info]",
        "ScriptType: v4.00+",
        f"PlayResX: {W}",
        f"PlayResY: {H}",
        "WrapStyle: 2",
        "ScaledBorderAndShadow: yes",
        "",
        "[V4+ Styles]",
        "Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding",
        f"Style: Default,Microsoft YaHei,{fs},&H00FFFFFF,&H000000FF,&H00000000,&H80000000,0,0,0,0,100,100,0,0,1,{outline},1,2,{ml},{ml},{mv},1",
        "",
        "[Events]",
        "Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text",
    ]
    body = []
    for a, b, text in items:
        if b - a < 0.15 or not text.strip():
            continue
        t = text.replace("\\", "\\\\").replace("{", "(").replace("}", ")").replace("\n", " ")
        body.append(f"Dialogue: 0,{_ass_ts(a)},{_ass_ts(b)},Default,,0,0,0,,{t}")
    with open(path, "w", encoding="utf-8") as f:
        f.write("\n".join(head + body) + "\n")


def _decode_audio(path, sr=8000):
    if np is None:
        return None, sr
    p = subprocess.run([FFMPEG, "-v", "error", "-i", path, "-vn", "-ac", "1",
                        "-ar", str(sr), "-f", "s16le", "-"], capture_output=True)
    buf = p.stdout
    if not buf:
        return None, sr
    return np.frombuffer(buf, dtype=np.int16).astype(np.float32) / 32768.0, sr


def _decode_motion(path, w=128, h=72, fps=2):
    if np is None:
        return None, fps
    p = subprocess.run([FFMPEG, "-v", "error", "-i", path, "-vf",
                        f"fps={fps},scale={w}:{h},format=gray", "-f", "rawvideo", "-"],
                       capture_output=True)
    buf = p.stdout
    n = len(buf) // (w * h)
    if n < 2:
        return None, fps
    arr = np.frombuffer(buf[:n * w * h], dtype=np.uint8).reshape(n, h, w).astype(np.float32)
    diff = np.abs(np.diff(arr, axis=0)).mean(axis=(1, 2))
    return diff, fps


def _window_scores(clip, win=10.0, hop=2.0):
    dur = clip.get("duration") or 0
    if dur <= win:
        return []
    audio, sr = _decode_audio(clip["path"])
    motion, mfps = _decode_motion(clip["path"])
    if audio is None and motion is None:
        return []
    rows = []
    s = 0.5
    while s + win <= dur - 0.5:
        av = mv = 0.0
        if audio is not None and len(audio):
            i0, i1 = int(s * sr), min(len(audio), int((s + win) * sr))
            if i1 > i0:
                seg = audio[i0:i1]
                av = float(np.sqrt(np.mean(seg * seg)))
        if motion is not None and len(motion):
            j0 = max(0, int((s - 0.5) * mfps))
            j1 = min(len(motion), int((s + win - 0.5) * mfps))
            if j1 > j0:
                mv = float(np.mean(motion[j0:j1]))
        rows.append({"start": float(s), "audio": av, "motion": mv})
        s += hop
    return rows


def _silence_points(path, noise="-30dB", min_sil=0.30):
    """静音区间中点：优先作为“台词完整处”的切点。"""
    cmd = [FFMPEG, "-v", "info", "-i", path,
           "-af", f"silencedetect=noise={noise}:d={min_sil}", "-f", "null", "-"]
    p = subprocess.run(cmd, capture_output=True)
    txt = (p.stderr or b"").decode("utf-8", "replace")
    starts = [float(x) for x in re.findall(r"silence_start:\s*(-?[\d.]+)", txt)]
    ends = [float(x) for x in re.findall(r"silence_end:\s*(-?[\d.]+)", txt)]
    pts = []
    for s in starts:
        nxt = [e for e in ends if e > s]
        if nxt:
            e = min(nxt)
            if e - s >= min_sil:
                pts.append((s + e) / 2.0)
    return pts


def _scene_points(path, thresh=0.35):
    """镜头切换点：静音不足时兜底，尽量落在句间而不是句中。"""
    cmd = [FFMPEG, "-v", "info", "-i", path, "-an",
           "-vf", f"select='gt(scene,{thresh})',metadata=print", "-f", "null", "-"]
    p = subprocess.run(cmd, capture_output=True)
    txt = (p.stderr or b"").decode("utf-8", "replace")
    return [float(x) for x in re.findall(r"pts_time:\s*([\d.]+)", txt)]


def _cut_points(clip):
    """静音中点切点；ASR 不可用时也只按停顿切，绝不切进句子。"""
    dur = clip.get("duration") or 0
    pts = _silence_points(clip["path"])
    pts = [p for p in pts if 0.5 < p < dur - 0.5]
    pts = [0.0] + pts + [dur]
    pts.sort()
    merged = []
    for p in pts:
        if not merged or p - merged[-1] >= 0.4:
            merged.append(p)
    return merged


_WHISPER = None


def _hf_endpoint():
    """国内网络自动切 HF 镜像；能直连 huggingface.co 就不动。"""
    if os.environ.get("HF_ENDPOINT"):
        return
    import socket
    for host, endpoint in (("huggingface.co", None), ("hf-mirror.com", "https://hf-mirror.com")):
        try:
            socket.create_connection((host, 443), timeout=4).close()
            if endpoint:
                os.environ["HF_ENDPOINT"] = endpoint
                print("HuggingFace 直连不可用，改用镜像:", endpoint, flush=True)
            return
        except Exception:
            continue


def _whisper():
    global _WHISPER
    if _WHISPER is None:
        _hf_endpoint()
        from faster_whisper import WhisperModel
        name = local_asr_dir() or os.environ.get("RECREATE_ASR_MODEL", "medium")
        dev = os.environ.get("RECREATE_ASR_DEVICE", "cpu")
        _WHISPER = WhisperModel(name, device=dev,
                                compute_type="int8" if dev == "cpu" else "float16")
    return _WHISPER


def _load_audio16k(path):
    p = subprocess.run([FFMPEG, "-v", "error", "-i", path, "-vn", "-ac", "1", "-ar", "16000",
                        "-f", "s16le", "-"], capture_output=True)
    return np.frombuffer(p.stdout, dtype=np.int16).astype(np.float32) / 32768.0


def _asr_sentences(clip):
    """Whisper 句级时间戳（带缓存）。失败返回 []。"""
    path = clip["path"]
    cache = path + ".asr.json"
    try:
        with open(cache, "a"):
            pass
    except OSError:
        cache = os.path.join(tempfile.gettempdir(),
                             "recreate_asr_" + hashlib.sha1(path.encode("utf-8", "ignore")).hexdigest() + ".json")
    if os.path.isfile(cache):
        try:
            data = json.load(open(cache, encoding="utf-8-sig"))
            if data.get("sentences"):
                return data["sentences"]
        except Exception:
            pass
    try:
        audio = _load_audio16k(path)
        if not len(audio):
            return []
        print("ASR start:", os.path.basename(path), flush=True)
        model = _whisper()
        segs, _ = model.transcribe(audio, language="zh", vad_filter=True, beam_size=1,
                                   condition_on_previous_text=False,
                                   initial_prompt="以下是简体中文短剧对白，请用简体中文输出。")
        out = []
        for s in segs:
            t = (s.text or "").strip()
            if not t:
                continue
            out.append({"start": round(float(s.start), 2), "end": round(float(s.end), 2), "text": t})
        # 合并被切碎的短片段（同一句被 VAD 切两半）
        merged = []
        for s in out:
            if merged and (s["end"] - s["start"] < 0.8 or len(s["text"]) < 4) \
                    and s["start"] - merged[-1]["end"] < 0.35:
                merged[-1]["end"] = s["end"]
                merged[-1]["text"] += s["text"]
            else:
                merged.append(dict(s))
        try:
            json.dump({"model": os.environ.get("RECREATE_ASR_MODEL", "medium"),
                       "sentences": merged},
                      open(cache, "w", encoding="utf-8"), ensure_ascii=False)
        except Exception:
            pass
        print("ASR done:", os.path.basename(path), len(merged), "sentences", flush=True)
        return merged
    except Exception as e:
        print("ASR failed:", path, e, flush=True)
        return []


def _sentence_windows(sentences, lo, hi):
    """由连续完整句组成的窗口，两端都落在句子边界。"""
    wins = []
    for i in range(len(sentences)):
        t0 = sentences[i]["start"]
        for j in range(i, len(sentences)):
            t1 = sentences[j]["end"]
            d = t1 - t0
            if d > hi:
                break
            if d >= lo:
                wins.append({"a": t0, "b": t1, "subs": sentences[i:j + 1]})
    return wins


def asr_model_present(model=None):
    if local_asr_dir():
        return True
    name = model or os.environ.get("RECREATE_ASR_MODEL", "medium")
    snap = os.path.join(os.path.expanduser("~"), ".cache", "huggingface", "hub",
                        f"models--Systran--faster-whisper-{name}", "snapshots")
    if os.path.isdir(snap):
        for d in os.listdir(snap):
            p = os.path.join(snap, d, "model.bin")
            try:
                if os.path.isfile(p) and os.path.getsize(p) > 1_400_000_000:
                    return True
            except OSError:
                pass
    return False


def ensure_models(auto_install=True):
    """新设备开剪前：ASR + VLM 模型必须就绪；缺则多源下载（断点续传）。"""
    if not asr_model_present():
        script = os.path.join(PKG_ROOT, "scripts", "fetch_asr_model.py")
        if os.path.isfile(script):
            print("[模型] 多源下载 ASR 模型（约 1.5GB，可断点续传）...", flush=True)
            subprocess.run([sys.executable, script], timeout=1800)
        if not asr_model_present():
            try:
                from faster_whisper import WhisperModel
                WhisperModel(os.environ.get("RECREATE_ASR_MODEL", "medium"),
                             device="cpu", compute_type="int8")
            except Exception as e:
                return False, {"asr": f"下载失败：{e}", "vlm": "未检查"}
    if not ensure_vlm(auto_install=auto_install):
        return False, {"asr": "ok", "vlm": "未就绪（Ollama/模型安装失败）"}
    return True, {"asr": "ok", "vlm": "ok"}


ASSET_CACHE_VER = 2


def _asset_cache_paths(clip):
    yield clip["path"] + ".asset_review.json"
    key = hashlib.sha1(clip["path"].encode("utf-8", "ignore")).hexdigest()
    yield os.path.join(tempfile.gettempdir(), "recreate_asset_" + key + ".json")


def _asset_cache(clip):
    p = next(_asset_cache_paths(clip))
    try:
        st = os.stat(clip["path"])
        key = f"{st.st_size}:{int(st.st_mtime)}:{VLM_MODEL}:{ASSET_CACHE_VER}"
        for p in _asset_cache_paths(clip):
            try:
                data = json.load(open(p, encoding="utf-8"))
                if data.get("key") == key:
                    return data.get("result")
            except Exception:
                continue
    except Exception:
        pass
    return None


def _asset_cache_save(clip, result):
    try:
        st = os.stat(clip["path"])
        key = f"{st.st_size}:{int(st.st_mtime)}:{VLM_MODEL}:{ASSET_CACHE_VER}"
        for p in _asset_cache_paths(clip):
            try:
                json.dump({"key": key, "result": result}, open(p, "w", encoding="utf-8"),
                          ensure_ascii=False)
                break
            except OSError:
                continue
    except Exception:
        pass


def review_asset_clips(clips, workdir, model=None):
    """选段前双重审核素材；同一素材审核结果缓存，重复批量不再跑模型。"""
    results, keep = [], []
    for clip in clips:
        cached = _asset_cache(clip)
        if cached:
            entry = dict(cached); entry["cached"] = True
            results.append(entry)
            if not (entry.get("rule_flagged") and entry.get("model_flagged")):
                keep.append(clip)
            continue
        frames = sample_review_frames(clip["path"], workdir, 3)
        rule_hits, model_hits = [], []
        model_vlm_fail = 0
        for ts, jpg in frames:
            rr = frame_red_ratio(clip["path"], ts)
            lum, sharp = frame_quality(clip["path"], ts)
            if rr > 0.35 or lum < 18 or sharp < 4.0:
                rule_hits.append(f"{ts}s 画面规则")
            try:
                r = vlm_check_frame(jpg, model)
                if r.get("risk"):
                    model_hits.append({"ts": ts, "cats": r.get("cats") or [], "reason": r.get("reason", "")})
            except Exception:
                model_vlm_fail += 1
                if model_vlm_fail >= 2:
                    break
                continue
        sens = _asr_sentences(clip)
        text = " ".join(s.get("text", "") for s in (sens or []))
        story = story_review(text) if text.strip() else {"rule_issues": [], "model_issues": []}
        rule_hits += story.get("rule_issues", [])
        model_issues = [f"剧情：{x}" for x in story.get("model_issues", [])]
        rule_flag = bool(rule_hits)
        model_flag = len(model_hits) >= 2 or bool(model_issues)
        entry = {"clip": os.path.basename(clip["path"]), "rule_flagged": rule_flag,
                 "model_flagged": model_flag, "rule_hits": rule_hits[:5],
                 "model_hits": model_hits[:5], "model_issues": model_issues[:5]}
        _asset_cache_save(clip, entry)
        results.append(entry)
        if not (rule_flag and model_flag):
            keep.append(clip)
        else:
            print(f"[素材审核] 跳过 {entry['clip']}：规则+模型均命中", flush=True)
    return keep, results


def plan_highlights(clips, total, seg_len, seed, safe="strict"):
    """按句级时间戳选段：每段起止都落在完整句子边界，杜绝切断台词。"""
    rnd = random.Random(seed)
    n = max(6, int(round(total / seg_len)) + rnd.randint(-1, 1))
    lo, hi = max(6.5, seg_len - 2.5), seg_len + 2.5
    feats = []
    for clip in clips:
        audio, sr = _decode_audio(clip["path"])
        motion, mfps = _decode_motion(clip["path"])
        feats.append({"clip": clip, "a": audio, "sr": sr,
                      "m": motion, "mf": mfps, "cuts": _cut_points(clip)})

    def score(f, a, b):
        av = mv = 0.0
        A, sr = f["a"], f["sr"]
        if A is not None and len(A):
            i0, i1 = int(a * sr), min(len(A), int(b * sr))
            if i1 > i0:
                av = float(np.sqrt(np.mean(A[i0:i1] ** 2)))
        M, mf = f["m"], f["mf"]
        if M is not None and len(M):
            j0, j1 = max(0, int((a - 0.5) * mf)), min(len(M), int((b - 0.5) * mf))
            if j1 > j0:
                mv = float(np.mean(M[j0:j1]))
        return av, mv

    asr_ok = False
    rejected_text = soft_hits = 0
    cand = []
    for ci, f in enumerate(feats):
        sens = _asr_sentences(f["clip"])
        wins = _sentence_windows(sens, lo, hi) if sens else []
        if wins:
            asr_ok = True
        if not wins:                      # ASR 不可用时退回停顿/镜头切点
            cuts = f["cuts"]
            for i, a in enumerate(cuts):
                for b in cuts[i + 1:]:
                    d = b - a
                    if d < lo:
                        continue
                    if d > hi:
                        break
                    wins.append({"a": a, "b": b, "subs": []})
        for w in wins:
            if safe == "strict" and w["subs"]:
                txt = " ".join(s["text"] for s in w["subs"])
                hard, soft = scan_text_safety(txt)
                soft_hits += len(soft)
                if hard:
                    rejected_text += 1
                    continue
            av, mv = score(f, w["a"], w["b"])
            cand.append((av, mv, ci, w["a"], w["b"], w["b"] - w["a"], w["subs"]))

    chosen = []
    if cand:
        au = sorted(c[0] for c in cand)
        mo = sorted(c[1] for c in cand)
        pa = au[int(len(au) * 0.9)] or 1.0
        pm = mo[int(len(mo) * 0.9)] or 1.0
        scored = sorted((((0.6 * min(1.0, c[0] / pa) + 0.4 * min(1.0, c[1] / pm))
                          * rnd.uniform(0.88, 1.12),
                          c[2], c[3], c[4], c[5], c[6]) for c in cand), reverse=True)
        per_clip_cap = max(3, n // len(clips) + 2)
        used = {i: [] for i in range(len(clips))}
        # 加权随机抽样（无放回）：同样素材每次选段不同，但仍偏向高能量窗口
        pool = list(range(len(scored)))
        weights = [max(0.05, item[0] ** 2) for item in scored]
        while pool and len(chosen) < n:
            total_w = sum(weights[i] for i in pool)
            r = rnd.uniform(0, total_w)
            acc = 0.0
            pick = pool[0]
            for i in pool:
                acc += weights[i]
                if acc >= r:
                    pick = i
                    break
            pool.remove(pick)
            item = scored[pick]
            sc, ci, a, b, d, subs = item
            if len(used[ci]) >= per_clip_cap:
                continue
            if any(not (a >= u2 or b <= u1) for u1, u2 in used[ci]):
                continue
            used[ci].append((a, b))
            chosen.append(item)
        # 画面粗筛：血色占比过高的段直接剔除，从剩余候选补位
        rejected_visual = 0
        rejected_lowq = 0
        if safe == "strict":
            kept = []
            for item in chosen:
                sc, ci, a, b = item[0], item[1], item[2], item[3]
                mid = (a + b) / 2
                if frame_red_ratio(clips[ci]["path"], mid) > 0.35:
                    rejected_visual += 1
                    continue
                lum, sharp = frame_quality(clips[ci]["path"], mid)
                if lum < 18 or sharp < 4.0:
                    rejected_lowq += 1
                    continue
                kept.append(item)
            chosen = kept
            if len(chosen) < n:
                for item in scored:
                    if len(chosen) >= n:
                        break
                    sc, ci, a, b, d, subs = item
                    if any(x is item for x in chosen):
                        continue
                    mid = (a + b) / 2
                    if frame_red_ratio(clips[ci]["path"], mid) > 0.35:
                        rejected_visual += 1
                        continue
                    lum, sharp = frame_quality(clips[ci]["path"], mid)
                    if lum < 18 or sharp < 4.0:
                        rejected_lowq += 1
                        continue
                    chosen.append(item)
        if safe == "strict":
            SAFETY["lowq_rejected"] = rejected_lowq
        # 时长不够就再补（仍取完整句窗口）
        raw = sum(c[4] for c in chosen)
        for item in scored:
            if len(chosen) >= n + 4:
                break
            if raw >= total * 0.97:
                break
            sc, ci, a, b, d, subs = item
            if any(x is item for x in chosen):
                continue
            if len(used[ci]) >= per_clip_cap + 2:
                continue
            if any(not (a >= u2 or b <= u1) for u1, u2 in used[ci]):
                continue
            used[ci].append((a, b))
            chosen.append(item)
            raw += d
    if safe == "strict" and len(chosen) < 4:
        return []
    # 极少见兜底：没有任何候选
    while len(chosen) < n:
        ci = rnd.randrange(len(clips))
        dur = feats[ci]["clip"].get("duration") or (seg_len * 2)
        st = rnd.uniform(0.5, max(0.6, dur - seg_len - 1))
        chosen.append((rnd.uniform(0.3, 0.6), ci, round(st, 2), round(st + seg_len, 2), seg_len, []))

    SAFETY.update({"enabled": safe == "strict", "text_rejected": rejected_text,
                   "visual_rejected": rejected_visual, "asr_available": asr_ok,
                   "soft_hits": soft_hits})
    # 超长则丢掉最弱段，保证总时长贴近目标
    while len(chosen) > 1 and sum(c[4] for c in chosen) > total * 1.15:
        chosen.remove(min(chosen, key=lambda c: c[0]))
    chosen.sort(key=lambda x: x[0])       # 由弱到强
    # 用统一缩放把总时长压到 total 附近，保住句子边界
    raw = sum(c[4] for c in chosen) or 1.0
    scale = max(0.85, min(1.15, raw / max(1.0, total)))
    segments = []
    for i, (sc, ci, a, b, d, subs) in enumerate(chosen):
        base = [1.0, 1.04, 0.96][i % 3]
        speed = round(max(0.85, min(1.15, base * scale * rnd.uniform(0.97, 1.03))), 4)
        out_dur = round(d / speed, 3)
        segments.append({"clip": clips[ci]["path"], "start": round(float(a), 2),
                         "dur": out_dur, "take": round(float(d), 3),
                         "speed": speed, "has_audio": clips[ci].get("has_audio", False),
                         "score": round(float(sc), 3),
                         "subs": [{"start": s["start"], "end": s["end"], "text": s["text"]}
                                  for s in subs],
                         "sentence_aligned": bool(subs) or asr_ok,
                         "cut_aligned": bool(subs) or asr_ok})
    return segments


def plan_segments(clips, total, seg_len, seed, safe="strict"):
    rnd = random.Random(seed)
    n = max(6, int(round(total / seg_len)) + rnd.randint(-1, 1))
    seg_len = total / n
    segments = []
    for i in range(n):
        clip = clips[i % len(clips)]
        speed = [1.0, 1.04, 0.96][i % 3]
        take = seg_len * speed
        max_start = max(1.0, clip["duration"] - take - 2.0)
        start = rnd.uniform(1.0, max_start)
        if safe == "strict" and frame_red_ratio(clip["path"], start + take / 2) > 0.35:
            start = rnd.uniform(1.0, max_start)
        segments.append({"clip": clip["path"], "start": round(start, 2),
                         "dur": seg_len, "take": round(take, 2),
                         "speed": speed, "has_audio": clip.get("has_audio", False)})
    return segments


def render_segment(seg, idx, out_path, W, H, workdir, mirror=False, keep_src_subs=False,
                   fps=30, zoom=1.0, eq_c=1.05, eq_s=1.12, vig=0.52, noise=4):
    """逐段渲染；fps/zoom/调色/颗粒可随机，用于让每条成片都不一样。"""
    flip = "hflip," if (mirror and idx % 2) else ""
    spd = seg.get("speed", 1.0)
    crop = "crop=iw:ih*0.72:0:0," if (seg.get("subs") and not keep_src_subs) else ""
    if zoom > 1.001:
        fit = f"scale={int(W * zoom)}:{int(H * zoom)}:force_original_aspect_ratio=increase,crop={W}:{H}"
    else:
        fit = f"scale={W}:{H}:force_original_aspect_ratio=decrease"
        if crop:
            fit += f",crop={W}:{H}"
    speed_pre = f"setpts=(1/{spd:.4f})*PTS," if abs(spd - 1.0) > 0.001 else ""
    vf = (
        f"[0:v]{speed_pre}fps={fps},split=2[bg][fg];"
        f"[bg]scale={max(2, W // 4)}:{max(2, H // 4)},gblur=sigma=12,scale={W}:{H},setsar=1[bgv];"
        f"[fg]{crop}{fit},{flip}setsar=1[fgv];"
        f"[bgv][fgv]overlay=({W}-w)/2:({H}-h)/2,"
        f"eq=contrast={eq_c:.3f}:saturation={eq_s:.3f},vignette=PI*{vig:.3f},"
        f"noise=alls={noise}:allf=t+u,"
        "tpad=stop_mode=clone:stop_duration=1,format=yuv420p[v]"
    )
    dur = seg["dur"]
    cmd = [FFMPEG, "-y", "-ss", str(seg["start"]), "-t", str(seg["take"]), "-i", seg["clip"]]
    has_audio = seg.get("has_audio")
    if has_audio:
        af = (f"atempo={spd:.3f}," if abs(spd - 1.0) > 0.001 else "")
        af += f"aresample=44100,apad,atrim=0:{dur:.3f},asetpts=PTS-STARTPTS"
        cmd += ["-filter_complex", vf + f";[0:a]{af}[a]", "-map", "[v]", "-map", "[a]"]
    else:
        cmd += ["-f", "lavfi", "-t", str(dur), "-i", "anullsrc=r=44100:cl=stereo"]
        cmd += ["-filter_complex", vf, "-map", "[v]", "-map", "1:a"]
    frames = max(1, int(round(dur * fps)))
    cmd += ["-c:v", "libx264", "-preset", "veryfast", "-crf", "20",
            "-c:a", "aac", "-b:a", "128k", "-ar", "44100", "-ac", "2",
            "-t", f"{dur + 0.2:.3f}", "-frames:v", str(frames), "-r", str(fps),
            "-video_track_timescale", "90000", out_path]
    rc, _, err = run(cmd, cwd=workdir)
    if rc != 0:
        raise RuntimeError(f"segment {idx} failed: {err[-2000:]}")
    return out_path


TRANSITION_SEC = 0.4


def overlay_dir(sub):
    for base in (os.path.join(PKG_ROOT, "assets", "overlays"),
                 os.path.join(os.environ.get("LOCALAPPDATA", os.path.expanduser("~")),
                              "recreate-studio", "assets", "overlays")):
        d = os.path.join(base, sub)
        try:
            os.makedirs(d, exist_ok=True)
            probe = os.path.join(d, ".w")
            open(probe, "w").close(); os.remove(probe)
            return d
        except OSError:
            continue
    return ""


def ffmpeg_has_filter(name):
    try:
        p = subprocess.run([FFMPEG, "-hide_banner", "-filters"], capture_output=True, timeout=30)
        return name in p.stdout.decode("utf-8", "ignore")
    except Exception:
        return False


def ensure_particles():
    """本地生成半透明粒子 PNG，避免外部素材版权问题。"""
    d = overlay_dir("particles")
    if not d:
        return []
    files = [os.path.join(d, f"p{i}.png") for i in range(1, 4)]
    if all(os.path.isfile(f) for f in files):
        return files
    try:
        from PIL import Image, ImageDraw, ImageFilter
        import random as _r
        for idx, path in enumerate(files, 1):
            img = Image.new("RGBA", (720, 1280), (0, 0, 0, 0))
            dr = ImageDraw.Draw(img)
            for _ in range(_r.randint(18, 30)):
                x, y = _r.randint(0, 720), _r.randint(0, 1280)
                r = _r.randint(3, 16)
                a = _r.randint(40, 120)
                dr.ellipse([x - r, y - r, x + r, y + r], fill=(255, 255, 255, a))
            img = img.filter(ImageFilter.GaussianBlur(2))
            img.save(path)
        return files
    except Exception:
        return []


def render_intro(cover, out_path, W, H, workdir, secs=2.5):
    """封面片头：铺满画布 + 缓慢推近，不带字幕。"""
    frames = max(15, int(round(secs * 30)))
    vf = (
        f"[0:v]scale={W}:{H}:force_original_aspect_ratio=increase,crop={W}:{H},"
        f"zoompan=z='min(zoom+0.0015,1.08)':d={frames}:s={W}x{H}:fps=30,"
        f"eq=contrast=1.03:saturation=1.08,fade=t=in:st=0:d=0.35:color=white,format=yuv420p[v]"
    )
    cmd = [FFMPEG, "-y", "-i", cover,
           "-f", "lavfi", "-t", str(secs), "-i", "anullsrc=r=44100:cl=stereo",
           "-filter_complex", vf, "-map", "[v]", "-map", "1:a", "-shortest",
           "-c:v", "libx264", "-preset", "veryfast", "-crf", "20",
           "-c:a", "aac", "-b:a", "128k", "-ar", "44100", "-ac", "2",
           "-t", str(secs), "-video_track_timescale", "90000", out_path]
    rc, _, err = run(cmd, cwd=workdir)
    if rc != 0:
        raise RuntimeError(f"intro failed: {err[-600:]}")
    return out_path


def rife_exe():
    for root in (os.environ.get("RECREATE_RIFE", ""),
                 os.path.join(PKG_ROOT, "tools", "rife-ncnn-vulkan"),
                 r"D:\AI\tools\rife-ncnn-vulkan"):
        if not root or not os.path.isdir(root):
            continue
        for dp, _, fs in os.walk(root):
            if "rife-ncnn-vulkan.exe" in fs:
                return os.path.join(dp, "rife-ncnn-vulkan.exe")
    return ""


def ensure_rife():
    exe = rife_exe()
    if exe:
        return exe
    script = os.path.join(PKG_ROOT, "scripts", "ensure_rife.py")
    if os.path.isfile(script):
        print("[补帧] 首次下载 RIFE（约 411MB）...", flush=True)
        subprocess.run([sys.executable, script], timeout=1800)
    return rife_exe()


def ffmpeg_interpolate(path, work, factor=2):
    """无 RIFE/无 GPU 时的 CPU 补帧兜底（慢）。"""
    info = probe(path)
    dur = float(info.get("duration") or 0)
    if dur <= 0:
        return path, False
    tmp = os.path.join(work, "interp_cpu.mp4")
    print("[补帧] 改用 ffmpeg minterpolate（CPU，较慢）...", flush=True)
    rc, _, err = run([FFMPEG, "-y", "-i", path,
                      "-vf", f"minterpolate=fps=60:mi_mode=mci:mc_mode=aobmc:me_mode=bidir:vsbmc=1",
                      "-c:v", "libx264", "-preset", "veryfast", "-crf", "20",
                      "-c:a", "copy", tmp], timeout=14400)
    if rc != 0 or not os.path.isfile(tmp):
        return path, False
    try:
        if os.path.exists(path):
            os.remove(path)
        shutil.move(tmp, path)
    except Exception:
        return path, False
    return path, True


def interpolate_video(path, work, factor=2):
    """RIFE 显卡补帧：抽帧 → 插帧 → 按新帧率编码，音频原样。"""
    exe = ensure_rife()
    if not exe:
        print("[补帧] RIFE 不可用，尝试 CPU 补帧", flush=True)
        return ffmpeg_interpolate(path, work, factor)
    info = probe(path)
    dur = float(info.get("duration") or 0)
    raw = str(info.get("fps") or "25")
    if "/" in raw:
        a, b = raw.split("/", 1)
        fps = float(a) / max(1.0, float(b))
    else:
        fps = float(raw or 25)
    if dur <= 1:
        return path, False
    fin = os.path.join(work, "rife_in")
    fout = os.path.join(work, "rife_out")
    os.makedirs(fin, exist_ok=True); os.makedirs(fout, exist_ok=True)
    rc, _, err = run([FFMPEG, "-y", "-i", path, "-vf", f"fps={fps:.3f}",
                      "-q:v", "2", os.path.join(fin, "%06d.jpg")], timeout=1800)
    n = len([x for x in os.listdir(fin) if x.endswith(".jpg")])
    if n < 2:
        print("[补帧] 抽帧失败", flush=True)
        return path, False
    model = os.path.join(os.path.dirname(exe), "rife-v4.6")
    if not os.path.isdir(model):
        model = os.path.join(os.path.dirname(exe), "rife-v4")
    print(f"[补帧] RIFE {n} → {n*factor} 帧（GPU）...", flush=True)
    rc, _, err = run([exe, "-i", fin, "-o", fout, "-m", model,
                      "-n", str(n * factor), "-g", "0", "-j", "2:2:2",
                      "-f", "%08d.jpg"], timeout=1800)
    out_n = len([x for x in os.listdir(fout) if x.endswith(".jpg")])
    if out_n < n * factor * 0.9:
        print("[补帧] RIFE 插帧失败，尝试 CPU 兜底", flush=True)
        return ffmpeg_interpolate(path, work, factor)
    tmp = os.path.join(work, "interp.mp4")
    cmd = [FFMPEG, "-y", "-framerate", f"{fps*factor:.3f}", "-i", os.path.join(fout, "%08d.jpg"),
           "-i", path, "-map", "0:v:0", "-map", "1:a?", "-c:v", "libx264", "-preset", "veryfast",
           "-crf", "19", "-c:a", "copy", "-shortest", "-movflags", "+faststart", tmp]
    rc, _, err = run(cmd, timeout=3600)
    if rc != 0 or not os.path.isfile(tmp):
        print("[补帧] 编码失败", flush=True)
        return path, False
    try:
        if os.path.exists(path):
            os.remove(path)
        shutil.move(tmp, path)
    except Exception as e:
        print("[补帧] 回写失败：", e, flush=True)
        return path, False
    print(f"[补帧] 完成：{fps:.0f} → {fps*factor:.0f} fps", flush=True)
    return path, True


def ensure_materials():
    d = overlay_dir("materials")
    if not d:
        return []
    files = [os.path.join(d, f"m{i}.png") for i in range(1, 4)]
    if all(os.path.isfile(f) for f in files):
        return files
    try:
        from PIL import Image, ImageDraw, ImageFilter
        import random as _r
        W, H = 1080, 1920
        # 1 灯漏：暖色径向渐变
        img = Image.new("RGBA", (W, H), (0, 0, 0, 0))
        px = img.load()
        cx, cy = _r.randint(200, W - 200), _r.randint(100, H // 2)
        for y in range(0, H, 4):
            for x in range(0, W, 4):
                dist = ((x - cx) ** 2 + (y - cy) ** 2) ** 0.5
                a = max(0, int(150 * (1 - dist / (W * 0.9))))
                if a:
                    for yy in range(y, min(H, y + 4)):
                        for xx in range(x, min(W, x + 4)):
                            px[xx, yy] = (255, 190, 90, a)
        img = img.filter(ImageFilter.GaussianBlur(40))
        img.save(files[0])
        # 2 光斑
        img = Image.new("RGBA", (W, H), (0, 0, 0, 0)); dr = ImageDraw.Draw(img)
        for _ in range(25):
            x, y, r = _r.randint(0, W), _r.randint(0, H), _r.randint(20, 90)
            dr.ellipse([x - r, y - r, x + r, y + r], fill=(255, 255, 255, _r.randint(10, 45)))
        img.filter(ImageFilter.GaussianBlur(8)).save(files[1])
        # 3 纹理
        img = Image.new("RGBA", (W, H))
        for y in range(H):
            for x in range(0, W, 3):
                v = _r.randint(0, 255); a = _r.randint(0, 30)
                img.putpixel((x, y), (v, v, v, a))
        img.filter(ImageFilter.GaussianBlur(1)).save(files[2])
        return files
    except Exception:
        return []


def concat_segments(paths, out_path, workdir, transitions=True):
    if transitions and len(paths) > 1:
        durs = []
        for p in paths:
            try:
                durs.append(float(probe(p).get("duration") or 0))
            except Exception:
                durs.append(0.0)
        if all(d > TRANSITION_SEC * 2 for d in durs):
            td = TRANSITION_SEC
            kinds = ["fade", "wipeleft", "slideup", "circleopen", "dissolve"]
            graph = []
            graph.append("[0:v]fps=30,format=yuv420p,setsar=1[vn0]")
            graph.append("[0:a]aresample=44100,aformat=channel_layouts=stereo[an0]")
            vcur, acur = "[vn0]", "[an0]"
            offset = 0.0
            for i in range(1, len(paths)):
                offset += durs[i - 1] - td
                k = random.choice(kinds)
                graph.append(f"[{i}:v]fps=30,format=yuv420p,setsar=1[vn{i}]")
                graph.append(f"[{i}:a]aresample=44100,aformat=channel_layouts=stereo[an{i}]")
                graph.append(f"{vcur}[vn{i}]xfade=transition={k}:duration={td}:offset={max(0.1, offset):.3f}[v{i}]")
                graph.append(f"{acur}[an{i}]acrossfade=d={td}[a{i}]")
                vcur, acur = f"[v{i}]", f"[a{i}]"
            cmd = [FFMPEG, "-y"]
            for p in paths:
                cmd += ["-i", p]
            cmd += ["-filter_complex", ";".join(graph), "-map", vcur, "-map", acur,
                    "-c:v", "libx264", "-preset", "veryfast", "-crf", "19",
                    "-c:a", "aac", "-b:a", "192k", "-ar", "44100", "-ac", "2",
                    "-movflags", "+faststart", out_path]
            rc, _, err = run(cmd, cwd=workdir, timeout=3600)
            if rc != 0:
                raise RuntimeError(f"concat xfade failed: {err[-600:]}")
            return out_path
    lst = os.path.join(workdir, "concat.txt")
    with open(lst, "w", encoding="utf-8") as f:
        for p in paths:
            f.write("file '" + p.replace("\\", "/") + "'\n")
    rc, _, err = run([FFMPEG, "-y", "-f", "concat", "-safe", "0", "-i", lst,
                      "-c:v", "copy", "-c:a", "aac", "-b:a", "192k",
                      "-ar", "44100", "-ac", "2", "-fflags", "+genpts", out_path], cwd=workdir)
    if rc != 0:
        raise RuntimeError(f"concat failed: {err[-600:]}")
    return out_path


def bgm_credit(path):
    """按选中的 BGM 文件回溯来源，返回许可/署名提示。"""
    if not path:
        return ""
    try:
        rel = os.path.relpath(path, BGM_DIR).replace(os.sep, "/")
    except Exception:
        return ""
    for r, u in BGM_SOURCES:
        if r == rel:
            if "incompetech" in u:
                return "CC BY 4.0；成片需署名：Music by Kevin MacLeod (incompetech.com), licensed under CC BY 4.0"
            return "Mixkit Stock Music Free License：可商用、免署名"
    return ""


PKG_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
LOCAL_ASR_DIRS = [
    os.path.join(PKG_ROOT, "runtime", "models", "faster-whisper-medium"),
    os.path.join(os.environ.get("LOCALAPPDATA", os.path.expanduser("~")),
                 "recreate-studio", "models", "faster-whisper-medium"),
]


def local_asr_dir():
    for d in LOCAL_ASR_DIRS:
        p = os.path.join(d, "model.bin")
        try:
            if os.path.isfile(p) and os.path.getsize(p) > 1_400_000_000:
                return d
        except OSError:
            pass
    return ""
OLLAMA_API = os.environ.get("OLLAMA_HOST", "http://127.0.0.1:11434").rstrip("/")
VLM_MODEL = os.environ.get("RECREATE_VLM_MODEL", "qwen2.5vl:7b")
VLM_PROMPT = (
    "你是抖音内容审核员。只判断这一帧画面是否违规，按下述类别逐项检查："
    "1) 血腥/伤口/尸体；2) 色情/裸露/擦边；3) 暴力斗殴/管制刀具/枪支；"
    "4) 吸毒/赌博/违禁品；5) 危险动作（玩火/攀高/马路）；6) 未成年人不当；"
    "7) 二维码/联系方式/站外导流；8) 明显搬运水印/台标；"
    "9) 封建迷信/伪科学宣传（符咒法事、算命改运、神婆神医、保健品夸大、伪科学仪器）；"
    "10) 广告极限词/医疗金融夸大/歧视辱骂/教培保过/未成年人营销/二维码联系方式；"
    "11) 涉政涉密/英烈/国旗国徽不当/篡改地图/假冒高仿/盗版盗播；"
    "12) 犯罪教唆（制毒/制枪/投毒/诈骗/开锁教程）；13) 自杀自残细节（方法/教程/相约自杀）；"
    "14) 诈骗/虚假信息/造谣/包治百病/炫富拜金。"
    '严格输出 JSON：{"risk":true/false,"cats":["类别"],"reason":"简短理由"}。'
    "不确定时 risk=false。不要输出 JSON 以外内容。"
)


def _http_json(url, data=None, timeout=3):
    import urllib.request
    req = urllib.request.Request(url, data=data,
                                 headers={"Content-Type": "application/json"} if data else {})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8"))


def _ollama_models():
    try:
        return [m.get("name", "") for m in _http_json(OLLAMA_API + "/api/tags").get("models", [])]
    except Exception:
        return []


def vlm_ready(model=None):
    want = (model or VLM_MODEL).split(":")[0]
    return any(m.split(":")[0] == want or m == (model or VLM_MODEL) for m in _ollama_models())


def _vlm_manifest_exists():
    return os.path.isfile(os.path.join(os.path.expanduser("~"), ".ollama", "models", "manifests",
                                       "registry.ollama.ai", "library", "qwen2.5vl", "7b"))


def _start_ollama_server():
    exe = os.path.join(os.environ.get("LOCALAPPDATA", ""), "Programs", "Ollama", "ollama.exe")
    if not os.path.isfile(exe):
        return False
    try:
        subprocess.Popen([exe, "serve"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                         creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    except Exception:
        return False
    for _ in range(30):
        if vlm_ready():
            return True
        time.sleep(1)
    return vlm_ready()


def ensure_vlm(auto_install=False):
    """确保 Ollama + 视觉模型可用；模型已装但服务没起时自动启动。"""
    if vlm_ready():
        return True
    if _vlm_manifest_exists() and _start_ollama_server():
        return True
    if not auto_install:
        return False
    ps = os.path.join(PKG_ROOT, "bootstrap_vlm.ps1")
    if not os.path.isfile(ps):
        print("[VLM] 缺少 bootstrap_vlm.ps1，跳过视觉审核", flush=True)
        return False
    print("[VLM] 未检测到 Ollama/模型，开始自动安装（首次约 5GB，请耐心等待）...", flush=True)
    try:
        subprocess.run(["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass",
                        "-File", ps, "-Root", PKG_ROOT,
                        "-Model", VLM_MODEL], timeout=5400)
    except Exception as e:
        print("[VLM] 自动安装失败：", e, flush=True)
    for _ in range(20):
        if vlm_ready():
            return True
        time.sleep(3)
    return vlm_ready()


def sample_review_frames(path, outdir, n=10):
    """均匀抽帧，跳过近黑帧；返回 [(ts, jpg)]。"""
    frames = []
    info = probe(path)
    dur = float(info.get("duration") or 0)
    if dur <= 1:
        return frames
    for i in range(n):
        ts = dur * (i + 0.5) / n
        jpg = os.path.join(outdir, f"vlm_{i:02d}.jpg")
        ok = False
        for args in (["-ss", str(ts), "-i", path], ["-i", path, "-ss", str(ts)]):
            try:
                rc, _, _ = run([FFMPEG, "-v", "error", "-nostdin"] + args +
                               ["-frames:v", "1", "-vf", "scale=768:-2", "-q:v", "3", jpg],
                               timeout=25)
                if rc == 0 and os.path.isfile(jpg):
                    ok = True
                    break
            except Exception:
                continue
        if not ok:
            continue
        try:
            lum, _ = frame_quality(path, ts)
        except Exception:
            lum = 99
        if lum >= 12:
            frames.append((round(ts, 2), jpg))
    return frames


def vlm_check_frame(jpg, model=None):
    import base64
    with open(jpg, "rb") as f:
        b64 = base64.b64encode(f.read()).decode()
    payload = {"model": model or VLM_MODEL, "prompt": VLM_PROMPT, "images": [b64],
               "stream": False, "format": "json", "options": {"temperature": 0}}
    data = _http_json(OLLAMA_API + "/api/generate", json.dumps(payload).encode(), timeout=60)
    txt = (data.get("response") or "").strip()
    try:
        data = json.loads(txt)
        return {"risk": bool(data.get("risk")), "cats": data.get("cats") or [],
                "reason": (data.get("reason") or "")[:120]}
    except Exception:
        return {"risk": False, "cats": [], "reason": ""}


def vlm_review_video(path, workdir, n=10, model=None):
    frames = sample_review_frames(path, workdir, n)
    hits = []
    rule_hits = []
    failures = 0
    for ts, jpg in frames:
        rr = frame_red_ratio(path, ts)
        lum, sharp = frame_quality(path, ts)
        if rr > 0.35 or lum < 18 or sharp < 4.0:
            reason = []
            if rr > 0.35:
                reason.append(f"强红{rr:.2f}")
            if lum < 18:
                reason.append(f"近黑{lum:.0f}")
            if sharp < 4.0:
                reason.append(f"模糊{sharp:.1f}")
            rule_hits.append({"ts": ts, "cats": ["规则画面"], "reason": "/".join(reason),
                              "source": "rule"})
        try:
            r = vlm_check_frame(jpg, model)
        except Exception as e:
            failures += 1
            if failures >= 2:
                return {"available": True, "frames": len(frames), "hits": hits + rule_hits,
                        "rule_hits": rule_hits, "model_hits": hits,
                        "error": f"连续调用失败，已停止（{e}）"}
            continue
        if r["risk"]:
            hits.append({"ts": ts, "cats": r["cats"], "reason": r["reason"],
                         "source": "model"})
    return {"available": True, "frames": len(frames),
            "hits": rule_hits + hits, "rule_hits": rule_hits,
            "model_hits": hits}


def story_review(text, model=None):
    """剧情/台词合规审查：优先用同一个本地模型，失败退回关键词规则。"""
    text = (text or "").strip()
    if not text:
        return {"available": False, "issues": [], "note": "无转写文本"}
    hard, soft = scan_text_safety(text)
    rule_issues = [f"敏感词：{w}" for w in hard[:8]]
    soft_notes = [f"风险词：{w}" for w in soft[:8]]
    model_issues = []
    issues = list(rule_issues) + list(soft_notes)
    if vlm_ready():
        try:
            prompt = (
                "你是短剧内容审核员。根据下面的台词全文，判断剧情是否存在违规风险："
                "犯罪教唆、自杀自残、未成年恋爱、色情低俗、炫富拜金、封建迷信/伪科学、诈骗、站外导流、广告极限词、医疗金融夸大、歧视辱骂、教培保过、价值观极端、涉政涉密、假冒盗版。"
                '严格输出 JSON：{"risk":true/false,"issues":["简短问题"]}。'
                "不要输出 JSON 以外内容。\n台词：\n" + text[:4000]
            )
            payload = {"model": model or VLM_MODEL, "prompt": prompt, "stream": False,
                       "format": "json", "options": {"temperature": 0}}
            data = json.loads((_http_json(OLLAMA_API + "/api/generate",
                                          json.dumps(payload).encode(), timeout=90).get("response") or "{}").strip())
            if data.get("risk"):
                model_issues = [f"剧情：{x}" for x in (data.get("issues") or [])[:8]]
                issues += model_issues
        except Exception:
            pass
    return {"available": True, "issues": issues, "soft_notes": soft_notes,
            "rule_issues": rule_issues, "model_issues": model_issues}


def postcheck_video(path, title, target_duration=0.0):
    """成品自检：抽样帧查强红/黑屏/极模糊，扫标题敏感词；返回问题列表。"""
    issues = []
    hard, _ = scan_text_safety(title or "")
    if hard:
        issues.append("标题含敏感词：" + "、".join(hard[:5]))
    try:
        info = probe(path)
        dur = float(info.get("duration") or 0)
    except Exception:
        dur = 0.0
    if dur <= 1:
        return issues + ["成品无法读取或时长异常"]
    n = 10
    for i in range(n):
        ts = dur * (i + 0.5) / n
        rr = frame_red_ratio(path, ts)
        lum, sharp = frame_quality(path, ts)
        if rr > 0.35:
            issues.append(f"{ts:.1f}s 强红占比 {rr:.2f}（疑似血腥）")
        if lum < 15:
            issues.append(f"{ts:.1f}s 画面近黑（亮度 {lum:.0f}）")
        if sharp < 3.0:
            issues.append(f"{ts:.1f}s 画面极模糊（锐度 {sharp:.1f}）")
    base = max(float(target_duration or 0), 32.0)   # 短样片最低 30s 内容 + 片头
    if base and (dur < base * 0.6 or dur > base * 1.6):
        issues.append(f"时长异常：{dur:.1f}s（预期约 {base:.0f}s）")
    return issues


def final_render(timeline, narration, bgm, subs, out_path, W, H, watermark, total, workdir,
                 acting_mark=True, bgm_volume=0.12,
                 wm_font=None, wm_margin=24, particles=True, progress_bar=True, materials=True):
    inputs = [FFMPEG, "-y", "-i", timeline]
    n = 1
    nar_idx = None
    bgm_idx = None
    if narration and os.path.isfile(narration):
        inputs += ["-i", narration]
        nar_idx = n; n += 1
    if bgm and os.path.isfile(bgm):
        inputs += ["-stream_loop", "-1", "-i", bgm]
        bgm_idx = n; n += 1
    part_idx = None
    if particles:
        pfiles = ensure_particles()
        if pfiles:
            inputs += ["-stream_loop", "-1", "-i", random.choice(pfiles)]
            part_idx = n; n += 1
    mat_idx = None
    if materials:
        mfiles = ensure_materials()
        if mfiles:
            inputs += ["-stream_loop", "-1", "-i", random.choice(mfiles)]
            mat_idx = n; n += 1
    bar_idx = None
    if progress_bar:
        inputs += ["-f", "lavfi", "-t", str(total), "-i", f"color=c=white:s={W}x12:r=30"]
        bar_idx = n; n += 1

    vf = []
    # 烧录字幕时先铺一条半透明字幕条，盖住源片自带字幕（避免重影）
    if subs and os.path.isfile(subs) and subs.lower().endswith(".ass"):
        pass  # 源字幕用画面裁切处理，不再压黑条
    if acting_mark and FONT:
        vf.append(
            f"drawtext=fontfile='{FONT_ESC}':text='AI演绎':fontsize={max(14, H // 56)}:"
            "fontcolor=white@0.38:x=24:y=24:shadowcolor=black@0.4:shadowx=1:shadowy=1"
        )
    wm = (watermark or "").replace(":", "\\:").replace("'", "")
    if wm and FONT:
        vf.append(
            f"drawtext=fontfile='{FONT_ESC}':text='{wm}':fontsize={wm_font or max(14, H // 28)}:"
            f"fontcolor=white@0.55:x=w-tw-{wm_margin}:y={wm_margin}:shadowcolor=black@0.45:shadowx=1:shadowy=1"
        )
    # libass 以 288 行为基准缩放 force_style 的单位；这里换算回像素意图
    scale = 288.0 / H
    fs_units = max(6, round(max(22, H // 36) * scale))
    mv_units = max(8, round(max(60, H // 8) * scale))
    ol_units = max(1, round(3 * scale))
    sub_style = (f"FontName=Microsoft YaHei,FontSize={fs_units},"
                 "PrimaryColour=&H00FFFFFF,OutlineColour=&H00000000,BorderStyle=1,"
                 f"Outline={ol_units},Shadow=0,MarginV={mv_units},Alignment=2")
    if subs and os.path.isfile(subs):
        if subs.lower().endswith(".ass"):
            vf.append(f"subtitles={os.path.basename(subs)}")
        else:
            vf.append(f"subtitles={os.path.basename(subs)}:force_style='{sub_style}'")
    vf.append("format=yuv420p")
    vchain = ",".join(vf) if vf else "null"

    if nar_idx is not None and bgm_idx is not None:
        afilter = (
            f"[{nar_idx}:a]volume=1.0,aresample=44100[nar];"
            f"[{bgm_idx}:a]volume={bgm_volume + 0.04:.3f},atrim=0:{total},asetpts=PTS-STARTPTS[bgm];"
            "[nar]asplit=2[n1][key];"
            "[bgm][key]sidechaincompress=threshold=0.03:ratio=12:attack=15:release=350[duck];"
            "[0:a]volume=0.7[orig];"
            f"[n1][duck][orig]amix=inputs=3:duration=longest:normalize=0,apad,atrim=0:{total}[a]"
        )
    elif bgm_idx is not None:
        # 原声全音量保留；BGM 低音量并用原声做侧链闪避，保证台词清楚
        afilter = (f"[{bgm_idx}:a]volume={bgm_volume:.3f},atrim=0:{total},asetpts=PTS-STARTPTS[bgm];"
                   "[0:a]volume=1.0,asplit=2[orig][key];"
                   "[bgm][key]sidechaincompress=threshold=0.02:ratio=10:attack=10:release=300[duck];"
                   f"[orig][duck]amix=inputs=2:duration=longest:normalize=0,apad,atrim=0:{total}[a]")
    else:
        afilter = "[0:a]volume=1.0[a]"

    graph = f"[0:v]{vchain}[base]"
    vlabel = "base"
    if mat_idx is not None:
        ma = round(random.uniform(0.08, 0.18), 3)
        graph += (f";[{mat_idx}:v]format=rgba,colorchannelmixer=aa={ma},scale={W}:{H}[mat]"
                  f";[{vlabel}][mat]overlay=x='-20+10*sin(t/4)':y=0[matout]")
        vlabel = "matout"
    if part_idx is not None:
        alpha = round(random.uniform(0.10, 0.22), 3)
        graph += (f";[{part_idx}:v]format=rgba,colorchannelmixer=aa={alpha},scale={W}:{H}[pt]"
                  f";[{vlabel}][pt]overlay=0:0[ptout]")
        vlabel = "ptout"
    if bar_idx is not None:
        graph += (f";[{bar_idx}:v]format=rgba,"
                  f"geq=r=255:g=255:b=255:a='if(lt(X,W*T/{max(0.1, total)}),190,0)'[bar]"
                  f";[{vlabel}][bar]overlay=0:{max(0, H - 30)}[barout]")
        vlabel = "barout"
    graph += f";[{vlabel}]format=yuv420p[vfinal];{afilter}"
    cmd = inputs + [
        "-filter_complex", graph,
        "-map", "[vfinal]", "-map", "[a]",
        "-t", str(total),
        "-c:v", "libx264", "-preset", "medium", "-crf", "19",
        "-c:a", "aac", "-b:a", "192k", "-ar", "44100", "-ac", "2",
        "-map_metadata", "-1", "-fflags", "+bitexact",
        "-movflags", "+faststart", "-pix_fmt", "yuv420p", out_path,
    ]
    rc, _, err = run(cmd, cwd=workdir, timeout=3600)
    if rc != 0:
        raise RuntimeError(f"final render failed: {err[-800:]}")
    return out_path


VIDEO_EXTS = {".mp4", ".mkv", ".mov", ".flv", ".ts", ".m4v", ".avi", ".webm"}


def _natkey(s):
    return [int(x) if x.isdigit() else x.lower() for x in re.split(r"(\d+)", s)]


def find_clips(folder):
    """优先 1/2/3.mp4；否则取文件夹里任意视频（自然排序，排除成片）。"""
    fixed = [os.path.join(folder, f"{i}.mp4") for i in (1, 2, 3)]
    if all(os.path.isfile(p) for p in fixed):
        return fixed
    found = []
    for name in os.listdir(folder):
        p = os.path.join(folder, name)
        if not os.path.isfile(p):
            continue
        if os.path.splitext(name)[1].lower() not in VIDEO_EXTS:
            continue
        if "二创_" in name or name.endswith(".asr.json"):
            continue
        found.append(p)
    found.sort(key=lambda p: _natkey(os.path.basename(p)))
    return found[:3]


def pick_cover(files):
    """封面命名不统一：封面/cover/海报/任意图片。"""
    imgs = [f for f in files if os.path.splitext(f)[1].lower() in (".jpg", ".jpeg", ".png", ".webp")]
    for f in imgs:
        if any(k in f.lower() for k in ("封面", "cover", "海报", "poster")):
            return f
    return imgs[0] if imgs else None


def render_one(folder, aspect="9:16", duration=180, watermark="", voice="zh-CN-YunxiNeural",
               no_tts=True, force=False, suffix="", mirror=False, cover_intro=True, keep_src_subs=False, subtitles=False, seed=0,
               clips_override=None, out_dir=None, title_override=None, safe_mode="strict",
               acting_mark=True, skip_postcheck=False,
               vlm_mode="auto", vlm_install=False, story_mode="auto",
               require_models=True, transitions=True, particles=True, progress_bar=True,
               interpolate=False, interp_factor=2, materials=True):
    t_start = time.time()
    if require_models:
        ok_models, model_detail = ensure_models(auto_install=True)
        if not ok_models:
            return {"status": "models_missing",
                    "error": f"模型未就绪，已停止：{model_detail}；下载完成后重跑"}
    t_preflight = time.time()
    if transitions and not ffmpeg_has_filter("xfade"):
        print("[特效] 当前 ffmpeg 不支持 xfade，关闭转场", flush=True)
        transitions = False
    if progress_bar and not ffmpeg_has_filter("geq"):
        print("[特效] 当前 ffmpeg 不支持 geq，关闭进度条", flush=True)
        progress_bar = False
    if (particles or materials) and not ffmpeg_has_filter("overlay"):
        particles = materials = False
    watermark = (watermark or "").strip()
    if watermark and CONTACT_RE.search(watermark):
        return {"status": "bad_watermark", "error": "水印包含联系方式/链接/二维码字样，属站外导流，已拒绝"}
    folder = norm_path(folder)
    clips_override = [norm_path(p) for p in clips_override] if clips_override else None
    out_dir = norm_path(out_dir) if out_dir else None
    title = title_override or os.path.basename(folder.rstrip("\\/"))
    title = re.sub(r"^\d+\.\s*", "", title)
    title = safe_title(title)[:80].strip(" .") or "untitled"
    if not os.path.isdir(folder):
        return {"status": "bad_folder", "folder": folder,
                "error": f"文件夹不存在或不是目录：{folder}"}
    free = 0
    try:
        free = shutil.disk_usage(folder).free
    except Exception:
        pass
    if free and free < 300 * 1024 * 1024:
        return {"status": "no_space", "folder": folder,
                "error": f"磁盘剩余空间不足 300MB：{free // 1048576}MB"}
    if folder.startswith("\\\\"):
        print("[警告] 素材在网络路径上，渲染会明显变慢；建议先拷到本地。", flush=True)
    if len(folder) > 240:
        print("路径过长（>240），Windows 下可能失败，建议移到更短路径：", folder, flush=True)
    out_base = out_dir or folder
    try:
        os.makedirs(out_base, exist_ok=True)
    except OSError as e:
        return {"status": "bad_out", "folder": folder, "error": f"无法创建输出目录：{e}"}
    out_path = os.path.join(out_base, f"{title}_二创_3min{suffix}.mp4")
    report_path = os.path.join(out_base, f"{title}_二创_报告{suffix}.json")
    if os.path.isfile(out_path) and not force:
        print("已存在成片，跳过（--force 可重剪）：", out_path, flush=True)
        return {"status": "skip", "folder": folder, "output": out_path}

    clip_paths = list(clips_override) if clips_override else find_clips(folder)
    clips = []
    for p in clip_paths:
        if not os.path.isfile(p):
            continue
        info = probe(p)
        info["path"] = p
        clips.append(info)                 # 无音轨也收，渲染时静音轨兜底
    if not clips:
        return {"status": "no_clips", "folder": folder}
    SAFETY.update({"enabled": safe_mode == "strict", "text_rejected": 0,
                   "visual_rejected": 0, "asr_available": False, "soft_hits": 0})
    offline = [c["path"] for c in clips if is_offline(c["path"])]
    if offline:
        return {"status": "offline_files", "folder": folder,
                "error": "以下文件是云端占位（OneDrive/网盘），请先“始终保留在此设备”或拷到本地：" + "; ".join(offline[:3])}

    W, H = parse_aspect(aspect)
    seed = int(seed or random.randrange(1, 10 ** 9))
    rnd = random.Random(seed)
    duration_eff = round(duration * rnd.uniform(0.90, 1.10), 2)
    fps = rnd.choice([25, 30])
    zoom = round(rnd.uniform(1.0, 1.12), 3)          # 画面缩放，连带源字幕视觉大小变化
    eq_c = round(rnd.uniform(1.03, 1.09), 3)
    eq_s = round(rnd.uniform(1.06, 1.18), 3)
    vig = round(rnd.uniform(0.145, 0.185), 3)
    noise = rnd.randint(2, 7)
    seg_len = round(rnd.uniform(8.5, 11.5), 2)
    wm_font = int(round(H * rnd.uniform(1 / 38, 1 / 22)))
    wm_margin = rnd.randint(16, 36)
    sub_fs = round(rnd.uniform(0.036, 0.058), 4)      # 烧录字幕字号（--subtitles 时生效）
    files = os.listdir(folder)
    cover = pick_cover(files) if cover_intro else None
    intro_secs = round(rnd.uniform(2.0, 3.0), 2) if cover else 0.0
    content_total = max(30.0, duration_eff - intro_secs)
    with tempfile.TemporaryDirectory(prefix="recreate_") as work:
        paths = []
        if cover:
            intro = os.path.join(work, "intro.mp4")
            render_intro(os.path.join(folder, cover), intro, W, H, work, intro_secs)
            paths.append(intro)
        clips, asset_review = review_asset_clips(clips, work)
        t_asset = time.time()
        if not clips:
            return {"status": "unsafe_material",
                    "error": "选段前素材双重审核：全部素材均被规则+模型同时判风险"}
        segs = plan_highlights(clips, content_total, seg_len, seed, safe=safe_mode)
        t_select = time.time()
        if not segs:
            return {"status": "unsafe_material", "folder": folder,
                    "error": "按抖音审核过滤后可用片段不足（文本/画面敏感），已跳过；确需关闭用 --safe-mode off",
                    "safety": dict(SAFETY)}
        for i, s in enumerate(segs):
            seg_path = os.path.join(work, f"seg_{i:03d}.mp4")
            render_segment(s, i, seg_path, W, H, work, mirror, keep_src_subs or not subtitles,
                           fps=fps, zoom=zoom, eq_c=eq_c, eq_s=eq_s, vig=vig, noise=noise)
            paths.append(seg_path)
        timeline = concat_segments(paths, os.path.join(work, "timeline.mp4"), work,
                                   transitions=transitions)
        content_actual = sum(float(s["dur"]) for s in segs)
        if transitions and len(paths) > 1:
            content_actual -= TRANSITION_SEC * (len(paths) - 1)
        total_actual = round(intro_secs + content_actual, 2)

        commentary = make_commentary(title, seed) if not no_tts else ""
        narration = None
        tts_err = ""
        if not no_tts:
            narration = os.path.join(work, "narration.mp3")
            ok, tts_err = tts(commentary, narration, voice)
            if not ok:
                narration = None

        nar_dur = 0.0
        if narration:
            nar_dur = probe(narration).get("duration", 0.0)

        subs = None
        subtitle_count = 0
        if narration and nar_dur > 5:
            sentences = split_sentences(commentary)
            subs = os.path.join(work, "subs.srt")
            write_srt(sentences, min(nar_dur, total_actual), subs)
            subtitle_count = len(sentences)
        elif subtitles and any(s.get("subs") for s in segs):
            items = []
            offset = intro_secs
            for s in segs:
                spd = float(s.get("speed") or 1.0)
                for sub in s.get("subs") or []:
                    items.append(((sub["start"] - s["start"]) / spd + offset,
                                  (sub["end"] - s["start"]) / spd + offset,
                                  sub["text"]))
                offset += float(s["dur"])
            subs = os.path.join(work, "subs.ass")
            write_ass(items, W, H, subs, fs_factor=sub_fs)
            subtitle_count = len(items)

        ensure_bgm()
        mood, bgm = pick_bgm(title)
        final_render(timeline, narration, bgm, subs, out_path, W, H, watermark, total_actual, work,
                     acting_mark=acting_mark,
                     bgm_volume=round(rnd.uniform(0.10, 0.145), 3),
                     particles=particles, progress_bar=progress_bar, materials=materials,
                     wm_font=wm_font, wm_margin=wm_margin)
        t_render = time.time()
        fps_eff = fps
        if interpolate:
            out_path, _interp_ok = interpolate_video(out_path, work, interp_factor)
            if _interp_ok:
                info = probe(out_path)
                fps_eff = int(round(fps * interp_factor))

        info = probe(out_path)
        rule_issues = [] if skip_postcheck else postcheck_video(out_path, title, duration_eff)
        model_issues = []
        vlm_model_count = 0
        story_model_issues = []
        vlm_info = {"available": False, "note": "未启用"}
        story_info = {"available": False, "note": "未启用"}
        if not skip_postcheck:
            if vlm_mode != "off":
                ready = vlm_ready()
                if not ready and (vlm_install or vlm_mode == "on"):
                    ready = ensure_vlm(auto_install=True)
                if ready:
                    vlm_info = vlm_review_video(out_path, work, n=10)
                    for hit in vlm_info.get("rule_hits", []):
                        cats = "/".join(hit.get("cats") or [])
                        rule_issues.append(f"VLM规则 {hit['ts']}s {cats} {hit.get('reason','')}".strip())
                    for hit in vlm_info.get("model_hits", []):
                        cats = "/".join(hit.get("cats") or [])
                        model_issues.append(f"VLM模型 {hit['ts']}s {cats} {hit.get('reason','')}".strip())
                        vlm_model_count += 1
                else:
                    vlm_info = {"available": False,
                                "note": "未安装视觉模型（--vlm-install 可自动安装约 5GB）"}
            if story_mode != "off":
                txt = " ".join(s["text"] for seg in segs for s in (seg.get("subs") or []))
                if txt.strip():
                    story_info = story_review(txt)
                    for it in story_info.get("rule_issues", []):
                        rule_issues.append("剧情/台词规则：" + it)
                    for it in story_info.get("model_issues", []):
                        model_issues.append("剧情/台词模型：" + it)
                        story_model_issues.append(it)
                else:
                    story_info = {"available": False, "note": "无转写文本"}
        t_check = time.time()
        post_issues = rule_issues + model_issues
        rule_flag = bool(rule_issues)
        model_flag = (vlm_model_count >= 3) or bool(story_model_issues)
        # 单层命中：文件名写清是哪层 + 原因
        def _short_reason(items):
            s = " ".join(str(x) for x in items)
            table = [("涉政","涉政"), ("邪教","邪教"), ("色情","色情"), ("血腥","血腥"),
                     ("暴力","暴力"), ("吸毒","毒品"), ("赌博","赌博"), ("迷信","迷信"),
                     ("算命","迷信"), ("伪科学","伪科学"), ("医疗","医疗"), ("金融","金融"),
                     ("导流","导流"), ("微信","导流"), ("极限","极限词"), ("歧视","歧视"),
                     ("教培","教培"), ("假冒","假冒"), ("未成年","未成年"), ("标题","标题敏感"),
                     ("黑屏","画面异常"), ("模糊","画面异常"), ("强红","血腥画面"), ("时长","时长")]
            for k, v in table:
                if k in s:
                    return v
            return "风险"
        if rule_flag and model_flag:
            verdict = "不合格"; reason = ""
        elif rule_flag:
            verdict = "规则单层不合格"; reason = _short_reason(rule_issues)
        elif model_flag:
            verdict = "模型单层不合格"; reason = _short_reason(model_issues)
        else:
            verdict = ""; reason = ""
        qualified = not (rule_flag or model_flag)
        if post_issues and verdict:
            base, ext = os.path.splitext(out_path)
            tag = ""
            if verdict == "不合格":
                tag = "_不合格"
            elif verdict:
                tag = f"_{verdict}_{reason}"
            flagged = base + tag + ext
            try:
                if os.path.isfile(flagged):
                    os.remove(flagged)
                os.replace(out_path, flagged)
                out_path = flagged
            except OSError as e:
                print("[警告] 成品重命名失败：", e, flush=True)
            print(f"[{verdict or '待复核'}] 成品审核发现问题，已标注：", out_path, flush=True)
            for it in post_issues[:6]:
                print("   -", it, flush=True)
        elif post_issues:
            print("成品自检通过（模型单帧/弱信号仅记录，不判不合格）：", flush=True)
            for it in post_issues[:4]:
                print("   -", it, flush=True)
        else:
            print("成品自检通过：未发现明显不合规画面/标题", flush=True)

        report = {
            "folder": folder, "title": title, "output": out_path,
            "aspect": aspect, "size": f"{W}x{H}",
            "duration": round(info.get("duration", 0), 2),
            "width": info.get("width"), "height": info.get("height"),
            "watermark": watermark, "bgm": mood,
            "safety": dict(SAFETY), "acting_mark": bool(acting_mark),
            "qualified": bool(qualified), "postcheck_issues": post_issues,
            "review_result": {"rule_flagged": rule_flag, "model_flagged": model_flag,
                              "rule_issues": rule_issues, "model_issues": model_issues,
                              "model_available": bool(vlm_info.get("available")),
                              "verdict": verdict or "通过", "reason": reason},
            "vlm": vlm_info, "story_review": story_info, "asset_review": asset_review,
            "effects": {"transitions": bool(transitions), "particles": bool(particles),
                        "progress_bar": bool(progress_bar), "opening_fade": bool(cover_intro),
                        "interpolate": bool(interpolate), "interp_factor": interp_factor,
                        "material_overlay": bool(materials)},
            "timing": {"preflight_sec": round(t_preflight - t_start, 1),
                       "asset_review_sec": round(t_asset - t_preflight, 1),
                       "select_sec": round(t_select - t_asset, 1),
                       "render_sec": round(t_render - t_select, 1),
                       "check_sec": round(time.time() - t_render, 1),
                       "total_sec": round(time.time() - t_start, 1)},
            "review_layers": {
                "rules": {"enabled": safe_mode == "strict",
                          "selection_rejected": SAFETY.get("text_rejected", 0) + SAFETY.get("visual_rejected", 0) + SAFETY.get("lowq_rejected", 0),
                          "issues": list(post_issues)},
                "model": {"vlm_hits": len(vlm_info.get("model_hits", [])),
                          "story_issues": len(story_info.get("model_issues", []))},
            },
            "bgm_license": bgm_credit(bgm),
            "seed": seed, "fps": fps_eff, "zoom": zoom,
            "duration_target": duration_eff, "segment_len": seg_len,
            "eq_contrast": eq_c, "eq_saturation": eq_s, "noise": noise,
            "watermark_font": wm_font, "watermark_margin": wm_margin,
            "highlight": True,
            "highlight_scores": [s.get("score") for s in segs],
            "segment_list": [{"clip": os.path.basename(s["clip"]), "start": s["start"],
                          "dur": s["dur"], "speed": s.get("speed")} for s in segs],
            "cut_aligned": all(s.get("cut_aligned") for s in segs),
            "sentence_aligned": all(s.get("sentence_aligned") for s in segs),
            "original_audio": True,
            "burned_subtitles": bool(subtitle_count),
            "subtitle_count": subtitle_count,
            "asr_model": os.environ.get("RECREATE_ASR_MODEL", "medium"),
            "src_subs_cropped": bool(subtitle_count and not keep_src_subs and not narration),
            "segment_durations": [round(float(s["dur"]), 2) for s in segs],
            "cover_file": cover or "",
            "cover_intro": bool(cover),
            "narration_chars": len(commentary) if narration else 0,
            "tts": ("edge-tts" if narration else ("disabled" if no_tts else f"failed: {tts_err[:200]}")),
            "segments": len(segs), "clips": len(clips),
            "compliance": {
                "multi_clip": len(clips) >= 3,
                "effects": True,
                "mirror": bool(mirror),
                "watermark": bool(watermark),
                "commentary": bool(narration),
                "subtitles": bool(subs),
                "bgm": bool(bgm),
            },
            "generated_at": time.strftime("%Y-%m-%d %H:%M:%S"),
        }
        with open(report_path, "w", encoding="utf-8") as f:
            json.dump(report, f, ensure_ascii=False, indent=1)
        return {"status": "ok", **report}


def main():
    ap = argparse.ArgumentParser(prog="recreate.py")
    ap.add_argument("--version", action="version", version=f"recreate-studio {__version__}")
    ap.add_argument("--folder")
    ap.add_argument("--root")
    ap.add_argument("--aspect", default="9:16")
    ap.add_argument("--duration", type=float, default=180)
    ap.add_argument("--watermark", default="")
    ap.add_argument("--voice", default="zh-CN-YunxiNeural")
    ap.add_argument("--tts", action="store_true", help="加 AI 解说旁白（默认关闭，只做高燃剪辑）")
    ap.add_argument("--force", action="store_true")
    ap.add_argument("--limit", type=int, default=0)
    ap.add_argument("--suffix", default="")
    ap.add_argument("--mirror", action="store_true",
                    help="隔段镜像（默认关闭：源片硬字幕会被镜像成反字）")
    ap.add_argument("--no-cover", action="store_true", help="不用封面做片头（默认会加）")
    ap.add_argument("--seed", type=int, default=0, help="随机种子；0=每条都随机，固定值可复现")
    ap.add_argument("--setup-bgm", action="store_true", help="只准备 BGM 库（下载/补齐后退出）")
    ap.add_argument("--bgm-limit", type=int, default=0)
    ap.add_argument("--bgm-force", action="store_true")
    ap.add_argument("--keep-src-subs", action="store_true", help="不裁掉源片底部硬字幕（默认裁掉，避免与烧录字幕重影）")
    ap.add_argument("--subtitles", action="store_true", help="额外烧录 ASR 字幕（默认关闭，保留源片硬字幕）")
    ap.add_argument("--clips", nargs="+", help="显式指定 1-3 个视频文件（可任意文件名）")
    ap.add_argument("--out", help="成片输出目录（默认放素材文件夹内）")
    ap.add_argument("--recursive", action="store_true", help="--root 时递归扫描所有子目录")
    ap.add_argument("--title", help="自定义成片标题（默认取文件夹名）")
    ap.add_argument("--interpolate", action="store_true", help="RIFE 显卡补帧（较慢）")
    ap.add_argument("--interp-factor", type=int, default=2, choices=[2, 4], help="补帧倍数")
    ap.add_argument("--no-transitions", action="store_false", dest="transitions", help="关闭段间转场")
    ap.add_argument("--no-materials", action="store_false", dest="materials", help="关闭素材叠加")
    ap.add_argument("--no-particles", action="store_false", dest="particles", help="关闭粒子叠加")
    ap.add_argument("--no-progress", action="store_false", dest="progress_bar", help="关闭底部进度条")
    ap.add_argument("--license", default="", help="输入授权码并保存（新电脑首次使用）")
    ap.add_argument("--machine-id", action="store_true", help="显示本机机器码")
    ap.add_argument("--no-require-models", action="store_false", dest="require_models",
                    help="不强制预检模型（默认必须先装好 ASR+视觉模型才开剪）")
    ap.add_argument("--vlm-review", choices=["auto", "on", "off"], default="auto",
                    help="画面 AI 审核：auto=有模型就跑；on=没有就自动装；off=关闭")
    ap.add_argument("--vlm-install", action="store_true", help="允许自动安装 Ollama + 视觉模型（约 5GB）")
    ap.add_argument("--story-review", choices=["auto", "on", "off"], default="auto",
                    help="剧情/台词合规审查：auto=有模型用模型，否则关键词规则；off=关闭")
    ap.add_argument("--skip-postcheck", action="store_true",
                    help="跳过成品自检（默认会抽样检测，发现不合规在文件名加 _不合格）")
    ap.add_argument("--no-acting-mark", action="store_false", dest="acting_mark",
                    help="不烧录左上角「AI演绎」标注（默认会烧）")
    ap.add_argument("--acting-mark", action="store_true", dest="acting_mark",
                    help=argparse.SUPPRESS)
    ap.add_argument("--safe-mode", choices=["strict", "off"], default="strict",
                    help="抖音审核安全过滤：strict=默认，剔除敏感台词/血色画面；off=关闭（不建议）")
    a = ap.parse_args()

    if _lic is not None:
        if getattr(a, "machine_id", False):
            print(_lic.machine_id())
            return
        if getattr(a, "license", ""):
            try:
                data = _lic.activate(a.license)
                import time as _t
                print("授权成功；到期：", "永久" if not data.get("e") else _t.strftime("%Y-%m-%d %H:%M", _t.localtime(int(data["e"]))))
            except Exception as e:
                print("授权失败：", e)
                return
            return
        if not _lic.require_license(interactive=sys.stdin.isatty()):
            sys.exit(2)

    if a.setup_bgm:
        ensure_bgm(a.bgm_limit, a.bgm_force)
        return

    targets = []
    clips_override = list(a.clips) if a.clips else None
    if clips_override:
        targets = [a.folder or os.path.dirname(os.path.abspath(clips_override[0]))]
    elif a.folder:
        targets = [a.folder]
    elif a.root:
        if a.recursive:
            for dirpath, _, _ in os.walk(a.root):
                if find_clips(dirpath):
                    targets.append(dirpath)
        else:
            for d in sorted(os.listdir(a.root)):
                p = os.path.join(a.root, d)
                if os.path.isdir(p) and find_clips(p):
                    targets.append(p)
    else:
        ap.error("需要 --folder、--root 或 --clips")

    if a.limit:
        targets = targets[:a.limit]

    results = []
    batch_start = time.time()
    for i, t in enumerate(targets, 1):
        folder_start = time.time()
        try:
            out_dir = None
            if a.out:
                out_dir = a.out if (a.folder or clips_override) else os.path.join(
                    a.out, os.path.relpath(t, a.root))
            r = render_one(t, a.aspect, a.duration, a.watermark, a.voice, safe_mode=a.safe_mode,
                           acting_mark=a.acting_mark, skip_postcheck=a.skip_postcheck,
                           vlm_mode=a.vlm_review, vlm_install=a.vlm_install,
                           story_mode=a.story_review, require_models=a.require_models,
                           transitions=a.transitions, particles=a.particles,
                           progress_bar=a.progress_bar, materials=a.materials, interpolate=a.interpolate,
                           interp_factor=a.interp_factor,
                           no_tts=not a.tts, force=a.force, suffix=a.suffix,
                           mirror=a.mirror, cover_intro=not a.no_cover,
                           keep_src_subs=a.keep_src_subs, subtitles=a.subtitles, seed=a.seed,
                           clips_override=clips_override if len(targets) == 1 else None,
                           out_dir=out_dir,
                           title_override=a.title if len(targets) == 1 else None)
        except Exception as e:
            r = {"status": "error", "folder": t, "error": str(e)[-800:]}
        r["elapsed_sec"] = round(time.time() - folder_start, 1)
        results.append(r)
        print(json.dumps({"i": i, "total": len(targets), **{k: r.get(k) for k in
                          ("status", "title", "output", "duration", "size", "error")}},
                         ensure_ascii=False), flush=True)

    batch_total = round(time.time() - batch_start, 1)
    summary = {
        "generated_at": time.strftime("%Y-%m-%d %H:%M:%S"),
        "targets": len(results), "ok": sum(1 for r in results if r.get("status") in ("ok", "skip")),
        "fail": sum(1 for r in results if r.get("status") not in ("ok", "skip")),
        "batch_total_sec": batch_total,
        "items": [{"folder": r.get("folder"), "title": r.get("title"),
                   "status": r.get("status"), "output": r.get("output"),
                   "elapsed_sec": r.get("elapsed_sec"),
                   "timing": r.get("timing")} for r in results],
    }
    report_dir = a.root if a.root else (a.folder or (os.path.dirname(os.path.abspath(clips_override[0])) if clips_override else "."))
    report_name = "_批量剪辑报告.json" if len(results) > 1 else "_剪辑报告.json"
    try:
        with open(os.path.join(report_dir, report_name), "w", encoding="utf-8") as f:
            json.dump(summary, f, ensure_ascii=False, indent=1)
    except Exception as e:
        print("[警告] 批量报告写入失败：", e, flush=True)
    print(json.dumps({"batch_total_sec": batch_total, "report": os.path.join(report_dir, report_name)},
                     ensure_ascii=False), flush=True)
    ok = sum(1 for r in results if r.get("status") in ("ok", "skip"))
    print(json.dumps({"done": len(results), "ok": ok,
                      "fail": len(results) - ok}, ensure_ascii=False))


if __name__ == "__main__":
    main()

