# -*- coding: utf-8 -*-
"""无授权门禁版本：所有入口直接放行。"""

def require_license(interactive=None):
    return True

def current_ok():
    return True

def owner_ok():
    return True

def activate(code):
    return {"e": 0}

def machine_id():
    return ""
