# -*- coding: utf-8 -*-
"""下载 RIFE ncnn Vulkan（显卡补帧）到包内 tools。"""
import os, subprocess, sys, zipfile, shutil

PKG = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DIRS = [os.path.join(PKG, "tools", "rife-ncnn-vulkan"),
        os.path.join(os.environ.get("LOCALAPPDATA", os.path.expanduser("~")),
                     "recreate-studio", "tools", "rife-ncnn-vulkan")]
DEST = DIRS[0]
ASSET = "https://github.com/nihui/rife-ncnn-vulkan/releases/download/20221029/rife-ncnn-vulkan-20221029-windows.zip"
URLS = [ASSET,
        "https://ghproxy.net/" + ASSET,
        "https://mirror.ghproxy.com/" + ASSET,
        "https://gh-proxy.com/" + ASSET]

def find_exe():
    for root in (os.environ.get("RECREATE_RIFE", ""), *DIRS,
                 r"D:\AI\tools\rife-ncnn-vulkan"):
        if not root or not os.path.isdir(root):
            continue
        for dirpath, _, files in os.walk(root):
            if "rife-ncnn-vulkan.exe" in files:
                return os.path.join(dirpath, "rife-ncnn-vulkan.exe")
    return ""

def main():
    exe = find_exe()
    if exe:
        print("[RIFE] 已存在:", exe, flush=True)
        return 0
    for cand in DIRS:
        try:
            os.makedirs(cand, exist_ok=True)
            probe = os.path.join(cand, ".w"); open(probe, "w").close(); os.remove(probe)
            DEST = cand
            break
        except OSError:
            continue
    try:
        free = shutil.disk_usage(DEST).free
        if free < 2 * 1024**3:
            print("[RIFE] 磁盘不足 2GB", flush=True)
            return 4
    except Exception:
        pass
    zp = os.path.join(DEST, "rife.zip")
    print("[RIFE] 下载补帧工具（约 411MB，显卡加速）...", flush=True)
    ok = False
    for u in URLS:
        print("[RIFE] 源:", u.split("/")[2], flush=True)
        cmd = ["curl.exe", "-L", "--fail", "--retry", "3", "--connect-timeout", "20",
               "--speed-time", "60", "--speed-limit", "1024", "-C", "-", "-o", zp, u]
        if subprocess.run(cmd).returncode == 0 and os.path.isfile(zp) and os.path.getsize(zp) > 300 * 1024 * 1024:
            ok = True
            break
    if not ok:
        print("[RIFE] 下载失败；可手动放到", DEST, flush=True)
        return 1
    try:
        with zipfile.ZipFile(zp) as z:
            z.extractall(DEST)
    except Exception as e:
        print("[RIFE] 解压失败:", e, flush=True)
        return 2
    exe = find_exe()
    print("[RIFE] 就绪:", exe or "未找到 exe", flush=True)
    return 0 if exe else 3

if __name__ == "__main__":
    sys.exit(main())