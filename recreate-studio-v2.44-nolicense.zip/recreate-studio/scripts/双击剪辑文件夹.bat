@echo off
setlocal EnableExtensions
chcp 936 >nul 2>&1
set "PYTHONUTF8=1"
set "PYTHONIOENCODING=utf-8"
title ˫�������ļ��� - recreate-studio v2.42
set "ROOT=%~dp0.."
for %%I in ("%ROOT%") do set "ROOT=%%~fI"
set "RENDER=%~dp0recreate.py"
if not exist "%RENDER%" ( echo [����] ȱ�� recreate.py & pause & exit /b 1 )
call :ENSURE_ENV
if not defined PY ( echo [����] ����׼��ʧ�ܣ��������� & pause & exit /b 1 )
if exist "%RT%\ffmpeg\ffmpeg.exe" set "RECREATE_FFMPEG=%RT%\ffmpeg\ffmpeg.exe"
if exist "%RT%\ffmpeg\ffprobe.exe" set "RECREATE_FFPROBE=%RT%\ffmpeg\ffprobe.exe"

"%PY%" "%~dp0launch_gui.py" %*
exit /b 0
:ENSURE_ENV
set "PY="
set "RT=%ROOT%\runtime"
if exist "%ROOT%\runtime\python\python.exe" set "RT=%ROOT%\runtime"
if exist "%ROOT%\runtime\python\python.exe" set "PY=%ROOT%\runtime\python\python.exe"
if not defined PY if exist "%ROOT%\runtime_path.txt" set /p RT=<"%ROOT%\runtime_path.txt"
if not defined PY if exist "%RT%\python\python.exe" set "PY=%RT%\python\python.exe"
if not defined PY if exist "%LOCALAPPDATA%\recreate-studio-runtime\python\python.exe" set "RT=%LOCALAPPDATA%\recreate-studio-runtime"
if not defined PY if exist "%LOCALAPPDATA%\recreate-studio-runtime\python\python.exe" set "PY=%LOCALAPPDATA%\recreate-studio-runtime\python\python.exe"
if not defined PY if exist "C:\Users\Administrator\.dsh\dsh-runtimes\dsh-primary-runtime\dependencies\python\python.exe" set "PY=C:\Users\Administrator\.dsh\dsh-runtimes\dsh-primary-runtime\dependencies\python\python.exe"
if defined PY exit /b 0
echo [����] �״����У�׼�� Python / ���� / FFmpeg��Լ 250MB��װ�ڰ��� runtime\��...
set "BOOT=%~dp0bootstrap.ps1"
if not exist "%BOOT%" if exist "%ROOT%\bootstrap.ps1" set "BOOT=%ROOT%\bootstrap.ps1"
if not exist "%BOOT%" if exist "%~dp0..\scripts\bootstrap.ps1" set "BOOT=%~dp0..\scripts\bootstrap.ps1"
if not exist "%BOOT%" (
    echo [����] ȱ�� bootstrap.ps1����װ����������
    echo ��ȷ�� scripts\bootstrap.ps1 ���ڣ������½�ѹ��������
    pause
    exit /b 1
)
powershell -NoProfile -ExecutionPolicy Bypass -File "%BOOT%" -Root "%ROOT%"
set "PY="
set "RT=%ROOT%\runtime"
if exist "%ROOT%\runtime\python\python.exe" set "PY=%ROOT%\runtime\python\python.exe"
if not defined PY if exist "%ROOT%\runtime_path.txt" set /p RT=<"%ROOT%\runtime_path.txt"
if not defined PY if exist "%RT%\python\python.exe" set "PY=%RT%\python\python.exe"
if not defined PY if exist "%LOCALAPPDATA%\recreate-studio-runtime\python\python.exe" set "RT=%LOCALAPPDATA%\recreate-studio-runtime"
if not defined PY if exist "%LOCALAPPDATA%\recreate-studio-runtime\python\python.exe" set "PY=%LOCALAPPDATA%\recreate-studio-runtime\python\python.exe"
exit /b 0
