# asset-harvester

> 素材下载技能：给一个站/网盘/直链，自动建文件夹、只下点名文件、校验、出报告。

## 来源

| 来源 | 路线 |
|---|---|
| 登录态网站 | Playwright + Chrome CDP 抓接口 |
| 百度网盘分享 | BaiduPCS-Go 转存 + 下载 |
| 公开直链 | curl |

## 双击使用

双击 `scripts\双击下载素材.bat`（首次自动下载约 15MB 便携 Python）：

1. 百度网盘分享：输入链接、提取码、剧名、集数（`4,9,14` 或 `3`）
2. 公开直链：粘贴 URL
3. 登录站请让 AI 用 Chrome CDP 跑

## 命令行

```bash
python scripts/harvester_template.py download \
  --remote /漫剧/某剧 --local "<LIBRARY_ROOT>\001. 某剧" \
  --eps 4,9,14 --cover 封面.jpg
```

`--eps 3` / `--eps 4,9,14` / `--eps 3-6`；认 `4.mp4`、`第4集.mp4`、`EP04.mp4`、`14话.mp4`。

## 依赖

- Python 3.10+（requests 不需要）
- Playwright（登录站）
- BaiduPCS-Go v4.0.2（网盘）
- Chrome（CDP）

## 边界

只用自己账号/已授权/公开内容；不绕登录、付费墙、加密；Cookie 不落日志。

## 版本

- v1.1（2026-10-27）：双击入口支持中文路径自装 Python（先查包内 runtime，marker 用 ANSI）

## 版本

- v1.3（2026-10-27）：路径加固（弹窗选目录、清洗、磁盘检查、% 路径）
- v1.2（2026-10-27）：双击中文路径修复、lite 自装 Python、--eps 跳集

## License

暂未声明。
