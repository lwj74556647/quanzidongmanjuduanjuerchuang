﻿# 工具链与踩坑（asset-harvester）

## 1. Chrome CDP（登录态网站）

三种做法，按稳定性排序：

### A. 复用已开调试端口的 Chrome（最省事，需 9222 已开）

```powershell
& "C:\Program Files\Google\Chrome\Application\chrome.exe" `
  --remote-debugging-port=9222 --user-data-dir="D:\chrome-debug"
```

Playwright：`connect_over_cdp("http://127.0.0.1:9222")`。

### B. 复制 profile 开新实例（推荐，实测最稳）

```powershell
# 必须先完全退出 Chrome（含后台进程），否则 Cookies 复制会卡住
$src = "$env:LOCALAPPDATA\Google\Chrome\User Data"
$dst = "D:\chrome-dsh-profile"
New-Item -ItemType Directory -Force "$dst\Default\Network" | Out-Null
Copy-Item "$src\Local State" "$dst\Local State"
Copy-Item "$src\Default\Network\Cookies" "$dst\Default\Network\Cookies"
Copy-Item "$src\Default\Local Storage" "$dst\Default\Local Storage" -Recurse
& "C:\Program Files\Google\Chrome\Application\chrome.exe" `
  --user-data-dir="$dst" --remote-debugging-port=9333 `
  --no-first-run --no-default-browser-check
```

注意：

- Chrome 155+ 有 App-Bound Encryption，复制后登录态可能只剩匿名 Cookie（26 条 → 6 条）。**在副本窗口手动登录一次**即可。
- 不要用 `chrome://inspect` 的 "Open dedicated DevTools for Node" 去开端口：第一次能连，之后 403/超时，不稳定。
- 复制前 Chrome 没完全退出时，`robocopy /B` 或 `Copy-Item` 会卡在锁文件上。

### C. 已有页面手动开调试（不推荐）

`chrome://inspect` → configure → 端口方案不稳定，放弃。

## 2. Playwright 抓接口

```python
from playwright.sync_api import sync_playwright

with sync_playwright() as p:
    browser = p.chromium.connect_over_cdp("http://127.0.0.1:9333")
    ctx = browser.contexts[0]
    page = ctx.pages[0] if ctx.pages else ctx.new_page()
    store = {}
    page.on("response", lambda r: store.setdefault(r.url, r.text()) if "/gw/api/" in r.url else None)
    page.goto("https://www.xingtu.cn/sup/creator/user/task")
    page.wait_for_timeout(6000)
    # 翻页：让页面自己发请求
    page.click("li.number >> text=1")
    for n in range(2, 13):
        page.click(f"li.number >> text={n}")
        page.wait_for_timeout(1500)
```

原则：

- 不要在页面外用 `requests` 重放接口：签名/时间戳由页面生成，重放 400。
- 页面里的 `li.number` 是分页控件；先点第 1 页，再顺序点。
- 响应存 `dict[url] = text`；后面按 URL 关键字找 JSON。

## 3. 百度网盘 BaiduPCS-Go

- 版本：v4.0.2（windows-x64）
- 路径：`<TOOLS_DIR>\BaiduPCS-Go\BaiduPCS-Go-v4.0.2-windows-x64\BaiduPCS-Go.exe`
- SHA256：`ce72b3155a710b7c4a2b15611c3aebd11a057d7cccf0529e7703bdde04f0aa30`

```powershell
$exe = "<TOOLS_DIR>\BaiduPCS-Go\BaiduPCS-Go-v4.0.2-windows-x64\BaiduPCS-Go.exe"
& $exe login "-cookies=BDUSS=...; STOKEN=..."
& $exe who
& $exe cd /漫剧
& $exe ls
& $exe transfer "https://pan.baidu.com/s/xxxx" "abcd"
& $exe download --saveto "<LIBRARY_ROOT>\001. 剧名" -p 8 封面.jpg 1.mp4 2.mp4 3.mp4
```

Python 封装（必须 DEVNULL，否则死锁）：

```python
def pcs(*args, timeout=1800):
    r = subprocess.run([PCS, *args], capture_output=True,
                       timeout=timeout,
                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    return r.returncode
```

GBK 解码：

```python
def decode(b):
    for enc in ("utf-8", "gbk"):
        try:
            return b.decode(enc)
        except UnicodeDecodeError:
            pass
    return b.decode("utf-8", "ignore")
```

`ls` 行解析（目录大小是 `-`）：

```python
LINE = re.compile(r"^\s*\d+\s+(\S+)\s+(\d+)\s+(-|[\d.]+[KMG]?B)\s+(.+)$")
```

## 4. 封面与目录容错

- `pick_cover()`：扩展名 `jpg/jpeg/png/webp`；优先名含 `封面/cover/海报`；否则取第一张图。
- 远端目录名可能带 `：共N集`；本地文件夹去掉这段。
- 分享内可能多一层同名目录、或分 `封面/`、`正片/《…》有字幕/`：按实际路径下钻。
- 封面文件名可能是 `cover (1).jpg`、`1：1.png`。

## 5. 批量与断点

- 进度文件 `download_progress.json`：`{剧名: {done: n, total: m}}`
- 已存在且大小一致的跳过；失败重试 3 次。
- 每部结束追加 CSV：序号、剧名、封面、1/2/3 集、大小、状态。
- 最后生成 `_下载报告.md`。

## 6. 校验

```powershell
Get-ChildItem "<根>" -Directory | ForEach-Object {
  $n = (Get-ChildItem $_.FullName -File | Where-Object { $_.Extension -in '.mp4','.jpg','.png','.jpeg','.webp' }).Count
  if ($n -lt 4) { "缺文件: $($_.Name)" }
}
```

预期：每部至少 4 个（封面 + 3 集）；报告总数与磁盘一致。
