@echo off
setlocal EnableExtensions
chcp 936 >nul 2>&1
set "PYTHONUTF8=1"
set "PYTHONIOENCODING=utf-8"
title asset-harvester ˫������
set "ROOT=%~dp0.."
for %%I in ("%ROOT%") do set "ROOT=%%~fI"
call :ENSURE_ENV
if not defined PY ( echo [����] Python ׼��ʧ�ܣ����������·�� & pause & exit /b 1 )
"%PY%" "%~dp0quick_download.py"
echo.
pause
exit /b 0

:ENSURE_ENV
set "PY="
set "RT=%ROOT%\runtime"
if exist "%ROOT%\runtime\python\python.exe" set "RT=%ROOT%\runtime"
if exist "%ROOT%\runtime\python\python.exe" set "PY=%ROOT%\runtime\python\python.exe"
if not defined PY if exist "%ROOT%\runtime_path.txt" set /p RT=<"%ROOT%\runtime_path.txt"
if not defined PY if exist "%RT%\python\python.exe" set "PY=%RT%\python\python.exe"
if not defined PY if exist "%LOCALAPPDATA%\recreate-studio-runtime\python\python.exe" set "RT=%LOCALAPPDATA%\recreate-studio-runtime"
if not defined PY if exist "%LOCALAPPDATA%\recreate-studio-runtime\python\python.exe" set "PY=%LOCALAPPDATA%\recreate-studio-runtime\python\python.exe"
if not defined PY if exist "C:\Users\Administrator\.dsh\dsh-runtimes\dsh-primary-runtime\dependencies\python\python.exe" set "PY=C:\Users\Administrator\.dsh\dsh-runtimes\dsh-primary-runtime\dependencies\python\python.exe"
if defined PY exit /b 0
echo [����] �״����У�׼����Я Python��Լ 15MB��...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0bootstrap.ps1" -Root "%ROOT%" -Mode lite
set "PY="
set "RT=%ROOT%\runtime"
if exist "%ROOT%\runtime\python\python.exe" set "PY=%ROOT%\runtime\python\python.exe"
if not defined PY if exist "%ROOT%\runtime_path.txt" set /p RT=<"%ROOT%\runtime_path.txt"
if not defined PY if exist "%RT%\python\python.exe" set "PY=%RT%\python\python.exe"
if not defined PY if exist "%LOCALAPPDATA%\recreate-studio-runtime\python\python.exe" set "RT=%LOCALAPPDATA%\recreate-studio-runtime"
if not defined PY if exist "%LOCALAPPDATA%\recreate-studio-runtime\python\python.exe" set "PY=%LOCALAPPDATA%\recreate-studio-runtime\python\python.exe"
exit /b 0
