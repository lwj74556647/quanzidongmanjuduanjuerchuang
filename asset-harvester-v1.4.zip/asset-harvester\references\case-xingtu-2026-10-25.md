﻿# 案例：星图短剧推广任务 112 部（2026-10-25）

## 目标

从星图（xingtu.cn）"短剧推广"任务里，把 112 部剧的**封面 + 前 3 集**下到 `<LIBRARY_ROOT>`，每部一个文件夹。

## 接口与字段

页面：`https://www.xingtu.cn/sup/creator/user/task`

关键接口（URL 含 `/gw/api/`）：

| 接口 | 用途 |
|---|---|
| `author_get_performance_list` | 任务列表（分页） |
| `author_get_challenge` | 任务详情（含素材） |
| `demand.attachment_description` | 附件描述，**百度网盘分享链接 + 提取码**在这里 |

分页：页面底部 `li.number`，共 12 页。**先显式点第 1 页，再 1→12 逐页点**；直接用 URL 参数翻页会漏（实测只拿到 62/112）。

## 目录结构差异

- 多数：`<剧名>：共N集`，分享内直接是 `封面.jpg`、`1.mp4`、`2.mp4`、`3.mp4`
- 043：分享内**再套一层同名目录**
- 107：分 `封面/` 与 `正片/《…》有字幕/` 两级
- 封面命名：`封面.jpg`、`cover (1).jpg`、`cover (3).jpg`、`1：1.png`

## 结果

- 112 个文件夹、448 个媒体文件、12.28 GB
- `_清单_封面与前三集.csv`、`_下载报告.md`
- 校验：0 缺失

## 踩过的坑

1. **Cookie 复制失效**：Chrome 155 App-Bound Encryption，复制 profile 后 26 条 Cookie 只剩 6 条匿名 → 在副本窗口手动登录一次。
2. **`chrome://inspect` 开端口**：首次可用，后续 403/超时 → 放弃，改用 profile 副本 + 9333。
3. **复制时 Chrome 未退出**：Cookies 被锁，复制卡死 → 先彻底退出 Chrome。
4. **BaiduPCS-Go 死锁**：进度条写满 stdout 管道，文件下完进程不退出（挂了 30 分钟）→ `stdout=DEVNULL, stderr=DEVNULL` + timeout。
5. **GBK 输出**：`成功`/`文件重复` 判断失败 → 先 utf-8 再 gbk 解码。
6. **目录行大小是 `-`**：正则漏掉目录行 → `(-|[\d.]+[KMG]?B)` 并把末尾 `/` 去掉。
7. **封面识别**：只认 `封面.jpg` 会漏 `cover (3).jpg`、`1：1.png` → 只要图片扩展名就接受，关键词只做优先级。
8. **翻页漏页**：从第 2 页开始 → 先点第 1 页再顺序点。

## 可复用参数

```text
根目录:      <LIBRARY_ROOT>
命名:        NNN. 剧名   （001. 毒酒换红妆）
每部下:      封面 + 1.mp4 + 2.mp4 + 3.mp4
并发:        -p 8
重试:        3 次，间隔 2s
```
