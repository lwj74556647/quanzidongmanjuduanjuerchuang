﻿---
name: asset-harvester
description: 当用户说"帮我下载 XX 的素材/封面/视频/剧集/文件"，并要求自动找到来源、按内容名建文件夹、只下点名文件（如封面+前几集）时使用。覆盖登录态网站（星图等）的接口抓取（Playwright + Chrome CDP）、百度网盘分享转存与下载（BaiduPCS-Go）、直链下载，以及批量流水线（断点续跑/重试/校验/报告）。
---

# Asset Harvester（素材获取流水线）

把"某站/某网盘上的一部剧/一个合集"自动落到本地：**建文件夹 → 只下点名文件 → 校验补齐 → 出报告**。

## 双击入口（免命令行）

首次双击会自动下载便携 Python（lite，约 15MB）到包内 `runtime\`；只读目录自动改存 `%LOCALAPPDATA%`。

双击 `scripts\双击下载素材.bat`：

1. 百度网盘分享：粘贴分享链接、提取码、剧名、集数（如 `4,9,14`），自动转存 + 建 `NNN. 剧名` + 只下指定集
2. 公开直链：粘贴多个 URL，逐条下载到指定文件夹
3. 登录站（星图/后台）：仍需让 AI 用 Playwright + Chrome CDP 跑，双击入口不做站点适配

## 星图批量（一句话场景）

用户说"去星图把短剧推广任务下了，封面+第4、9、14集，然后全剪了"时：

1. Chrome 副本 + CDP（`--remote-debugging-port=9333`），确认已登录星图
2. 抓 `author_get_performance_list`（点 1→N 页，不硬翻 URL）
3. 逐任务 `author_get_challenge` → 剧名 + `demand.attachment_description`（网盘链接/提取码）
4. 按剧名建 `<根>\NNN. 剧名`，BaiduPCS-Go 转存
5. 只下封面 + 指定集：`--eps 4,9,14`
6. 校验补齐 → 交 recreate-studio 批量剪辑回同一文件夹

字段与坑见 `references/case-xingtu-2026-10-25.md`。

## 判断来源

| 来源 | 路线 |
|---|---|
| 已登录网站（星图等） | Playwright + Chrome CDP 抓接口 |
| 百度网盘分享 + 提取码 | BaiduPCS-Go 转存 → 选择性下载 |
| 公开直链 | curl / aria2c |

不绕登录/付费墙；只处理自己账号/已授权/公开内容。

## 按集点名（跳集）

`--eps 4,9,14` 或 `--eps 3-6`；也认 `第4集.mp4`/`EP04.mp4`；`--names` 仍可精确点名。

## 通用流程

1. 确认要哪些文件（常见：封面 + 前 3 集）、根目录、命名。
2. 远端建/列目录，得到剧名→文件列表。
3. 本地建 `<根>\NNN. 剧名`。
4. 只下点名文件。
5. 校验：封面 + 1/2/3.mp4。
6. 出报告（CSV + Markdown）。

## 星图实战（2026-10-27 已验证）

1. 启动 Chrome 副本：`--user-data-dir=D:\chrome-dsh-profile --remote-debugging-port=9333`。
2. `playwright.chromium.connect_over_cdp("http://127.0.0.1:9333")` 接管已登录页。
3. 任务列表接口 `author_get_performance_list` 拿 task_id + demand_name。
4. 每个任务调 `GET /gw/api/challenge/author_get_challenge?challenge_id=<task_id>`（页面上下文 fetch 带 Cookie），响应含 `pan.baidu.com/s/...?pwd=xxxx`。
5. BaiduPCS-Go：`transfer <链接> <pwd>` → `ls /漫剧/<剧名>` → `download --saveto <目录> -p 8 封面.jpg 1.mp4 2.mp4 3.mp4`。
6. 校验并归位。

示例（本次）：`015. 女官照棠`、`016. 工龄一纸，半生车间`，主夹封面+1/2/3，其余在 `_全集/`。

## 百度网盘要点

- 转存落在当前目录（先 `cd /漫剧`）。
- **`--saveto` 路径不能含 `. `**：`015. 剧名` 会被拆成 `015\剧名`；先下无点临时目录再移动。
- **点名文件对不上会整目录下载**：先 `ls` 核对。
- Python 调用 `stdout=DEVNULL, stderr=DEVNULL` 防死锁；输出 GBK，先 utf-8 再 gbk。

## 容错

- 目录带 `：共N集` 后缀要剥掉。
- 封面 `封面.jpg`/`cover (1).jpg`/`1：1.png` 都认，任意图片扩展名兜底。
- 套层/拆分目录（`封面/`、`正片/`）按实际路径下。
- 翻页先点第 1 页再顺序点；断点续跑记进度 JSON。

## 校验

`scripts/harvester_template.py verify --root "<根>"`；每部应有封面 + 1/2/3.mp4。

## 安全

Cookie 只本机用；不写日志、不外发；不碰付费墙。

## 版本

- v1.4（2026-10-27）：新设备加固——bat 设 PYTHONUTF8/UTF-8 输出（英文系统不乱码）；PCS 自动在 env/常见目录/PATH 查找；星图批量章节。
- v1.3（2026-10-27）：路径加固——保存目录可弹窗选择、norm 绝对化、标题清洗、磁盘检查、BaiduPCS-Go 缺失提示、PCS 输出 utf-8→gbk 严格解码；支持中文/空格/! % 路径。
- v1.2（2026-10-27）：双击入口中文路径修复（marker 改 ANSI、先查包内 runtime）、bat 统一 CRLF、lite 自装 Python（约 15MB）；模板支持 --eps 4,9,14 / 3-6。 / 来源 / 回滚

- v1.0（2026-10-25；2026-10-27 恢复并补星图 challenge 接口与 PCS 路径坑）
- 来源：星图 112 部素材实战 + 2026-10-27 两部剧实下
- 注意：本技能曾被并行进程合并进 recreate-studio 并删除目录，已从合并副本恢复
- 回滚：删目录 + 删记忆条目

详细命令：`references/toolchain.md`、`references/case-xingtu-2026-10-25.md`、`references/download-pipeline.md`

## 按用户指定集数下载（硬规则，2026-10-27）

用户说“下载封面和 N 集” → **只下封面 + 第 1..N 集**，不得整目录、不得多下。

- 命令：`python scripts/harvester_template.py download --remote "/漫剧/<剧名>" --local "<目录>" --eps N`
- 实现：逐个文件 `download --saveto <临时目录> "<远端>/<文件名>"`，下完移动到本地，避免 PCS 多参数时整目录下载。
- 校验：下载结果 `want == got`，目录里只能有 封面 + 1..N.mp4。
- 若远端没有封面或某集：报告缺失，不拿其它文件凑数。
